import json
import os
import re
import urllib.error
import urllib.request
from typing import List, Optional


def get_ollama_model() -> str:
    return os.getenv("OLLAMA_MODEL", "llama3.2:3b")


def ollama_generate(prompt: str, model: str) -> Optional[str]:
    payload = {
        "model": model,
        "prompt": prompt,
        "stream": False,
        "options": {
            "temperature": 0.0,
            "top_p": 0.9,
        },
    }

    url = "http://localhost:11434/api/generate"
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})

    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            out = json.loads(resp.read().decode("utf-8"))
            text = (out.get("response") or "").strip()
            return text if text else None
    except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, json.JSONDecodeError):
        return None


_GREETING_RE = re.compile(r"^\s*(hi|hello|hey|thanks|thank you|thx)\b", re.IGNORECASE)


def _is_small_talk(text: str) -> bool:
    if not text:
        return False
    t = text.strip().lower()
    if _GREETING_RE.match(t):
        return True
    if t in {"ok", "okay", "nice", "great", "cool"}:
        return True
    return False


def _final_with_sources(answer: str, sources: List[str]) -> str:
    answer = (answer or "").strip()
    if not answer:
        answer = "I couldn't produce an answer."

    if sources:
        return answer.rstrip() + "\nSources: " + ", ".join(sources)
    return answer


def llm_rewrite(user_q: str, factual_text: str, facts: List[str], sources: List[str]) -> str:
    # 1) Small talk: never respond with specs
    if _is_small_talk(user_q):
        return "Hi! Tell me what you want to know (e.g., budget + seats + fuel + body type, or ask about a model’s feature)."

    # 2) If we have no facts, DO NOT let LLM guess
    #    (This is the strongest anti-hallucination rule.)
    if not facts:
        return _final_with_sources(factual_text, sources)

    # 3) If factual_text already contains Sources line, don't rewrite it
    if "Sources:" in (factual_text or ""):
        return factual_text.strip()

    # 4) Strict rewrite prompt: output must follow exact format
    prompt = f"""
You are a Toyota Cambodia Sales/Service Assistant.

Your job: ONLY rewrite the provided answer for clarity and friendliness.
You MUST NOT add, remove, infer, or change any vehicle specification.
You MUST NOT answer a different question.

Hard rules:
- Use ONLY the information contained in FACTS and FACTUAL_ANSWER.
- Do NOT add any new features, trims, years, safety systems, prices, or assumptions.
- Do NOT mention PVM unless it is already in FACTS or FACTUAL_ANSWER.
- Keep it short: 1 to 3 sentences.
- End with a Sources line exactly like this if sources are provided:
  Sources: <url1>, <url2>

Output format (STRICT):
ANSWER: <your rewritten answer>
SOURCES: <comma-separated urls>   (only if sources exist; otherwise omit this line)

USER_QUESTION:
{user_q}

FACTUAL_ANSWER:
{factual_text}

FACTS_JSON:
{json.dumps(facts, ensure_ascii=False)}

SOURCES_JSON:
{json.dumps(sources, ensure_ascii=False)}
""".strip()

    model = get_ollama_model()
    out = ollama_generate(prompt, model)

    # 5) Validate output format; fallback if not compliant
    if not out:
        return _final_with_sources(factual_text, sources)

    out = out.strip()

    # Must start with ANSWER:
    if not out.lower().startswith("answer:"):
        return _final_with_sources(factual_text, sources)

    # Extract ANSWER line(s)
    lines = [ln.strip() for ln in out.splitlines() if ln.strip()]
    answer_lines = []
    sources_line = ""

    for ln in lines:
        if ln.lower().startswith("answer:"):
            answer_lines.append(ln.split(":", 1)[1].strip())
        elif ln.lower().startswith("sources:") or ln.lower().startswith("sources:".replace(":", "")):
            sources_line = ln

    answer = " ".join([a for a in answer_lines if a]).strip()
    if not answer:
        return _final_with_sources(factual_text, sources)

    # Enforce sources if provided
    if sources:
        # if model did not provide sources line, we append it ourselves
        return _final_with_sources(answer, sources)

    return answer