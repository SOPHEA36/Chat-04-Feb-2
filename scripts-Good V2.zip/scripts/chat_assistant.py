# scripts/chat_assistant.py
from typing import Dict, Any, List, Optional
import re

from scripts.csv_engine import (
    load_full_rows,
    detect_feature_key,
    detect_model_in_text,
    detect_models_in_text,
    resolve_target_model,
    answer_feature_from_csv,
    is_recommendation_intent,
    extract_budget,
    extract_seats,
    extract_fuel,
    extract_body_type,
    filter_cars_split,
    build_reco_answer,
    is_summary_intent,
    answer_summary_from_csv,
    find_row_by_model,
    to_int,
    format_price_usd,
)
from scripts.llm_client import llm_rewrite
from scripts.rag_engine import RAGEngine


def _is_small_talk(text: str) -> bool:
    t = (text or "").strip().lower()
    return t in {"hi", "hello", "hey", "hii", "hallo"} or t.startswith(("hi ", "hello ", "hey "))

def _small_talk_reply() -> Dict[str, Any]:
    text = (
        "Hi! I can help you with:\n"
        "- Recommend Toyota models by budget + fuel + body type (seats optional)\n"
        "- Answer quick questions (price, turning radius, CarPlay/Android Auto, BSM, PVM, reverse camera, cruise control)\n"
        "- Summarize safety systems\n"
        "- Compare 2 models\n"
        "Examples:\n"
        "  recommend budget 50000 hybrid suv\n"
        "  price of yaris cross hev\n"
        "  turning radius of yaris cross\n"
        "  compare yaris cross and corolla cross\n"
    )
    return {"answer_type": "system", "text": text, "facts": [], "sources": []}

def _is_yes(text: str) -> bool:
    t = (text or "").strip().lower()
    return t in {"yes", "y", "ok", "okay", "sure", "pls", "please"}

def _pipe(res: Dict[str, Any], pipeline: str, debug: bool) -> Dict[str, Any]:
    if debug:
        res = dict(res)
        res["pipeline"] = pipeline
    return res

def _render_pipeline_tag(res: Dict[str, Any], debug: bool) -> str:
    if not debug:
        return ""
    p = res.get("pipeline")
    if not p:
        return ""
    return f"\n[PIPELINE={p}]"

def _parse_compare_models(text: str, full_rows) -> List[str]:
    return detect_models_in_text(text, full_rows, max_models=3)

def _compare_models_from_csv(full_rows, model_a_norm: str, model_b_norm: str) -> Optional[Dict[str, Any]]:
    row_a = find_row_by_model(full_rows, model_a_norm)
    row_b = find_row_by_model(full_rows, model_b_norm)
    if not row_a or not row_b:
        return None

    a_name = row_a.get("model") or model_a_norm
    b_name = row_b.get("model") or model_b_norm
    src_a = row_a.get("url") or ""
    src_b = row_b.get("url") or ""

    compare_fields = [
        ("Price (USD)", "price_usd", "price"),
        ("Body type", "body_type", None),
        ("Seats", "seats", None),
        ("Fuel", "fuel", None),
        ("Minimum turning radius", "spec_minimum_turning_radius_tire", None),
        ("Apple CarPlay / Android Auto", "spec_apple_carplay_and_android_auto", None),
        ("Reverse camera", "spec_reverse_camera", None),
        ("Panoramic View Monitor (PVM)", "spec_panoramic_view_monitor_pvm", None),
        ("Blind Spot Monitor (BSM)", "spec_blind_spot_monitor_bsm", None),
        ("Cruise control", "spec_cruise_control", None),
    ]

    diffs: List[str] = []
    same: List[str] = []

    for label, col, kind in compare_fields:
        av = row_a.get(col)
        bv = row_b.get(col)

        if kind == "price":
            a_txt = format_price_usd(av)
            b_txt = format_price_usd(bv)
        else:
            a_txt = str(av).strip() if av not in (None, "") else "N/A"
            b_txt = str(bv).strip() if bv not in (None, "") else "N/A"

        line = f"- {label}: {a_txt} vs {b_txt}"
        if a_txt.strip().lower() == b_txt.strip().lower():
            same.append(line)
        else:
            diffs.append(line)

    lines: List[str] = []
    lines.append("Here’s a quick comparison (official specs):")
    lines.append(f"{a_name} vs {b_name}")

    if diffs:
        lines.append("")
        lines.append("Key differences:")
        lines.extend(diffs)

    if same:
        lines.append("")
        lines.append("Same on both models:")
        lines.extend(same)

    sources: List[str] = []
    if src_a:
        sources.append(src_a)
    if src_b and src_b not in sources:
        sources.append(src_b)

    text = "\n".join(lines).strip()
    return {"answer_type": "csv_compare", "text": text, "facts": [text], "sources": sources}

def _reset_state(state: Dict[str, Any]) -> None:
    state["last_model"] = None
    state["slots"] = {"max_budget": None, "min_seats": None, "fuel": None, "body_type": None}
    state["pending_compare"] = {"awaiting": False, "base_model_norm": None}
    state["slot_fill_active"] = False
    state["slot_fill_missing"] = []
    state["last_reco"] = None

def _has_last_reco(state: Dict[str, Any]) -> bool:
    lr = state.get("last_reco")
    if not lr:
        return False
    return lr.get("max_budget") is not None and lr.get("fuel") and lr.get("body_type")

def _continue_reco_from_state(state: Dict[str, Any], full_rows, debug: bool) -> Dict[str, Any]:
    slots = state["slots"]

    need_budget = slots["max_budget"] is None
    need_fuel = slots["fuel"] is None
    need_body = slots["body_type"] is None

    if need_budget or need_fuel or need_body:
        missing = []
        if need_budget:
            missing.append("maximum budget (USD)")
        if need_fuel:
            missing.append("fuel (Diesel/Gasoline/Hybrid/EV/Any)")
        if need_body:
            missing.append("body type (SUV/Sedan/MPV/Pickup/Bus/Any)")

        state["slot_fill_active"] = True
        text = "To recommend from official data, please tell me: " + ", ".join(missing) + "."
        return _pipe({"answer_type": "csv_reco", "text": text, "facts": [], "sources": []}, "CSV_METHOD", debug)

    assumed_seats = None
    if slots["min_seats"] is None:
        slots["min_seats"] = 5
        assumed_seats = 5

    max_budget = int(slots["max_budget"])
    min_seats = int(slots["min_seats"])
    fuel = slots["fuel"]
    body_type = slots["body_type"]

    verified, possible = filter_cars_split(full_rows, max_budget, min_seats, fuel, body_type)
    ans = build_reco_answer(verified, possible, max_items=5, assumed_seats=assumed_seats)

    state["last_reco"] = {
        "max_budget": max_budget,
        "min_seats": min_seats,
        "fuel": fuel,
        "body_type": body_type,
    }

    if verified:
        state["last_model"] = (verified[0].get("model") or "").lower().strip() or state.get("last_model")
    elif possible:
        state["last_model"] = (possible[0].get("model") or "").lower().strip() or state.get("last_model")

    state["slots"] = {"max_budget": None, "min_seats": None, "fuel": None, "body_type": None}
    state["slot_fill_active"] = False
    state["slot_fill_missing"] = []

    return _pipe(ans, "CSV_METHOD", debug)

def chat_turn(user_text: str, state: Dict[str, Any], full_rows, rag: RAGEngine, debug: bool) -> Dict[str, Any]:
    user_text = (user_text or "").strip()
    if not user_text:
        return _pipe({"answer_type": "system", "text": "Please type a question or your requirements.", "facts": [], "sources": []}, "SYSTEM", debug)

    if user_text.lower().strip() == "/reset":
        _reset_state(state)
        return _pipe({"answer_type": "system", "text": "Reset done. Ask me anything.", "facts": [], "sources": []}, "SYSTEM", debug)

    if _is_small_talk(user_text):
        return _pipe(_small_talk_reply(), "SYSTEM", debug)

    feature_key_now = detect_feature_key(user_text)
    summary_now = is_summary_intent(user_text)

    if summary_now:
        model_norm = resolve_target_model(user_text, state.get("last_model"), full_rows)
        if model_norm:
            state["last_model"] = model_norm
            csv_sum = answer_summary_from_csv(full_rows, model_norm)
            if csv_sum:
                return _pipe(csv_sum, "CSV_METHOD", debug)

    if feature_key_now == "price":
        models = detect_models_in_text(user_text, full_rows, max_models=3)
        if models:
            lines: List[str] = []
            sources: List[str] = []
            for m in models:
                res = answer_feature_from_csv(full_rows, m, "price")
                if res:
                    lines.append(res["text"])
                    for s in res.get("sources", []):
                        if s and s not in sources:
                            sources.append(s)
            if lines:
                return _pipe({"answer_type": "csv_feature_multi", "text": "\n".join(lines), "facts": [], "sources": sources}, "CSV_METHOD", debug)

    if feature_key_now and feature_key_now != "spec":
        model_norm = resolve_target_model(user_text, state.get("last_model"), full_rows)
        if model_norm:
            state["last_model"] = model_norm
            csv_res = answer_feature_from_csv(full_rows, model_norm, feature_key_now)
            if csv_res:
                return _pipe(csv_res, "CSV_METHOD", debug)

    t_norm = user_text.lower().strip()
    if t_norm.startswith("compare") or " vs " in t_norm or " versus " in t_norm:
        models = _parse_compare_models(user_text, full_rows)
        if len(models) >= 2:
            res = _compare_models_from_csv(full_rows, models[0], models[1])
            if res:
                return _pipe(res, "CSV_METHOD", debug)
        state["pending_compare"] = {"awaiting": True, "base_model_norm": state.get("last_model")}
        return _pipe({"answer_type": "system", "text": "Which two models do you want to compare? Example: compare yaris cross and corolla cross", "facts": [], "sources": []}, "SYSTEM", debug)

    if state.get("pending_compare", {}).get("awaiting") is True:
        base_norm = state.get("pending_compare", {}).get("base_model_norm")
        models = _parse_compare_models(user_text, full_rows)

        if len(models) >= 2:
            res = _compare_models_from_csv(full_rows, models[0], models[1])
            state["pending_compare"] = {"awaiting": False, "base_model_norm": None}
            if res:
                return _pipe(res, "CSV_METHOD", debug)
            return _pipe({"answer_type": "system", "text": "I couldn’t build the comparison from CSV.", "facts": [], "sources": []}, "SYSTEM", debug)

        if base_norm and len(models) == 1:
            target = models[0]
            if target == base_norm:
                return _pipe({"answer_type": "system", "text": "That’s the same model. Please choose a different model to compare.", "facts": [], "sources": []}, "SYSTEM", debug)
            res = _compare_models_from_csv(full_rows, base_norm, target)
            state["pending_compare"] = {"awaiting": False, "base_model_norm": None}
            if res:
                return _pipe(res, "CSV_METHOD", debug)
            return _pipe({"answer_type": "system", "text": "I couldn’t build the comparison from CSV.", "facts": [], "sources": []}, "SYSTEM", debug)

        if _is_yes(user_text):
            return _pipe({"answer_type": "system", "text": "Type the model name you want to compare with. Example: Corolla Cross HEV", "facts": [], "sources": []}, "SYSTEM", debug)

        return _pipe({"answer_type": "system", "text": "Which model should I compare with? Please type the model name.", "facts": [], "sources": []}, "SYSTEM", debug)

    # Follow-up refinement: "then 7 seats" after a recommendation
    if _has_last_reco(state):
        b = extract_budget(user_text)
        s = extract_seats(user_text)
        f = extract_fuel(user_text)
        bt = extract_body_type(user_text)

        # Only apply refinement if user did not start a new recommendation with new budget
        if b is None and (s is not None or f is not None or bt is not None) and not is_recommendation_intent(user_text):
            lr = dict(state["last_reco"])
            if s is not None:
                lr["min_seats"] = s
            if f is not None:
                lr["fuel"] = f
            if bt is not None:
                lr["body_type"] = bt

            state["slots"]["max_budget"] = lr["max_budget"]
            state["slots"]["min_seats"] = lr["min_seats"]
            state["slots"]["fuel"] = lr["fuel"]
            state["slots"]["body_type"] = lr["body_type"]

            return _continue_reco_from_state(state, full_rows, debug)

    if state.get("slot_fill_active") is True:
        b = extract_budget(user_text)
        s = extract_seats(user_text)
        f = extract_fuel(user_text)
        bt = extract_body_type(user_text)

        if b is not None:
            state["slots"]["max_budget"] = b
        if s is not None:
            state["slots"]["min_seats"] = s
        if f is not None:
            state["slots"]["fuel"] = f
        if bt is not None:
            state["slots"]["body_type"] = bt

        return _continue_reco_from_state(state, full_rows, debug)

    if is_recommendation_intent(user_text):
        b = extract_budget(user_text)
        s = extract_seats(user_text)
        f = extract_fuel(user_text)
        bt = extract_body_type(user_text)

        if b is not None:
            state["slots"]["max_budget"] = b
        if s is not None:
            state["slots"]["min_seats"] = s
        if f is not None:
            state["slots"]["fuel"] = f
        if bt is not None:
            state["slots"]["body_type"] = bt

        return _continue_reco_from_state(state, full_rows, debug)

    mentioned_model = detect_model_in_text(user_text, full_rows)
    if mentioned_model:
        state["last_model"] = mentioned_model

    return _pipe(rag.rag_answer(user_text, last_model_norm=state.get("last_model")), "RAG", debug)

def render_answer(user_text: str, res: Dict[str, Any], use_llm: bool, debug: bool) -> str:
    text = (res.get("text") or "").strip()
    facts = res.get("facts") or []
    sources = res.get("sources") or []

    if not text:
        text = "I couldn't produce an answer."

    if res.get("answer_type") in {"csv_feature", "csv_feature_multi", "csv_reco", "csv_summary", "csv_compare"}:
        if sources:
            text = text + "\nSources: " + ", ".join(sources)
        return text + _render_pipeline_tag(res, debug)

    if use_llm:
        out = llm_rewrite(user_text, text, facts, sources)
        if sources:
            out = out + "\nSources: " + ", ".join(sources)
        return out + _render_pipeline_tag(res, debug)

    if sources:
        return (text + "\nSources: " + ", ".join(sources)) + _render_pipeline_tag(res, debug)

    return text + _render_pipeline_tag(res, debug)

def main():
    full_rows = load_full_rows()
    rag = RAGEngine(full_rows)

    state: Dict[str, Any] = {
        "last_model": None,
        "slots": {"max_budget": None, "min_seats": None, "fuel": None, "body_type": None},
        "pending_compare": {"awaiting": False, "base_model_norm": None},
        "slot_fill_active": False,
        "slot_fill_missing": [],
        "last_reco": None,
    }

    use_llm = True
    debug = True

    print("Car Assistant (CSV-first + Compare + RAG fallback + optional LLM rewrite)")
    print("Commands: /debug on | /debug off | /reset | exit\n")

    while True:
        user = input("You: ").strip()
        if user.lower() in {"exit", "quit"}:
            break

        if user.lower().strip() == "/debug on":
            debug = True
            print("\nBot: Debug ON\n")
            continue
        if user.lower().strip() == "/debug off":
            debug = False
            print("\nBot: Debug OFF\n")
            continue

        res = chat_turn(user, state, full_rows, rag, debug=debug)
        out = render_answer(user, res, use_llm=use_llm, debug=debug)
        print(f"\nBot: {out}\n")

if __name__ == "__main__":
    main()