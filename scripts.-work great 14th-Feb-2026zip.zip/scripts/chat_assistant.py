#
# from __future__ import annotations
#
# from typing import Dict, Any, List, Optional
# import re
# import sys
# from pathlib import Path
#
# PROJECT_ROOT = Path(__file__).resolve().parents[1]
# if str(PROJECT_ROOT) not in sys.path:
#     sys.path.insert(0, str(PROJECT_ROOT))
#
# from scripts.csv_engine import (
#     load_full_rows,
#     detect_feature_key,
#     detect_model_in_text,
#     detect_models_in_text,
#     resolve_target_model,
#     answer_feature_from_csv,
#     is_recommendation_intent,
#     extract_budget,
#     extract_seats,
#     extract_fuel,
#     extract_body_type,
#     filter_cars_split,
#     build_reco_answer,
#     is_summary_intent,
#     answer_summary_from_csv,
#     is_spec_intent,
#     answer_specs_from_csv,
#     find_row_by_model,
#     format_price_usd,
#     list_variants_for_model,
# )
#
# from scripts.llm_client import llm_rewrite
#
#
# class SafeRAGFallback:
#     available = False
#
#     def __init__(self, rows):
#         self.rows = rows
#
#     def rag_answer(self, user_text: str, last_model_norm: str | None = None) -> Dict[str, Any]:
#         return {
#             "answer_type": "system",
#             "text": "This question is not answerable from the current dataset.",
#             "facts": [],
#             "sources": [],
#         }
#
#
# def build_rag_engine(rows):
#     try:
#         from scripts.rag_engine import RAGEngine
#
#         eng = RAGEngine(rows)
#         setattr(eng, "available", True)
#         return eng
#     except Exception:
#         return SafeRAGFallback(rows)
#
#
# def _clean_user_text(text: str) -> str:
#     t = (text or "").strip()
#     t = re.sub(r"^\s*\d+[\.\)]\s*", "", t)
#     t = t.strip().strip("“”\"'")
#     t = re.sub(r"[\(\)\[\]\{\}]+$", "", t).strip()
#     t = re.sub(r"\s+", " ", t).strip()
#     return t
#
#
# def _is_small_talk(text: str) -> bool:
#     t = (text or "").strip().lower()
#     return t in {"hi", "hello", "hey", "hii", "hallo", "thanks", "thank you"} or t.startswith(
#         ("hi ", "hello ", "hey ", "thanks ", "thank you ")
#     )
#
#
# def _pipe(res: Dict[str, Any], pipeline: str, debug: bool) -> Dict[str, Any]:
#     if debug:
#         res = dict(res)
#         res["pipeline"] = pipeline
#     return res
#
#
# def _render_pipeline_tag(pipeline: str, debug: bool) -> str:
#     if not debug or not pipeline:
#         return ""
#     return f"\n[PIPELINE={pipeline}]"
#
#
# def _reset_state(state: Dict[str, Any]) -> None:
#     state.clear()
#     state.update(
#         {
#             "last_model": None,
#             "slots": {"max_budget": None, "min_seats": None, "fuel": None, "body_type": None},
#             "slot_fill_active": False,
#             "slot_fill_missing": [],
#             "last_reco": None,
#             "awaiting_model_for": None,  # "spec" | "summary" | "feature:<key>"
#         }
#     )
#
#
# def _cancel_reco_flow(state: Dict[str, Any]) -> None:
#     state["slot_fill_active"] = False
#     state["slot_fill_missing"] = []
#     state["slots"] = {"max_budget": None, "min_seats": None, "fuel": None, "body_type": None}
#
#
# def _missing_reco_slots(slots: Dict[str, Any]) -> List[str]:
#     missing: List[str] = []
#     if slots.get("max_budget") is None:
#         missing.append("budget (USD)")
#     if not slots.get("body_type"):
#         missing.append("body type (SUV / Sedan / Pickup / MPV / Bus)")
#     if not slots.get("fuel"):
#         missing.append("fuel (Gasoline / Diesel / Hybrid / EV)")
#     return missing
#
#
# def _answer_field_missing(full_rows, model_norm: str, feature_key: str, debug: bool) -> Dict[str, Any]:
#     row = find_row_by_model(full_rows, model_norm)
#     name = row.get("model") if row else model_norm
#     src = row.get("url") if row else ""
#     text = f"Thanks. I don’t have '{feature_key}' captured for {name} in the current dataset yet."
#     return _pipe(
#         {"answer_type": "system", "text": text, "facts": [], "sources": [src] if src else []},
#         "CSV_METHOD",
#         debug,
#     )
#
#
# def _try_switch_variant_by_fuel(full_rows, base_model_norm: str, fuel: str) -> Optional[str]:
#     if not base_model_norm or not fuel:
#         return None
#
#     fuel_norm = fuel.lower().strip()
#     if fuel_norm == "hev":
#         fuel_norm = "hybrid"
#     if fuel_norm == "electric":
#         fuel_norm = "ev"
#     if fuel_norm == "her":
#         fuel_norm = "hev"
#
#     variant = detect_model_in_text(f"{base_model_norm} {fuel_norm}", full_rows)
#     if variant:
#         return variant
#
#     variants = list_variants_for_model(full_rows, base_model_norm)
#     for v in variants:
#         vf = (v.get("fuel") or "").lower().strip()
#         if vf == fuel_norm:
#             vname = (v.get("model") or "").lower().strip()
#             if vname:
#                 return vname
#
#     return None
#
#
# def _compare_models_from_csv(full_rows, model_a_norm: str, model_b_norm: str) -> Optional[Dict[str, Any]]:
#     row_a = find_row_by_model(full_rows, model_a_norm)
#     row_b = find_row_by_model(full_rows, model_b_norm)
#     if not row_a or not row_b:
#         return None
#
#     a_name = row_a.get("model") or model_a_norm
#     b_name = row_b.get("model") or model_b_norm
#
#     def norm_txt(v: Any) -> str:
#         if v in (None, ""):
#             return "N/A"
#         return str(v).strip()
#
#     lines: List[str] = []
#     lines.append(f"Here’s a quick comparison (official dataset): {a_name} vs {b_name}")
#     lines.append(f"- Price: {format_price_usd(row_a.get('price_usd'))} vs {format_price_usd(row_b.get('price_usd'))}")
#     lines.append(f"- Seats: {norm_txt(row_a.get('seats'))} vs {norm_txt(row_b.get('seats'))}")
#     lines.append(f"- Fuel: {norm_txt(row_a.get('fuel'))} vs {norm_txt(row_b.get('fuel'))}")
#     lines.append(f"- Body type: {norm_txt(row_a.get('body_type'))} vs {norm_txt(row_b.get('body_type'))}")
#
#     sources: List[str] = []
#     if row_a.get("url"):
#         sources.append(row_a["url"])
#     if row_b.get("url") and row_b["url"] not in sources:
#         sources.append(row_b["url"])
#
#     text = "\n".join(lines).strip()
#     return {"answer_type": "csv_compare", "text": text, "facts": [text], "sources": sources}
#
#
# def _looks_like_shopping_request(user_text: str, full_rows) -> bool:
#     t = (user_text or "").lower()
#     b = extract_budget(user_text)
#     bt = extract_body_type(user_text)
#     has_budget = b is not None
#     has_body = bool(bt)
#     has_any_model = bool(
#         detect_model_in_text(user_text, full_rows) or detect_models_in_text(user_text, full_rows, max_models=2)
#     )
#     has_compare = " vs " in t or " versus " in t or t.startswith("compare")
#     has_spec = is_spec_intent(user_text) or bool(re.fullmatch(r"specs?\??", user_text.strip().lower()))
#     has_summary = is_summary_intent(user_text)
#
#     if has_budget and has_body and (not has_any_model) and (not has_compare) and (not has_spec) and (not has_summary):
#         return True
#
#     if has_body and (not has_any_model) and (not has_compare) and (not has_spec) and (not has_summary):
#         return True
#
#     return False
#
#
# def _sales_wrap_csv_text(original_text: str) -> str:
#     text = (original_text or "").strip()
#     if not text:
#         return text
#
#     if "— Price (USD):" in text or text.lower().startswith("the price"):
#         return "Sure — here are the official prices from our dataset:\n\n" + text
#
#     if "I don’t have" in text or "I don't have" in text:
#         return text + "\nIf you’d like, tell me your budget and preferred fuel, and I’ll suggest the closest options we have."
#
#     return text
#
#
# def _normalize_words(s: str) -> List[str]:
#     s = (s or "").lower()
#     s = re.sub(r"[^a-z0-9\s]+", " ", s)
#     return [w for w in s.split() if w]
#
#
# def _looks_like_user_named_a_model(user_text: str) -> bool:
#     t = (user_text or "").lower()
#     patterns = [
#         r"\bprice of\b",
#         r"\bwhat is the price of\b",
#         r"\bwhat is the starting price of\b",
#         r"\bstarting price of\b",
#         r"\bhow much is\b",
#         r"\bhow much does\b",
#         r"\bcost of\b",
#     ]
#     return any(re.search(p, t) for p in patterns)
#
#
# def _best_effort_model_from_text(full_rows, user_text: str) -> Optional[str]:
#     text_tokens = set(_normalize_words(user_text))
#     if not text_tokens:
#         return None
#
#     best_model = None
#     best_score = 0
#
#     for r in full_rows:
#         m = (r.get("model") or "").strip()
#         if not m:
#             continue
#
#         model_tokens = set(_normalize_words(m))
#         if not model_tokens:
#             continue
#
#         score = len(model_tokens.intersection(text_tokens))
#         if score > best_score:
#             best_score = score
#             best_model = m.lower().strip()
#
#     if best_score >= 2:
#         return best_model
#     return None
#
#
# def _resolve_model_no_leak(full_rows, user_text: str, last_model: Optional[str]) -> Dict[str, Any]:
#     """
#     Critical rule:
#     If user text looks like it contains a model name request (price of X / how much is X),
#     NEVER fall back to last_model (prevents Fortuner repeating bug).
#     """
#     explicit = detect_model_in_text(user_text, full_rows)
#     if explicit:
#         return {"model": explicit, "explicit": True}
#
#     if _looks_like_user_named_a_model(user_text):
#         fuzzy = _best_effort_model_from_text(full_rows, user_text)
#         if fuzzy:
#             return {"model": fuzzy, "explicit": True}
#         return {"model": None, "explicit": True}
#
#     resolved = resolve_target_model(user_text, last_model, full_rows)
#     if resolved:
#         return {"model": resolved, "explicit": False}
#
#     return {"model": last_model, "explicit": False}
#
#
# def chat_turn(user_text: str, state: Dict[str, Any], full_rows, rag, debug: bool) -> Dict[str, Any]:
#     user_text = _clean_user_text(user_text)
#     if not user_text:
#         return _pipe({"answer_type": "system", "text": "Please type a question.", "facts": [], "sources": []}, "SYSTEM", debug)
#
#     if user_text.lower().strip() == "/reset":
#         _reset_state(state)
#         return _pipe({"answer_type": "system", "text": "Reset done.", "facts": [], "sources": []}, "SYSTEM", debug)
#
#     if _is_small_talk(user_text):
#         return _pipe(
#             {"answer_type": "system", "text": "Hi! Tell me what you want to know (price, specs, features, compare, or recommendation).", "facts": [], "sources": []},
#             "SYSTEM",
#             debug,
#         )
#
#     if state.get("awaiting_model_for"):
#         m = detect_model_in_text(user_text, full_rows) or _best_effort_model_from_text(full_rows, user_text)
#         if m:
#             purpose = state["awaiting_model_for"]
#             state["awaiting_model_for"] = None
#             state["last_model"] = m
#             _cancel_reco_flow(state)
#
#             if purpose == "spec":
#                 res = answer_specs_from_csv(full_rows, m)
#                 if res:
#                     return _pipe(res, "CSV_METHOD", debug)
#             if purpose == "summary":
#                 res = answer_summary_from_csv(full_rows, m)
#                 if res:
#                     return _pipe(res, "CSV_METHOD", debug)
#             if purpose.startswith("feature:"):
#                 fk = purpose.split(":", 1)[1]
#                 res = answer_feature_from_csv(full_rows, m, fk)
#                 if res:
#                     return _pipe(res, "CSV_METHOD", debug)
#
#             return _pipe({"answer_type": "system", "text": "Sorry — I couldn’t find that in the current dataset.", "facts": [], "sources": []}, "SYSTEM", debug)
#
#         return _pipe({"answer_type": "system", "text": "Sure — which model are you asking about?"}, "SYSTEM", debug)
#
#     feature_key_now = detect_feature_key(user_text)
#     spec_now = is_spec_intent(user_text) or bool(re.fullmatch(r"specs?\??", user_text.strip().lower()))
#     summary_now = is_summary_intent(user_text)
#
#     if state.get("slot_fill_active") is True:
#         looks_like_reco = is_recommendation_intent(user_text) or _looks_like_shopping_request(user_text, full_rows)
#         has_model = bool(detect_model_in_text(user_text, full_rows) or detect_models_in_text(user_text, full_rows, max_models=2))
#         looks_like_compare = " vs " in user_text.lower() or "compare" in user_text.lower()
#         looks_like_feature = bool(feature_key_now)
#         looks_like_spec_summary = bool(spec_now or summary_now)
#         if not looks_like_reco and (has_model or looks_like_compare or looks_like_feature or looks_like_spec_summary):
#             _cancel_reco_flow(state)
#
#     mentioned_model = detect_model_in_text(user_text, full_rows)
#     if mentioned_model:
#         state["last_model"] = mentioned_model
#
#     t_norm = user_text.lower()
#     if t_norm.startswith("compare") or " vs " in t_norm or " versus " in t_norm:
#         models = detect_models_in_text(user_text, full_rows, max_models=2)
#         if len(models) >= 2:
#             res = _compare_models_from_csv(full_rows, models[0], models[1])
#             if res:
#                 _cancel_reco_flow(state)
#                 return _pipe(res, "CSV_METHOD", debug)
#         return _pipe({"answer_type": "system", "text": "Sure — which two models would you like to compare? Example: compare A vs B", "facts": [], "sources": []}, "SYSTEM", debug)
#
#     if spec_now:
#         r = _resolve_model_no_leak(full_rows, user_text, state.get("last_model"))
#         model_norm = r["model"]
#         if not model_norm:
#             state["awaiting_model_for"] = "spec"
#             return _pipe({"answer_type": "system", "text": "Sure — which model do you want the specs for?"}, "SYSTEM", debug)
#
#         state["last_model"] = model_norm
#         _cancel_reco_flow(state)
#         res = answer_specs_from_csv(full_rows, model_norm)
#         if res:
#             return _pipe(res, "CSV_METHOD", debug)
#         return _pipe({"answer_type": "system", "text": "Sorry — I couldn't find the specs for that model in the dataset.", "facts": [], "sources": []}, "SYSTEM", debug)
#
#     if summary_now:
#         r = _resolve_model_no_leak(full_rows, user_text, state.get("last_model"))
#         model_norm = r["model"]
#         if not model_norm:
#             state["awaiting_model_for"] = "summary"
#             return _pipe({"answer_type": "system", "text": "Sure — which model do you want the summary for?"}, "SYSTEM", debug)
#
#         state["last_model"] = model_norm
#         _cancel_reco_flow(state)
#         res = answer_summary_from_csv(full_rows, model_norm)
#         if res:
#             return _pipe(res, "CSV_METHOD", debug)
#         return _pipe({"answer_type": "system", "text": "Sorry — I couldn't find a summary for that model in the dataset.", "facts": [], "sources": []}, "SYSTEM", debug)
#
#     if is_recommendation_intent(user_text) or _looks_like_shopping_request(user_text, full_rows) or state.get("slot_fill_active") is True:
#         b = extract_budget(user_text)
#         s = extract_seats(user_text)
#         f = extract_fuel(user_text)
#         bt = extract_body_type(user_text)
#
#         if b is not None:
#             state["slots"]["max_budget"] = b
#         if s is not None:
#             state["slots"]["min_seats"] = s
#         if f is not None:
#             state["slots"]["fuel"] = f
#         if bt is not None:
#             state["slots"]["body_type"] = bt
#
#         missing = _missing_reco_slots(state["slots"])
#         if missing:
#             state["slot_fill_active"] = True
#             state["slot_fill_missing"] = missing
#             text = "Sure — I can help. To recommend from our dataset, please tell me:\n" + "\n".join(f"- {m}" for m in missing) + "\n(Seats is optional)"
#             return _pipe({"answer_type": "system", "text": text, "facts": [], "sources": []}, "SYSTEM", debug)
#
#         max_budget = int(state["slots"]["max_budget"])
#         min_seats = int(state["slots"]["min_seats"] or 5)
#         fuel = state["slots"]["fuel"]
#         body_type = state["slots"]["body_type"]
#
#         verified, possible = filter_cars_split(full_rows, max_budget, min_seats, fuel, body_type)
#         ans = build_reco_answer(verified, possible, max_items=5, assumed_seats=None if state["slots"]["min_seats"] else 5)
#
#         state["last_reco"] = {"max_budget": max_budget, "min_seats": min_seats, "fuel": fuel, "body_type": body_type}
#         _cancel_reco_flow(state)
#         return _pipe(ans, "CSV_METHOD", debug)
#
#     if feature_key_now:
#         r = _resolve_model_no_leak(full_rows, user_text, state.get("last_model"))
#         model_norm = r["model"]
#
#         if not model_norm:
#             state["awaiting_model_for"] = f"feature:{feature_key_now}"
#             return _pipe({"answer_type": "system", "text": "Sure — which model are you asking about?"}, "SYSTEM", debug)
#
#         state["last_model"] = model_norm
#         _cancel_reco_flow(state)
#
#         res = answer_feature_from_csv(full_rows, model_norm, feature_key_now)
#         if res:
#             return _pipe(res, "CSV_METHOD", debug)
#
#         return _answer_field_missing(full_rows, model_norm, feature_key_now, debug)
#
#     pipeline = "RAG" if getattr(rag, "available", False) else "CSV_ONLY"
#     return _pipe(rag.rag_answer(user_text, last_model_norm=state.get("last_model")), pipeline, debug)
#
#
# def render_answer(user_text: str, res: Dict[str, Any], use_llm: bool, rewrite_csv: bool, debug: bool) -> str:
#     text = (res.get("text") or "").strip()
#     facts = res.get("facts") or []
#     sources = res.get("sources") or []
#     pipeline = res.get("pipeline") or ""
#
#     if not text:
#         text = "Sorry — I couldn’t produce an answer."
#
#     if use_llm:
#         if pipeline == "CSV_METHOD" and not rewrite_csv:
#             out = _sales_wrap_csv_text(text)
#         else:
#             ground = facts if facts else [text]
#             out = llm_rewrite(user_text, text, ground, sources)
#     else:
#         out = _sales_wrap_csv_text(text) if pipeline == "CSV_METHOD" else text
#
#     if sources:
#         srcs = ", ".join(s for s in sources if s)
#         if srcs:
#             out += "\nSources: " + srcs
#
#     return out + _render_pipeline_tag(pipeline, debug)
#
#
# def main() -> None:
#     full_rows = load_full_rows()
#     rag = build_rag_engine(full_rows)
#
#     state: Dict[str, Any] = {}
#     _reset_state(state)
#
#     use_llm = True
#     rewrite_csv = False
#     debug = True
#
#     print("Assistant (CSV-first + optional RAG fallback)")
#     print("Commands: /debug on | /debug off | /reset | exit\n")
#
#     while True:
#         user = input("You: ").strip()
#         if user.lower() in {"exit", "quit"}:
#             break
#
#         if user.lower().strip() == "/debug on":
#             debug = True
#             print("\nBot: Debug ON\n")
#             continue
#         if user.lower().strip() == "/debug off":
#             debug = False
#             print("\nBot: Debug OFF\n")
#             continue
#
#         res = chat_turn(user, state, full_rows, rag, debug=debug)
#         out = render_answer(user, res, use_llm=use_llm, rewrite_csv=rewrite_csv, debug=debug)
#         print(f"\nBot: {out}\n")
#
#
# if __name__ == "__main__":
#     main()

from __future__ import annotations

from typing import Dict, Any, List, Optional, Tuple
import re
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from scripts.csv_engine import (
    load_full_rows,
    detect_feature_key,
    detect_model_in_text,
    detect_models_in_text,
    resolve_target_model,
    answer_feature_from_csv,
    is_recommendation_intent,
    extract_budget,
    extract_seats,
    extract_fuel,
    extract_body_type,
    filter_cars_split,
    build_reco_answer,
    is_summary_intent,
    answer_summary_from_csv,
    is_spec_intent,
    answer_specs_from_csv,
    find_row_by_model,
    format_price_usd,
    list_variants_for_model,
)

from scripts.llm_client import llm_rewrite


class SafeRAGFallback:
    available = False

    def __init__(self, rows):
        self.rows = rows

    def rag_answer(self, user_text: str, last_model_norm: str | None = None) -> Dict[str, Any]:
        return {
            "answer_type": "system",
            "text": "This question is not answerable from the current dataset.",
            "facts": [],
            "sources": [],
        }


def build_rag_engine(rows):
    try:
        from scripts.rag_engine import RAGEngine

        eng = RAGEngine(rows)
        setattr(eng, "available", True)
        return eng
    except Exception:
        return SafeRAGFallback(rows)


def _clean_user_text(text: str) -> str:
    t = (text or "").strip()
    t = re.sub(r"^\s*\d+[\.\)]\s*", "", t)
    t = t.strip().strip("“”\"'")
    t = re.sub(r"[\(\)\[\]\{\}]+$", "", t).strip()
    t = re.sub(r"\s+", " ", t).strip()
    return t


def _is_small_talk(text: str) -> bool:
    t = (text or "").strip().lower()
    return t in {"hi", "hello", "hey", "hii", "hallo", "thanks", "thank you"} or t.startswith(
        ("hi ", "hello ", "hey ", "thanks ", "thank you ")
    )


def _pipe(res: Dict[str, Any], pipeline: str, debug: bool) -> Dict[str, Any]:
    if debug:
        res = dict(res)
        res["pipeline"] = pipeline
    return res


def _render_pipeline_tag(pipeline: str, debug: bool) -> str:
    if not debug or not pipeline:
        return ""
    return f"\n[PIPELINE={pipeline}]"


def _reset_state(state: Dict[str, Any]) -> None:
    state.clear()
    state.update(
        {
            "last_model": None,
            "slots": {"max_budget": None, "min_seats": None, "fuel": None, "body_type": None},
            "slot_fill_active": False,
            "slot_fill_missing": [],
            "last_reco": None,
            "awaiting_model_for": None,  # "spec" | "summary" | "feature:<key>"
            "last_candidates": [],  # list[str] model_norms from last recommendation
        }
    )


def _cancel_reco_flow(state: Dict[str, Any]) -> None:
    state["slot_fill_active"] = False
    state["slot_fill_missing"] = []
    state["slots"] = {"max_budget": None, "min_seats": None, "fuel": None, "body_type": None}


def _missing_reco_slots(slots: Dict[str, Any]) -> List[str]:
    missing: List[str] = []
    if slots.get("max_budget") is None:
        missing.append("budget (USD)")
    if not slots.get("body_type"):
        missing.append("body type (SUV / Sedan / Pickup / MPV / Bus)")
    if not slots.get("fuel"):
        missing.append("fuel (Gasoline / Diesel / Hybrid / EV)")
    return missing


def _answer_field_missing(full_rows, model_norm: str, feature_key: str, debug: bool) -> Dict[str, Any]:
    row = find_row_by_model(full_rows, model_norm)
    name = row.get("model") if row else model_norm
    src = row.get("url") if row else ""
    text = f"Thanks. I don’t have '{feature_key}' captured for {name} in the current dataset yet."
    return _pipe(
        {"answer_type": "system", "text": text, "facts": [], "sources": [src] if src else []},
        "CSV_METHOD",
        debug,
    )


def _try_switch_variant_by_fuel(full_rows, base_model_norm: str, fuel: str) -> Optional[str]:
    if not base_model_norm or not fuel:
        return None

    fuel_norm = fuel.lower().strip()
    if fuel_norm == "hev":
        fuel_norm = "hybrid"
    if fuel_norm == "electric":
        fuel_norm = "ev"
    if fuel_norm == "her":
        fuel_norm = "hev"

    variant = detect_model_in_text(f"{base_model_norm} {fuel_norm}", full_rows)
    if variant:
        return variant

    variants = list_variants_for_model(full_rows, base_model_norm)
    for v in variants:
        vf = (v.get("fuel") or "").lower().strip()
        if vf == fuel_norm:
            vname = (v.get("model") or "").lower().strip()
            if vname:
                return vname

    return None


def _compare_models_from_csv(full_rows, model_a_norm: str, model_b_norm: str) -> Optional[Dict[str, Any]]:
    row_a = find_row_by_model(full_rows, model_a_norm)
    row_b = find_row_by_model(full_rows, model_b_norm)
    if not row_a or not row_b:
        return None

    a_name = row_a.get("model") or model_a_norm
    b_name = row_b.get("model") or model_b_norm

    def norm_txt(v: Any) -> str:
        if v in (None, ""):
            return "N/A"
        return str(v).strip()

    lines: List[str] = []
    lines.append(f"Here’s a quick comparison (official dataset): {a_name} vs {b_name}")
    lines.append(f"- Price: {format_price_usd(row_a.get('price_usd'))} vs {format_price_usd(row_b.get('price_usd'))}")
    lines.append(f"- Seats: {norm_txt(row_a.get('seats'))} vs {norm_txt(row_b.get('seats'))}")
    lines.append(f"- Fuel: {norm_txt(row_a.get('fuel'))} vs {norm_txt(row_b.get('fuel'))}")
    lines.append(f"- Body type: {norm_txt(row_a.get('body_type'))} vs {norm_txt(row_b.get('body_type'))}")

    sources: List[str] = []
    if row_a.get("url"):
        sources.append(row_a["url"])
    if row_b.get("url") and row_b["url"] not in sources:
        sources.append(row_b["url"])

    text = "\n".join(lines).strip()
    return {"answer_type": "csv_compare", "text": text, "facts": [text], "sources": sources}


def _looks_like_shopping_request(user_text: str, full_rows) -> bool:
    t = (user_text or "").lower()
    b = extract_budget(user_text)
    bt = extract_body_type(user_text)
    has_budget = b is not None
    has_body = bool(bt)
    has_any_model = bool(
        detect_model_in_text(user_text, full_rows) or detect_models_in_text(user_text, full_rows, max_models=2)
    )
    has_compare = " vs " in t or " versus " in t or t.startswith("compare")
    has_spec = _is_spec_like(user_text)
    has_summary = is_summary_intent(user_text)

    if has_budget and has_body and (not has_any_model) and (not has_compare) and (not has_spec) and (not has_summary):
        return True

    if has_body and (not has_any_model) and (not has_compare) and (not has_spec) and (not has_summary):
        return True

    return False


def _sales_wrap_csv_text(original_text: str) -> str:
    text = (original_text or "").strip()
    if not text:
        return text

    if "— Price (USD):" in text or text.lower().startswith("the price"):
        return "Sure — here are the official prices from our dataset:\n\n" + text

    if "I don’t have" in text or "I don't have" in text:
        return text + "\nIf you’d like, tell me your budget and preferred fuel, and I’ll suggest the closest options we have."

    return text


def _normalize_words(s: str) -> List[str]:
    s = (s or "").lower()
    s = re.sub(r"[^a-z0-9\s]+", " ", s)
    return [w for w in s.split() if w]


def _looks_like_user_named_a_model(user_text: str) -> bool:
    t = (user_text or "").lower()
    patterns = [
        r"\bprice of\b",
        r"\bwhat is the price of\b",
        r"\bwhat is the starting price of\b",
        r"\bstarting price of\b",
        r"\bhow much is\b",
        r"\bhow much does\b",
        r"\bcost of\b",
    ]
    return any(re.search(p, t) for p in patterns)


def _best_effort_model_from_text(full_rows, user_text: str) -> Optional[str]:
    text_tokens = set(_normalize_words(user_text))
    if not text_tokens:
        return None

    best_model = None
    best_score = 0

    for r in full_rows:
        m = (r.get("model") or "").strip()
        if not m:
            continue

        model_tokens = set(_normalize_words(m))
        if not model_tokens:
            continue

        score = len(model_tokens.intersection(text_tokens))
        if score > best_score:
            best_score = score
            best_model = m.lower().strip()

    if best_score >= 2:
        return best_model
    return None


def _resolve_model_no_leak(full_rows, user_text: str, last_model: Optional[str]) -> Dict[str, Any]:
    explicit = detect_model_in_text(user_text, full_rows)
    if explicit:
        return {"model": explicit, "explicit": True}

    if _looks_like_user_named_a_model(user_text):
        fuzzy = _best_effort_model_from_text(full_rows, user_text)
        if fuzzy:
            return {"model": fuzzy, "explicit": True}
        return {"model": None, "explicit": True}

    resolved = resolve_target_model(user_text, last_model, full_rows)
    if resolved:
        return {"model": resolved, "explicit": False}

    return {"model": last_model, "explicit": False}


def _is_spec_like(user_text: str) -> bool:
    t = (user_text or "").strip().lower()
    if is_spec_intent(user_text) or bool(re.fullmatch(r"specs?\??", t)):
        return True
    if re.search(r"\btell me (the )?specs?\b", t):
        return True
    if re.search(r"\bshow me (the )?specs?\b", t):
        return True
    if re.search(r"\bwhat are (the )?specs?\b", t):
        return True
    return False


def _is_both_intent(user_text: str) -> bool:
    t = (user_text or "").strip().lower()
    return t in {"both", "both of them", "both please", "show both", "compare both", "all"} or t.startswith("both ")


def _collect_model_norms_from_rows(rows: List[Dict[str, Any]], max_n: int = 5) -> List[str]:
    out: List[str] = []
    for r in rows[:max_n]:
        m = (r.get("model") or "").strip().lower()
        if m and m not in out:
            out.append(m)
    return out


def _answer_price_list(full_rows, models: List[str], debug: bool) -> Dict[str, Any]:
    lines: List[str] = []
    sources: List[str] = []

    for m in models:
        res = answer_feature_from_csv(full_rows, m, "price")
        if res and (res.get("text") or "").strip():
            lines.append(res["text"].strip())
            for u in (res.get("sources") or []):
                if u and u not in sources:
                    sources.append(u)

    text = "\n".join(lines).strip() if lines else "Sorry — I couldn’t find prices for those models in the dataset."
    return _pipe({"answer_type": "csv_multi_price", "text": text, "facts": [text], "sources": sources}, "CSV_METHOD", debug)


def chat_turn(user_text: str, state: Dict[str, Any], full_rows, rag, debug: bool) -> Dict[str, Any]:
    user_text = _clean_user_text(user_text)
    if not user_text:
        return _pipe({"answer_type": "system", "text": "Please type a question.", "facts": [], "sources": []}, "SYSTEM", debug)

    if user_text.lower().strip() == "/reset":
        _reset_state(state)
        return _pipe({"answer_type": "system", "text": "Reset done.", "facts": [], "sources": []}, "SYSTEM", debug)

    if _is_small_talk(user_text):
        return _pipe(
            {"answer_type": "system", "text": "Hi! Tell me what you want to know (price, specs, features, compare, or recommendation).", "facts": [], "sources": []},
            "SYSTEM",
            debug,
        )

    if _is_both_intent(user_text) and state.get("last_candidates"):
        cands = list(state.get("last_candidates") or [])
        if len(cands) == 2:
            res = _compare_models_from_csv(full_rows, cands[0], cands[1])
            if res:
                return _pipe(res, "CSV_METHOD", debug)
        return _answer_price_list(full_rows, cands[:5], debug)

    if state.get("awaiting_model_for"):
        m = detect_model_in_text(user_text, full_rows) or _best_effort_model_from_text(full_rows, user_text)
        if m:
            purpose = state["awaiting_model_for"]
            state["awaiting_model_for"] = None
            state["last_model"] = m
            _cancel_reco_flow(state)

            if purpose == "spec":
                res = answer_specs_from_csv(full_rows, m)
                if res:
                    return _pipe(res, "CSV_METHOD", debug)
            if purpose == "summary":
                res = answer_summary_from_csv(full_rows, m)
                if res:
                    return _pipe(res, "CSV_METHOD", debug)
            if purpose.startswith("feature:"):
                fk = purpose.split(":", 1)[1]
                res = answer_feature_from_csv(full_rows, m, fk)
                if res:
                    return _pipe(res, "CSV_METHOD", debug)

            return _pipe({"answer_type": "system", "text": "Sorry — I couldn’t find that in the current dataset.", "facts": [], "sources": []}, "SYSTEM", debug)

        return _pipe({"answer_type": "system", "text": "Sure — which model are you asking about?", "facts": [], "sources": []}, "SYSTEM", debug)

    feature_key_now = detect_feature_key(user_text)
    spec_now = _is_spec_like(user_text)
    summary_now = is_summary_intent(user_text)

    if state.get("slot_fill_active") is True:
        looks_like_reco = is_recommendation_intent(user_text) or _looks_like_shopping_request(user_text, full_rows)
        has_model = bool(detect_model_in_text(user_text, full_rows) or detect_models_in_text(user_text, full_rows, max_models=2))
        looks_like_compare = " vs " in user_text.lower() or "compare" in user_text.lower()
        looks_like_feature = bool(feature_key_now)
        looks_like_spec_summary = bool(spec_now or summary_now)
        if not looks_like_reco and (has_model or looks_like_compare or looks_like_feature or looks_like_spec_summary):
            _cancel_reco_flow(state)

    mentioned_model = detect_model_in_text(user_text, full_rows)
    if mentioned_model:
        state["last_model"] = mentioned_model

    t_norm = user_text.lower()
    if t_norm.startswith("compare") or " vs " in t_norm or " versus " in t_norm:
        models = detect_models_in_text(user_text, full_rows, max_models=2)
        if len(models) >= 2:
            res = _compare_models_from_csv(full_rows, models[0], models[1])
            if res:
                _cancel_reco_flow(state)
                return _pipe(res, "CSV_METHOD", debug)
        return _pipe({"answer_type": "system", "text": "Sure — which two models would you like to compare? Example: compare A vs B", "facts": [], "sources": []}, "SYSTEM", debug)

    if spec_now:
        r = _resolve_model_no_leak(full_rows, user_text, state.get("last_model"))
        model_norm = r["model"]
        if not model_norm:
            state["awaiting_model_for"] = "spec"
            return _pipe({"answer_type": "system", "text": "Sure — which model do you want the specs for?", "facts": [], "sources": []}, "SYSTEM", debug)

        state["last_model"] = model_norm
        _cancel_reco_flow(state)
        res = answer_specs_from_csv(full_rows, model_norm)
        if res:
            return _pipe(res, "CSV_METHOD", debug)
        return _pipe({"answer_type": "system", "text": "Sorry — I couldn't find the specs for that model in the dataset.", "facts": [], "sources": []}, "SYSTEM", debug)

    if summary_now:
        r = _resolve_model_no_leak(full_rows, user_text, state.get("last_model"))
        model_norm = r["model"]
        if not model_norm:
            state["awaiting_model_for"] = "summary"
            return _pipe({"answer_type": "system", "text": "Sure — which model do you want the summary for?", "facts": [], "sources": []}, "SYSTEM", debug)

        state["last_model"] = model_norm
        _cancel_reco_flow(state)
        res = answer_summary_from_csv(full_rows, model_norm)
        if res:
            return _pipe(res, "CSV_METHOD", debug)
        return _pipe({"answer_type": "system", "text": "Sorry — I couldn't find a summary for that model in the dataset.", "facts": [], "sources": []}, "SYSTEM", debug)

    if is_recommendation_intent(user_text) or _looks_like_shopping_request(user_text, full_rows) or state.get("slot_fill_active") is True:
        b = extract_budget(user_text)
        s = extract_seats(user_text)
        f = extract_fuel(user_text)
        bt = extract_body_type(user_text)

        if b is not None:
            state["slots"]["max_budget"] = b
        if s is not None:
            state["slots"]["min_seats"] = s
        if f is not None:
            state["slots"]["fuel"] = f
        if bt is not None:
            state["slots"]["body_type"] = bt

        missing = _missing_reco_slots(state["slots"])
        if missing:
            state["slot_fill_active"] = True
            state["slot_fill_missing"] = missing
            text = "Sure — I can help. To recommend from our dataset, please tell me:\n" + "\n".join(f"- {m}" for m in missing) + "\n(Seats is optional)"
            return _pipe({"answer_type": "system", "text": text, "facts": [], "sources": []}, "SYSTEM", debug)

        max_budget = int(state["slots"]["max_budget"])
        min_seats = int(state["slots"]["min_seats"] or 5)
        fuel = state["slots"]["fuel"]
        body_type = state["slots"]["body_type"]

        verified, possible = filter_cars_split(full_rows, max_budget, min_seats, fuel, body_type)
        ans = build_reco_answer(verified, possible, max_items=5, assumed_seats=None if state["slots"]["min_seats"] else 5)

        candidates = _collect_model_norms_from_rows(verified, max_n=5) + _collect_model_norms_from_rows(possible, max_n=5)
        uniq: List[str] = []
        for m in candidates:
            if m and m not in uniq:
                uniq.append(m)

        state["last_candidates"] = uniq[:5]
        if state["last_candidates"]:
            state["last_model"] = state["last_candidates"][0]

        state["last_reco"] = {"max_budget": max_budget, "min_seats": min_seats, "fuel": fuel, "body_type": body_type}
        _cancel_reco_flow(state)
        return _pipe(ans, "CSV_METHOD", debug)

    if feature_key_now:
        r = _resolve_model_no_leak(full_rows, user_text, state.get("last_model"))
        model_norm = r["model"]

        if not model_norm:
            state["awaiting_model_for"] = f"feature:{feature_key_now}"
            return _pipe({"answer_type": "system", "text": "Sure — which model are you asking about?", "facts": [], "sources": []}, "SYSTEM", debug)

        state["last_model"] = model_norm
        _cancel_reco_flow(state)

        res = answer_feature_from_csv(full_rows, model_norm, feature_key_now)
        if res:
            return _pipe(res, "CSV_METHOD", debug)

        return _answer_field_missing(full_rows, model_norm, feature_key_now, debug)

    pipeline = "RAG" if getattr(rag, "available", False) else "CSV_ONLY"
    return _pipe(rag.rag_answer(user_text, last_model_norm=state.get("last_model")), pipeline, debug)


def render_answer(user_text: str, res: Dict[str, Any], use_llm: bool, rewrite_csv: bool, debug: bool) -> str:
    text = (res.get("text") or "").strip()
    facts = res.get("facts") or []
    sources = res.get("sources") or []
    pipeline = res.get("pipeline") or ""

    if not text:
        text = "Sorry — I couldn’t produce an answer."

    if use_llm:
        if pipeline == "CSV_METHOD" and not rewrite_csv:
            out = _sales_wrap_csv_text(text)
        else:
            ground = facts if facts else [text]
            out = llm_rewrite(user_text, text, ground, sources)
    else:
        out = _sales_wrap_csv_text(text) if pipeline == "CSV_METHOD" else text

    if sources:
        srcs = ", ".join(s for s in sources if s)
        if srcs:
            out += "\nSources: " + srcs

    return out + _render_pipeline_tag(pipeline, debug)


def main() -> None:
    full_rows = load_full_rows()
    rag = build_rag_engine(full_rows)

    state: Dict[str, Any] = {}
    _reset_state(state)

    use_llm = True
    rewrite_csv = False
    debug = True

    print("Assistant (CSV-first + optional RAG fallback)")
    print("Commands: /debug on | /debug off | /reset | exit\n")

    while True:
        user = input("You: ").strip()
        if user.lower() in {"exit", "quit"}:
            break

        if user.lower().strip() == "/debug on":
            debug = True
            print("\nBot: Debug ON\n")
            continue
        if user.lower().strip() == "/debug off":
            debug = False
            print("\nBot: Debug OFF\n")
            continue

        res = chat_turn(user, state, full_rows, rag, debug=debug)
        out = render_answer(user, res, use_llm=use_llm, rewrite_csv=rewrite_csv, debug=debug)
        print(f"\nBot: {out}\n")


if __name__ == "__main__":
    main()