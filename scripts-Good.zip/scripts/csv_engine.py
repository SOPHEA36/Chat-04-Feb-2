# scripts/csv_engine.py
import csv
import re
import difflib
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple

# ==========================================================
# PATHS
# ==========================================================
PROJECT_ROOT = Path(__file__).resolve().parents[1]
CSV_FULL = PROJECT_ROOT / "data" / "csv" / "vehicle_master.csv"

# ==========================================================
# CONSTANTS
# ==========================================================
FUELS = {"diesel", "gasoline", "hybrid", "ev", "any"}
BODY_TYPES = {"suv", "sedan", "pickup", "bus", "mpv", "mvp", "van", "any"}

# ==========================================================
# FEATURE MAP
# ==========================================================
FEATURE_MAP: Dict[str, Dict[str, Any]] = {
    "pvm": {
        "aliases": ["pvm", "panoramic view monitor", "panoramic view", "around view monitor"],
        "columns": ["spec_panoramic_view_monitor_pvm"],
        "label": "Panoramic View Monitor (PVM)",
    },
    "camera_360": {
        "aliases": [
            "360 camera",
            "camera 360",
            "360-degree camera",
            "360° camera",
            "surround view camera",
            "surround-view camera",
            "birds eye camera",
            "bird view camera",
        ],
        "columns": [],
        "label": "360° surround-view camera",
    },
    "reverse_camera": {
        "aliases": ["reverse camera", "rear camera", "backup camera", "reversing camera"],
        "columns": ["spec_reverse_camera"],
        "label": "Reverse camera",
    },
    "adaptive_cruise": {
        "aliases": ["adaptive cruise", "acc", "drcc", "radar cruise", "dynamic radar cruise", "cruise control"],
        "columns": [
            "spec_fullspeed_range_adaptive_cruise_control_acc",
            "spec_dynamic_radar_cruise_control_drcc",
            "spec_cruise_control",
        ],
        "label": "Cruise control",
    },
    "bsm": {
        "aliases": ["blind spot", "bsm", "blind spot monitor"],
        "columns": ["spec_blind_spot_monitor_bsm"],
        "label": "Blind Spot Monitor (BSM)",
    },
    "carplay_android": {
        "aliases": ["carplay", "apple carplay", "android auto"],
        "columns": ["spec_apple_carplay_and_android_auto", "spec_apple_carplay_or_android_auto"],
        "label": "Apple CarPlay / Android Auto",
    },
    "turning_radius": {
        "aliases": [
            "turning radius",
            "minimum turning radius",
            "min turning radius",
            "turning circle",
            "minimum turning circle",
        ],
        "columns": ["spec_minimum_turning_radius_tire"],
        "label": "Minimum turning radius",
    },
    "price": {
        "aliases": ["price", "cost", "how much", "usd"],
        "columns": ["price_usd"],
        "label": "Price (USD)",
    },
}

# ==========================================================
# CSV LOAD
# ==========================================================
def load_csv(path: Path) -> List[Dict[str, Any]]:
    with path.open("r", encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def load_full_rows() -> List[Dict[str, Any]]:
    return load_csv(CSV_FULL)

# ==========================================================
# NORMALIZATION HELPERS
# ==========================================================
def normalize_model_name(s: str) -> str:
    return re.sub(r"\s+", " ", (s or "").lower().strip())


def _compact(s: str) -> str:
    return re.sub(r"[^a-z0-9]", "", (s or "").lower())


def to_int(v: Any) -> Optional[int]:
    try:
        if v is None:
            return None
        s = str(v).strip()
        if not s:
            return None
        s = s.replace(",", "")
        return int(float(s))
    except Exception:
        return None


def _squeeze_repeats(text: str) -> str:
    return re.sub(r"(.)\1{2,}", r"\1\1", text)


def _normalize_text(text: str) -> str:
    t = (text or "").lower()
    t = _squeeze_repeats(t)

    t = re.sub(r"\bseadan\b", "sedan", t)
    t = re.sub(r"\bsaloon\b", "sedan", t)
    t = re.sub(r"\bmpvs?\b", "mpv", t)
    t = re.sub(r"\bmvp\b", "mpv", t)
    t = re.sub(r"\bmini\s*van\b", "van", t)
    t = re.sub(r"\bpick[\s\-]?up\b", "pickup", t)
    t = re.sub(r"\bvan\b", "bus", t)

    t = re.sub(r"\bdisel\b", "diesel", t)
    t = re.sub(r"\bdissel\b", "diesel", t)
    t = re.sub(r"\bgazoline\b", "gasoline", t)
    t = re.sub(r"\bgasolin\b", "gasoline", t)
    t = re.sub(r"\bpetrol\b", "gasoline", t)
    t = re.sub(r"\bhybird\b", "hybrid", t)
    t = re.sub(r"\bhev\b", "hybrid", t)

    return t


def _tokenize(text: str) -> List[str]:
    t = _normalize_text(text)
    t = re.sub(r"[^a-z0-9]+", " ", t)
    t = re.sub(r"\s+", " ", t).strip()
    return t.split()

# ==========================================================
# FUZZY HELPERS
# ==========================================================
def _extract_after_of_phrase(text: str) -> Optional[str]:
    t = _normalize_text(text)
    m = re.search(r"\bof\s+([a-z0-9\s\-]+)$", t)
    if not m:
        return None
    phrase = (m.group(1) or "").strip()
    return phrase if phrase else None


def _is_explicit_model_query(text: str) -> bool:
    t = _normalize_text(text)
    return bool(re.search(r"\bof\s+[a-z0-9]", t))


def _best_fuzzy_model_match(user_text: str, full_rows: List[Dict[str, Any]]) -> Tuple[Optional[str], float]:
    t = _normalize_text(user_text)
    t_comp = _compact(t)
    if not t_comp:
        return None, 0.0

    best_model = None
    best_score = 0.0

    for r in full_rows:
        model_raw = str(r.get("model") or "")
        model_norm = normalize_model_name(model_raw)
        if not model_norm:
            continue

        m_comp = _compact(model_norm)
        if not m_comp:
            continue

        score = difflib.SequenceMatcher(None, t_comp, m_comp).ratio()
        if score > best_score:
            best_score = score
            best_model = model_norm

    return best_model, best_score

# ==========================================================
# MODEL MATCHING
# ==========================================================
def detect_model_in_text(text: str, full_rows: List[Dict[str, Any]]) -> Optional[str]:
    t_norm = normalize_model_name(_normalize_text(text))
    t_comp = _compact(t_norm)
    t_tokens = set(t_norm.split())

    best = None
    best_overlap = 0

    for r in full_rows:
        model_raw = str(r.get("model") or "")
        model_norm = normalize_model_name(model_raw)
        if not model_norm:
            continue

        if model_norm in t_norm:
            return model_norm

        m_comp = _compact(model_norm)
        if m_comp and m_comp in t_comp:
            return model_norm

        m_tokens = set(model_norm.split())
        overlap = len(m_tokens.intersection(t_tokens))
        if overlap >= 2 and overlap > best_overlap:
            best_overlap = overlap
            best = model_norm

    phrase = _extract_after_of_phrase(text)
    if phrase:
        fuzzy_best, fuzzy_score = _best_fuzzy_model_match(phrase, full_rows)
        if fuzzy_best and fuzzy_score >= 0.78:
            return fuzzy_best

    fuzzy_best, fuzzy_score = _best_fuzzy_model_match(text, full_rows)
    if fuzzy_best and fuzzy_score >= 0.82:
        return fuzzy_best

    return best


def prefer_last_model_if_close(mentioned_model_norm: Optional[str], last_model_norm: Optional[str]) -> Optional[str]:
    if not mentioned_model_norm:
        return None
    if not last_model_norm:
        return mentioned_model_norm
    if mentioned_model_norm in last_model_norm:
        return last_model_norm
    return mentioned_model_norm


def resolve_target_model(user_text: str, last_model: Optional[str], full_rows: List[Dict[str, Any]]) -> Optional[str]:
    mentioned = detect_model_in_text(user_text, full_rows)
    if mentioned:
        return prefer_last_model_if_close(mentioned, last_model)

    t = _normalize_text(user_text)

    if t.startswith(("how about", "what about")):
        rest = re.sub(r"^(how about|what about)\s+", "", t).strip()
        mentioned2 = detect_model_in_text(rest, full_rows)
        if mentioned2:
            return prefer_last_model_if_close(mentioned2, last_model)
        return None

    if _is_explicit_model_query(t):
        return None

    if any(p in t for p in ["it", "this model", "that model", "this one", "the car"]):
        return last_model

    return last_model

# ==========================================================
# FEATURE DETECTION
# ==========================================================
def detect_feature_key(text: str) -> Optional[str]:
    t = _normalize_text(text)
    for key, meta in FEATURE_MAP.items():
        for alias in meta.get("aliases", []):
            if alias in t:
                return key
    return None

# ==========================================================
# YES/NO PARSING
# ==========================================================
def yn_from_value(val: Any) -> Optional[bool]:
    if val is None:
        return None

    s = str(val).strip().lower()
    if not s:
        return None

    s = s.replace("_", " ").replace("-", " ")
    s = re.sub(r"\s+", " ", s)

    yes_values = {"yes", "true", "1", "available", "standard", "included", "present"}
    no_values = {"no", "false", "0", "not available", "na", "n/a", "none", "absent"}

    if s in yes_values or s.startswith("standard") or s.startswith("included"):
        return True
    if s in no_values or s.startswith("not"):
        return False

    return None

# ==========================================================
# CSV FEATURE ANSWERING
# ==========================================================
def find_row_by_model(full_rows: List[Dict[str, Any]], model_norm: str) -> Optional[Dict[str, Any]]:
    for r in full_rows:
        if normalize_model_name(r.get("model")) == model_norm:
            return r
    return None


def answer_feature_from_csv(full_rows: List[Dict[str, Any]], model_norm: str, feature_key: str) -> Optional[Dict[str, Any]]:
    row = find_row_by_model(full_rows, model_norm)
    if not row:
        return None

    model_name = row.get("model") or "This model"
    src = row.get("url") or ""

    meta = FEATURE_MAP.get(feature_key)
    if not meta:
        return None

    for col in meta["columns"]:
        val = row.get(col)
        if val in (None, ""):
            continue

        if feature_key == "price":
            price = to_int(val)
            if price is None:
                value = str(val).strip()
                text = f"{model_name} — Price (USD): {value}"
            else:
                value = f"${price}"
                text = f"{model_name} — Price (USD): {value}"
            return {
                "answer_type": "csv_feature",
                "text": text,
                "value": value,
                "facts": [text],
                "sources": [src] if src else [],
                "model": model_name,
                "feature": feature_key,
            }

        yn = yn_from_value(val)
        if yn is True:
            value = "Yes"
            text = f"Yes — {model_name} has {meta['label']} according to official specifications."
        elif yn is False:
            value = "No"
            text = f"No — {model_name} does not list {meta['label']} in the official specifications."
        else:
            value = str(val).strip()
            if feature_key == "turning_radius":
                text = f"{model_name} — {meta['label']}: {value}"
            else:
                text = f"{model_name}: {meta['label']} = {value}"

        return {
            "answer_type": "csv_feature",
            "text": text,
            "value": value,
            "facts": [text],
            "sources": [src] if src else [],
            "model": model_name,
            "feature": feature_key,
        }

    if feature_key == "camera_360":
        value = "No"
        text = f"No — {model_name} does not list {FEATURE_MAP['camera_360']['label']} in the official specifications we captured."
        return {
            "answer_type": "csv_feature",
            "text": text,
            "value": value,
            "facts": [text],
            "sources": [src] if src else [],
            "model": model_name,
            "feature": feature_key,
        }

    return None

# ==========================================================
# RECOMMENDATION INTENT + EXTRACTORS
# ==========================================================
def is_recommendation_intent(text: str) -> bool:
    t = _normalize_text(text)

    if re.search(r"\b(spec|specs|specification|details)\b", t):
        return False

    if extract_budget(t) is not None:
        return True
    if extract_seats(t) is not None:
        return True
    if extract_fuel(t) is not None:
        return True
    if extract_body_type(t) is not None:
        return True

    if any(k in t for k in ["recommend", "suggest", "buy", "looking for", "need a car", "budget"]):
        return True

    return False


def extract_budget(text: str) -> Optional[int]:
    m = re.search(r"\$?\s*([\d,]{4,})", text or "", flags=re.IGNORECASE)
    if not m:
        return None
    n = m.group(1).replace(",", "")
    return int(n) if n.isdigit() else None


def extract_seats(text: str) -> Optional[int]:
    m = re.search(r"(\d+)\s*(?:seat|seats|seater)\b", text or "", flags=re.IGNORECASE)
    return int(m.group(1)) if m else None


def extract_fuel(text: str) -> Optional[str]:
    tokens = set(_tokenize(text))
    if "diesel" in tokens:
        return "diesel"
    if "gasoline" in tokens:
        return "gasoline"
    if "hybrid" in tokens:
        return "hybrid"
    if "ev" in tokens or "electric" in tokens:
        return "ev"
    if "any" in tokens:
        return "any"
    return None


def extract_body_type(text: str) -> Optional[str]:
    tokens = set(_tokenize(text))
    if "sedan" in tokens:
        return "sedan"
    if "suv" in tokens:
        return "suv"
    if "pickup" in tokens:
        return "pickup"
    if "bus" in tokens:
        return "bus"
    if "mpv" in tokens:
        return "mpv"
    if "any" in tokens:
        return "any"
    return None

# ==========================================================
# RECOMMENDATION FILTERING
# ==========================================================
def _seats_value(row: Dict[str, Any]) -> Optional[int]:
    v = to_int(row.get("seats"))
    if v is not None:
        return v
    return to_int(row.get("spec_seating_capacity"))


def filter_cars_split(
    rows: List[Dict[str, Any]],
    max_budget: int,
    min_seats: int,
    fuel: str,
    body_type: str,
) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    fuel = (fuel or "any").lower().strip()
    body_type = (body_type or "any").lower().strip()

    verified: List[Dict[str, Any]] = []
    possible: List[Dict[str, Any]] = []

    for r in rows:
        price = to_int(r.get("price_usd"))
        if price is None or price > max_budget:
            continue

        row_fuel = (r.get("fuel") or "").lower().strip()
        row_body = (r.get("body_type") or "").lower().strip()

        if fuel != "any" and row_fuel != fuel:
            continue
        if body_type != "any" and row_body != body_type:
            continue

        seats_val = _seats_value(r)
        if seats_val is None:
            possible.append(r)
            continue
        if seats_val < min_seats:
            continue

        verified.append(r)

    verified.sort(key=lambda x: to_int(x.get("price_usd")) or 10**12)
    possible.sort(key=lambda x: to_int(x.get("price_usd")) or 10**12)
    return verified, possible


def build_reco_answer(
    verified: List[Dict[str, Any]],
    possible: List[Dict[str, Any]],
    max_items: int = 5,
) -> Dict[str, Any]:
    if not verified and not possible:
        return {
            "answer_type": "csv_reco",
            "text": "I couldn't find an official match with those constraints. Try increasing budget, lowering seats, changing body type, or using fuel = Any.",
            "facts": [],
            "sources": [],
        }

    lines: List[str] = []
    sources: List[str] = []

    if verified:
        lines.append("Based on your requirements, here are official matches:\n")
        for m in verified[:max_items]:
            brand = m.get("brand", "")
            model = m.get("model", "")
            price = m.get("price_usd", "")
            seats_val = _seats_value(m)
            seats_txt = str(seats_val) if seats_val is not None else "N/A"
            f = m.get("fuel", "")
            body = m.get("body_type", "")
            url = m.get("url", "")

            lines.append(f"- {brand} {model} (${price}), seats={seats_txt}, fuel={f}, body={body}")
            if url:
                sources.append(url)

    if possible:
        if lines:
            lines.append("")
        lines.append("Possible matches (some required fields are N/A in CSV):\n")
        for m in possible[:max_items]:
            brand = m.get("brand", "")
            model = m.get("model", "")
            price = m.get("price_usd", "")
            seats_val = _seats_value(m)
            seats_txt = str(seats_val) if seats_val is not None else "N/A"
            f = m.get("fuel", "")
            body = m.get("body_type", "")
            url = m.get("url", "")

            lines.append(f"- {brand} {model} (${price}), seats={seats_txt}, fuel={f}, body={body}")
            if url:
                sources.append(url)

    return {"answer_type": "csv_reco", "text": "\n".join(lines).strip(), "facts": [], "sources": sources}

# ==========================================================
# SUMMARY INTENT (SAFETY)
# ==========================================================
def is_summary_intent(text: str) -> bool:
    t = _normalize_text(text)
    keys = [
        "safety system", "safety systems", "safety feature", "safety features",
        "safety", "adas", "driver assist", "driver assistance", "toyota safety sense", "tss",
    ]
    return any(k in t for k in keys)


def _yn_label(val: Any) -> str:
    yn = yn_from_value(val)
    if yn is True:
        return "Yes"
    if yn is False:
        return "No"
    s = str(val).strip() if val is not None else ""
    return s if s else "N/A"


def _build_safety_summary(row: Dict[str, Any]) -> List[str]:
    lines: List[str] = []

    def add(label: str, col: str):
        v = row.get(col)
        if v not in (None, ""):
            lines.append(f"- {label}: {_yn_label(v)}")

    add("ABS", "spec_antilock_braking_system_abs")
    add("Vehicle Stability Control (VSC)", "spec_vehicle_stability_control_vsc")
    add("SRS Airbags", "spec_srs_airbags")
    add("Blind Spot Monitor (BSM)", "spec_blind_spot_monitor_bsm")
    add("Lane Departure Warning (LDW)", "spec_lane_departure_warning_ldw")
    add("Lane Keeping Control (LKC)", "spec_lane_keeping_control_lkc")
    add("Pre-Collision Warning (PCW)", "spec_precollision_warning_pcw")
    add("Pre-Collision Braking (PCB)", "spec_precollision_braking_pcb")
    add("Reverse camera", "spec_reverse_camera")
    add("Panoramic View Monitor (PVM)", "spec_panoramic_view_monitor_pvm")

    sr = str(row.get("spec_safety_rating") or "").strip()
    if sr:
        lines.append(f"- Safety rating: {sr}")

    return lines


def answer_summary_from_csv(full_rows: List[Dict[str, Any]], model_norm: str) -> Optional[Dict[str, Any]]:
    row = find_row_by_model(full_rows, model_norm)
    if not row:
        return None

    model_name = row.get("model") or "This model"
    src = row.get("url") or ""

    lines = _build_safety_summary(row)
    if not lines:
        text = f"I couldn't find structured safety fields for {model_name} in the CSV."
    else:
        text = f"{model_name} — Safety systems (from official CSV):\n" + "\n".join(lines)

    return {
        "answer_type": "csv_summary",
        "text": text,
        "facts": [text],
        "sources": [src] if src else [],
        "model": model_name,
        "summary_type": "safety",
    }