# scripts/chat_assistant.py
from typing import Dict, Any, List, Optional, Tuple
import re

from scripts.csv_engine import (
    load_full_rows,
    detect_feature_key,
    detect_model_in_text,
    resolve_target_model,
    answer_feature_from_csv,
    is_recommendation_intent,
    extract_budget,
    extract_seats,
    extract_fuel,
    extract_body_type,
    filter_cars_split,
    build_reco_answer,
    is_summary_intent,
    answer_summary_from_csv,
    find_row_by_model,
    to_int,
)
from scripts.llm_client import llm_rewrite
from scripts.rag_engine import RAGEngine


def _is_small_talk(text: str) -> bool:
    t = (text or "").strip().lower()
    return t in {"hi", "hello", "hey", "hii", "hallo"} or t.startswith(("hi ", "hello ", "hey "))


def _small_talk_reply() -> Dict[str, Any]:
    text = (
        "Hi! I can help you with:\n"
        "- Recommend Toyota models by budget + fuel + seats + body type\n"
        "- Answer quick questions (turning radius, price, CarPlay/Android Auto, BSM, PVM, reverse camera, cruise control)\n"
        "- Summarize safety systems if available\n"
        "Example: budget 50000 gasoline 5 seats suv"
    )
    return {"answer_type": "system", "text": text, "facts": [], "sources": []}


def _is_yes(text: str) -> bool:
    t = (text or "").strip().lower()
    return t in {"yes", "y", "ok", "okay", "sure", "pls", "please"}


def _normalize_yesno_value(v: str) -> str:
    s = (v or "").strip()
    lv = s.lower()
    if lv in {"yes", "true", "1", "included", "standard", "present", "available"}:
        return "Yes"
    if lv in {"no", "false", "0", "not available", "n/a", "na", "none", "absent"}:
        return "No"
    return s if s else "N/A"


def _feature_value(full_rows, model_norm: str, key: str) -> str:
    res = answer_feature_from_csv(full_rows, model_norm, key)
    if not res:
        return "N/A"
    v = res.get("value")
    if v is None:
        return "N/A"
    return _normalize_yesno_value(str(v))


def _compare_models_from_csv(full_rows, model_a_norm: str, model_b_norm: str) -> Optional[Dict[str, Any]]:
    row_a = find_row_by_model(full_rows, model_a_norm)
    row_b = find_row_by_model(full_rows, model_b_norm)
    if not row_a or not row_b:
        return None

    model_a = row_a.get("model") or model_a_norm
    model_b = row_b.get("model") or model_b_norm

    src_a = row_a.get("url") or ""
    src_b = row_b.get("url") or ""

    keys = ["price", "turning_radius", "carplay_android", "reverse_camera", "pvm", "bsm", "adaptive_cruise"]
    label_map = {
        "price": "Price (USD)",
        "turning_radius": "Minimum turning radius",
        "carplay_android": "Apple CarPlay / Android Auto",
        "reverse_camera": "Reverse camera",
        "pvm": "Panoramic View Monitor (PVM)",
        "bsm": "Blind Spot Monitor (BSM)",
        "adaptive_cruise": "Cruise control",
    }

    diffs: List[str] = []
    same: List[str] = []

    for k in keys:
        label = label_map.get(k, k.replace("_", " ").title())
        a_show = _feature_value(full_rows, model_a_norm, k)
        b_show = _feature_value(full_rows, model_b_norm, k)
        line = f"- {label}: {a_show} vs {b_show}"
        if a_show.strip().lower() == b_show.strip().lower():
            same.append(line)
        else:
            diffs.append(line)

    lines: List[str] = []
    lines.append("Here’s a quick comparison (official specs):")
    lines.append(f"{model_a} vs {model_b}")

    if diffs:
        lines.append("")
        lines.append("Key differences:")
        lines.extend(diffs)

    if same:
        lines.append("")
        lines.append("Same on both models:")
        lines.extend(same)

    lines.append("")
    lines.append("If you tell me your budget and main usage (city/highway), I can suggest which one fits you better.")

    sources: List[str] = []
    if src_a:
        sources.append(src_a)
    if src_b and src_b not in sources:
        sources.append(src_b)

    text = "\n".join(lines).strip()
    return {"answer_type": "csv_compare", "text": text, "facts": [text], "sources": sources}


def _suggest_models_near_same_type(
    full_rows,
    base_model_norm: str,
    max_items: int = 3,
    max_price_gap_usd: int = 15000,
) -> List[str]:
    """
    Suggest comparison models:
    - same body_type as base (SUV -> SUV)
    - closest price to base
    - within max_price_gap_usd (so no random pickup/bus)
    """
    base_row = find_row_by_model(full_rows, base_model_norm)
    if not base_row:
        return []

    base_body = (base_row.get("body_type") or "").strip().lower()
    base_price = to_int(base_row.get("price_usd"))
    if not base_body or base_price is None:
        return []

    candidates: List[Tuple[int, str]] = []
    for r in full_rows:
        m = str(r.get("model") or "").strip()
        if not m:
            continue

        m_norm = str(r.get("model") or "").lower().strip()
        if m_norm == base_model_norm:
            continue

        body = (r.get("body_type") or "").strip().lower()
        if body != base_body:
            continue

        p = to_int(r.get("price_usd"))
        if p is None:
            continue

        diff = abs(p - base_price)
        if diff > max_price_gap_usd:
            continue

        candidates.append((diff, m))

    candidates.sort(key=lambda x: x[0])
    return [c[1] for c in candidates[:max_items]]


def chat_turn(user_text: str, state: Dict[str, Any], full_rows, rag: RAGEngine) -> Dict[str, Any]:
    user_text = (user_text or "").strip()
    if not user_text:
        return {"answer_type": "system", "text": "Please type a question or your requirements.", "facts": [], "sources": []}

    if _is_small_talk(user_text):
        return _small_talk_reply()

    pending = state.get("pending_compare") or {}
    if pending.get("awaiting") is True:
        base_norm = pending.get("base_model_norm")

        if base_norm and _is_yes(user_text):
            suggestions = _suggest_models_near_same_type(full_rows, base_norm, max_items=3, max_price_gap_usd=15000)
            if suggestions:
                txt = "Sure. Which model would you like to compare with? For example: " + ", ".join(suggestions) + "."
            else:
                txt = "Sure. Which model would you like to compare with? Please type the model name."
            return {"answer_type": "system", "text": txt, "facts": [], "sources": []}

        user_text_clean = re.sub(r"[^\w\s\-]", " ", user_text)
        user_text_clean = " ".join(user_text_clean.split()).strip()
        target_norm = detect_model_in_text(user_text_clean, full_rows)

        if not base_norm:
            state["pending_compare"] = {"awaiting": False, "base_model_norm": None}
            return {"answer_type": "system", "text": "I lost the model to compare. Please ask again with a model name.", "facts": [], "sources": []}

        if not target_norm:
            return {
                "answer_type": "system",
                "text": "I can’t find that model name in my official list. Please type the model name again (example: Corolla Cross HEV).",
                "facts": [],
                "sources": [],
            }

        if target_norm == base_norm:
            return {"answer_type": "system", "text": "That’s the same model. Please choose a different model to compare.", "facts": [], "sources": []}

        res = _compare_models_from_csv(full_rows, base_norm, target_norm)
        state["pending_compare"] = {"awaiting": False, "base_model_norm": None}
        if res:
            return res

        return {"answer_type": "system", "text": "I couldn’t build the comparison from CSV.", "facts": [], "sources": []}

    mentioned_model = detect_model_in_text(user_text, full_rows)
    if mentioned_model:
        state["last_model"] = mentioned_model

    model_norm = resolve_target_model(user_text, state.get("last_model"), full_rows)
    if model_norm:
        state["last_model"] = model_norm

    if is_summary_intent(user_text) and model_norm:
        csv_sum = answer_summary_from_csv(full_rows, model_norm)
        if csv_sum:
            return csv_sum

    if is_recommendation_intent(user_text):
        b = extract_budget(user_text)
        s = extract_seats(user_text)
        f = extract_fuel(user_text)
        bt = extract_body_type(user_text)

        if b is not None:
            state["slots"]["max_budget"] = b
        if s is not None:
            state["slots"]["min_seats"] = s
        if f is not None:
            state["slots"]["fuel"] = f
        if bt is not None:
            state["slots"]["body_type"] = bt

        missing = []
        if state["slots"]["max_budget"] is None:
            missing.append("maximum budget (USD)")
        if state["slots"]["min_seats"] is None:
            missing.append("minimum seats")
        if state["slots"]["fuel"] is None:
            missing.append("fuel (Diesel/Gasoline/Hybrid/EV/Any)")
        if state["slots"]["body_type"] is None:
            missing.append("body type (SUV/Sedan/MPV/Pickup/Bus/Any)")

        if missing:
            return {
                "answer_type": "csv_reco",
                "text": "To recommend from official data, please tell me: " + ", ".join(missing) + ".",
                "facts": [],
                "sources": [],
            }

        max_budget = state["slots"]["max_budget"]
        min_seats = state["slots"]["min_seats"]
        fuel = state["slots"]["fuel"]
        body_type = state["slots"]["body_type"]

        verified, possible = filter_cars_split(full_rows, max_budget, min_seats, fuel, body_type)
        ans = build_reco_answer(verified, possible, max_items=5)

        if verified:
            state["last_model"] = (verified[0].get("model") or "").lower().strip() or state.get("last_model")
        elif possible:
            state["last_model"] = (possible[0].get("model") or "").lower().strip() or state.get("last_model")

        state["slots"] = {"max_budget": None, "min_seats": None, "fuel": None, "body_type": None}
        return ans

    feature_key = detect_feature_key(user_text)
    if feature_key and model_norm:
        csv_res = answer_feature_from_csv(full_rows, model_norm, feature_key)
        if csv_res:
            if feature_key == "turning_radius":
                state["pending_compare"] = {"awaiting": True, "base_model_norm": model_norm}
                csv_res = dict(csv_res)
                csv_res["text"] = (csv_res.get("text", "") + "\nWould you like to compare it with another SUV in a similar price range?").strip()
            return csv_res

    return rag.rag_answer(user_text, last_model_norm=state.get("last_model"))


def render_answer(user_text: str, res: Dict[str, Any], use_llm: bool) -> str:
    text = (res.get("text") or "").strip()
    facts = res.get("facts") or []
    sources = res.get("sources") or []

    if not text:
        text = "I couldn't produce an answer."

    if res.get("answer_type") in {"csv_feature", "csv_reco", "csv_summary", "csv_compare"}:
        if sources:
            return text + "\nSources: " + ", ".join(sources)
        return text

    if use_llm:
        return llm_rewrite(user_text, text, facts, sources)

    if sources:
        return text + " Sources: " + ", ".join(sources)
    return text


def main():
    full_rows = load_full_rows()
    rag = RAGEngine(full_rows)

    state: Dict[str, Any] = {
        "last_model": None,
        "slots": {"max_budget": None, "min_seats": None, "fuel": None, "body_type": None},
        "pending_compare": {"awaiting": False, "base_model_norm": None},
    }

    use_llm = True

    print("Car Assistant (CSV-first + Recommendation + RAG fallback + LLM rewrite)")
    print("Type 'exit' to quit.\n")

    while True:
        user = input("You: ").strip()
        if user.lower() in {"exit", "quit"}:
            break

        res = chat_turn(user, state, full_rows, rag)
        out = render_answer(user, res, use_llm=use_llm)
        print(f"\nBot: {out}\n")


if __name__ == "__main__":
    main()