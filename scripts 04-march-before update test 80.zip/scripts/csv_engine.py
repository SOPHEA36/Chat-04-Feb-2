# # # # csv_engine.py
# # # import csv
# # # import re
# # # import difflib
# # # from pathlib import Path
# # # from typing import Dict, Any, List, Optional, Tuple
# # #
# # # PROJECT_ROOT = Path(__file__).resolve().parents[1]
# # # CSV_FULL = PROJECT_ROOT / "data" / "csv" / "vehicle_master.csv"
# # #
# # # FUELS = {"diesel", "gasoline", "hybrid", "ev", "any"}
# # # BODY_TYPES = {"suv", "sedan", "pickup", "bus", "mpv", "mvp", "van", "hatchback", "any"}
# # #
# # # MODEL_STOP_TOKENS = {
# # #     "hev", "hybrid", "electric", "ev",
# # #     "gasoline", "diesel",
# # #     "mt", "at", "manual", "automatic", "transmission",
# # #     "edition", "legender", "rally", "gr", "gr-s", "zx", "vx", "vxr",
# # #     "seater", "seaters",
# # # }
# # #
# # # MODEL_ALIASES: Dict[str, str] = {
# # #     "vigo": "wigo",
# # #     "viggo": "wigo",
# # #     "wiggo": "wigo",
# # # }
# # #
# # # FEATURE_MAP: Dict[str, Dict[str, Any]] = {
# # #     "pvm": {
# # #         "aliases": ["pvm", "panoramic view monitor", "panoramic view", "around view monitor"],
# # #         "columns": ["spec_panoramic_view_monitor_pvm"],
# # #         "label": "Panoramic View Monitor (PVM)",
# # #     },
# # #     "camera_360": {
# # #         "aliases": [
# # #             "360 camera", "camera 360", "360-degree camera", "360° camera",
# # #             "surround view camera", "surround-view camera",
# # #             "birds eye camera", "bird view camera",
# # #         ],
# # #         "columns": [],
# # #         "label": "360° surround-view camera",
# # #     },
# # #     "reverse_camera": {
# # #         "aliases": ["reverse camera", "rear camera", "backup camera", "reversing camera"],
# # #         "columns": ["spec_reverse_camera"],
# # #         "label": "Reverse camera",
# # #     },
# # #     "adaptive_cruise": {
# # #         "aliases": ["adaptive cruise", "acc", "drcc", "radar cruise", "dynamic radar cruise", "cruise control"],
# # #         "columns": [
# # #             "spec_fullspeed_range_adaptive_cruise_control_acc",
# # #             "spec_dynamic_radar_cruise_control_drcc",
# # #             "spec_cruise_control",
# # #         ],
# # #         "label": "Cruise control",
# # #     },
# # #     "bsm": {
# # #         "aliases": ["blind spot", "bsm", "blind spot monitor"],
# # #         "columns": ["spec_blind_spot_monitor_bsm"],
# # #         "label": "Blind Spot Monitor (BSM)",
# # #     },
# # #     "carplay_android": {
# # #         "aliases": ["carplay", "apple carplay", "android auto"],
# # #         "columns": ["spec_apple_carplay_and_android_auto", "spec_apple_carplay_or_android_auto"],
# # #         "label": "Apple CarPlay / Android Auto",
# # #     },
# # #     "turning_radius": {
# # #         "aliases": [
# # #             "turning radius", "minimum turning radius", "min turning radius",
# # #             "turning circle", "minimum turning circle",
# # #         ],
# # #         "columns": ["spec_minimum_turning_radius_tire"],
# # #         "label": "Minimum turning radius",
# # #     },
# # #     "wireless_charging": {
# # #         "aliases": ["wireless charging", "wireless charger", "qi", "charging pad"],
# # #         "columns": ["spec_wireless_charging", "spec_wireless_charger", "spec_wireless_charging", "spec_wireless_charger"],
# # #         "label": "Wireless charging",
# # #     },
# # #     "ambient_lighting": {
# # #         "aliases": ["ambient lighting", "ambient light", "mood lighting"],
# # #         "columns": ["spec_ambient_lighting", "Ambient lighting"],
# # #         "label": "Ambient lighting",
# # #     },
# # #     "price": {
# # #         "aliases": ["price", "cost", "how much", "selling price", "usd", "$"],
# # #         "columns": ["price_usd"],
# # #         "label": "Price (USD)",
# # #     },
# # # }
# # #
# # # def load_csv(path: Path) -> List[Dict[str, Any]]:
# # #     with path.open("r", encoding="utf-8", newline="") as f:
# # #         return list(csv.DictReader(f))
# # #
# # # def load_full_rows() -> List[Dict[str, Any]]:
# # #     return load_csv(CSV_FULL)
# # #
# # # def normalize_model_name(s: str) -> str:
# # #     return re.sub(r"\s+", " ", (s or "").lower().strip())
# # #
# # # def _compact(s: str) -> str:
# # #     return re.sub(r"[^a-z0-9]", "", (s or "").lower())
# # #
# # # def to_int(v: Any) -> Optional[int]:
# # #     try:
# # #         if v is None:
# # #             return None
# # #         s = str(v).strip()
# # #         if not s:
# # #             return None
# # #         s = s.replace(",", "")
# # #         return int(float(s))
# # #     except Exception:
# # #         return None
# # #
# # # def format_price_usd(v: Any) -> str:
# # #     n = to_int(v)
# # #     if n is None:
# # #         s = str(v).strip() if v is not None else ""
# # #         return s if s else "N/A"
# # #     return f"${n:,}"
# # #
# # # def _squeeze_repeats(text: str) -> str:
# # #     return re.sub(r"(.)\1{2,}", r"\1\1", text)
# # #
# # # def _normalize_text(text: str) -> str:
# # #     t = (text or "").lower()
# # #     t = _squeeze_repeats(t)
# # #
# # #     t = re.sub(r"\bseadan\b", "sedan", t)
# # #     t = re.sub(r"\bsaloon\b", "sedan", t)
# # #     t = re.sub(r"\bmpvs?\b", "mpv", t)
# # #     t = re.sub(r"\bmvp\b", "mpv", t)
# # #     t = re.sub(r"\bmini\s*van\b", "van", t)
# # #     t = re.sub(r"\bpick[\s\-]?up\b", "pickup", t)
# # #     t = re.sub(r"\bvan\b", "bus", t)
# # #
# # #     t = re.sub(r"\bdisel\b", "diesel", t)
# # #     t = re.sub(r"\bdissel\b", "diesel", t)
# # #     t = re.sub(r"\bgazoline\b", "gasoline", t)
# # #     t = re.sub(r"\bgasolin\b", "gasoline", t)
# # #     t = re.sub(r"\bpetrol\b", "gasoline", t)
# # #     t = re.sub(r"\bhybird\b", "hybrid", t)
# # #     t = re.sub(r"\bhev\b", "hybrid", t)
# # #
# # #     return t
# # #
# # # def _tokenize(text: str) -> List[str]:
# # #     t = _normalize_text(text)
# # #     t = re.sub(r"[^a-z0-9]+", " ", t)
# # #     t = re.sub(r"\s+", " ", t).strip()
# # #     return t.split()
# # #
# # # def _model_tokens(model_norm: str) -> List[str]:
# # #     return [t for t in re.split(r"\s+", (model_norm or "").strip()) if t]
# # #
# # # def _base_model_tokens(model_norm: str) -> List[str]:
# # #     toks = _model_tokens(model_norm)
# # #     base = [t for t in toks if t not in MODEL_STOP_TOKENS]
# # #     return base if base else toks
# # #
# # # def _extract_after_of_phrase(text: str) -> Optional[str]:
# # #     t = _normalize_text(text)
# # #     m = re.search(r"\bof\s+([a-z0-9\s\-]+)$", t)
# # #     if not m:
# # #         return None
# # #     phrase = (m.group(1) or "").strip()
# # #     return phrase if phrase else None
# # #
# # # def _best_fuzzy_model_match(user_text: str, full_rows: List[Dict[str, Any]]) -> Tuple[Optional[str], float]:
# # #     t = _normalize_text(user_text)
# # #     t_comp = _compact(t)
# # #     if not t_comp:
# # #         return None, 0.0
# # #
# # #     best_model = None
# # #     best_score = 0.0
# # #
# # #     for r in full_rows:
# # #         model_norm = normalize_model_name(str(r.get("model") or ""))
# # #         if not model_norm:
# # #             continue
# # #         m_comp = _compact(model_norm)
# # #         if not m_comp:
# # #             continue
# # #         score = difflib.SequenceMatcher(None, t_comp, m_comp).ratio()
# # #         if score > best_score:
# # #             best_score = score
# # #             best_model = model_norm
# # #
# # #     return best_model, best_score
# # #
# # # def find_row_by_model(full_rows: List[Dict[str, Any]], model_norm: str) -> Optional[Dict[str, Any]]:
# # #     for r in full_rows:
# # #         if normalize_model_name(r.get("model")) == model_norm:
# # #             return r
# # #     return None
# # #
# # # def _row_fuel(row: Dict[str, Any]) -> str:
# # #     return (row.get("fuel") or "").strip().lower()
# # #
# # # def _pick_best_variant(
# # #     candidates: List[Tuple[str, Dict[str, Any]]],
# # #     user_fuel_pref: Optional[str],
# # # ) -> Optional[str]:
# # #     if not candidates:
# # #         return None
# # #
# # #     if user_fuel_pref and user_fuel_pref in FUELS and user_fuel_pref != "any":
# # #         filtered = [c for c in candidates if _row_fuel(c[1]) == user_fuel_pref]
# # #         if filtered:
# # #             candidates = filtered
# # #
# # #     candidates_sorted = sorted(
# # #         candidates,
# # #         key=lambda x: (to_int(x[1].get("price_usd")) if to_int(x[1].get("price_usd")) is not None else 10**12)
# # #     )
# # #     return candidates_sorted[0][0]
# # #
# # # def extract_budget(text: str) -> Optional[int]:
# # #     m = re.search(r"\$?\s*([\d,]{4,})", text or "", flags=re.IGNORECASE)
# # #     if not m:
# # #         return None
# # #     n = m.group(1).replace(",", "")
# # #     return int(n) if n.isdigit() else None
# # #
# # # def extract_seats(text: str) -> Optional[int]:
# # #     m = re.search(r"(\d+)\s*(?:seat|seats|seater)\b", text or "", flags=re.IGNORECASE)
# # #     return int(m.group(1)) if m else None
# # #
# # # def extract_fuel(text: str) -> Optional[str]:
# # #     tokens = set(_tokenize(text))
# # #     if "diesel" in tokens:
# # #         return "diesel"
# # #     if "gasoline" in tokens:
# # #         return "gasoline"
# # #     if "hybrid" in tokens:
# # #         return "hybrid"
# # #     if "ev" in tokens or "electric" in tokens:
# # #         return "ev"
# # #     if "any" in tokens:
# # #         return "any"
# # #     return None
# # #
# # # def extract_body_type(text: str) -> Optional[str]:
# # #     tokens = set(_tokenize(text))
# # #     if "sedan" in tokens:
# # #         return "sedan"
# # #     if "suv" in tokens:
# # #         return "suv"
# # #     if "pickup" in tokens:
# # #         return "pickup"
# # #     if "bus" in tokens:
# # #         return "bus"
# # #     if "mpv" in tokens:
# # #         return "mpv"
# # #     if "hatchback" in tokens:
# # #         return "hatchback"
# # #     if "any" in tokens:
# # #         return "any"
# # #     return None
# # #
# # # def detect_feature_key(text: str) -> Optional[str]:
# # #     t = _normalize_text(text)
# # #     for key, meta in FEATURE_MAP.items():
# # #         for alias in meta.get("aliases", []):
# # #             if alias in t:
# # #                 return key
# # #     return None
# # #
# # # def _apply_model_aliases(text_norm: str) -> str:
# # #     toks = _tokenize(text_norm)
# # #     for tok in toks:
# # #         if tok in MODEL_ALIASES:
# # #             return MODEL_ALIASES[tok]
# # #     return ""
# # #
# # # def _find_rows_by_base_name(full_rows: List[Dict[str, Any]], base_norm: str) -> List[Tuple[str, Dict[str, Any]]]:
# # #     out: List[Tuple[str, Dict[str, Any]]] = []
# # #     base_norm = normalize_model_name(base_norm)
# # #     if not base_norm:
# # #         return out
# # #     base_tokens = set(_tokenize(base_norm))
# # #     for r in full_rows:
# # #         model_norm = normalize_model_name(str(r.get("model") or ""))
# # #         if not model_norm:
# # #             continue
# # #         btoks = set(_base_model_tokens(model_norm))
# # #         if btoks and btoks.issubset(base_tokens):
# # #             out.append((model_norm, r))
# # #     return out
# # #
# # # def detect_model_in_text(text: str, full_rows: List[Dict[str, Any]]) -> Optional[str]:
# # #     t_norm = normalize_model_name(_normalize_text(text))
# # #     t_comp = _compact(t_norm)
# # #     t_tokens = set(t_norm.split())
# # #
# # #     user_fuel_pref = extract_fuel(t_norm)
# # #
# # #     alias_base = _apply_model_aliases(t_norm)
# # #     if alias_base:
# # #         candidates = _find_rows_by_base_name(full_rows, alias_base)
# # #         picked = _pick_best_variant(candidates, user_fuel_pref)
# # #         if picked:
# # #             return picked
# # #
# # #     best_exact = None
# # #     best_overlap = 0
# # #     base_candidates: List[Tuple[str, Dict[str, Any]]] = []
# # #
# # #     for r in full_rows:
# # #         model_raw = str(r.get("model") or "")
# # #         model_norm = normalize_model_name(model_raw)
# # #         if not model_norm:
# # #             continue
# # #
# # #         if model_norm in t_norm:
# # #             return model_norm
# # #
# # #         m_comp = _compact(model_norm)
# # #         if m_comp and m_comp in t_comp:
# # #             return model_norm
# # #
# # #         m_tokens = set(_model_tokens(model_norm))
# # #         overlap = len(m_tokens.intersection(t_tokens))
# # #         if overlap >= 2 and overlap > best_overlap:
# # #             best_overlap = overlap
# # #             best_exact = model_norm
# # #
# # #         base_tokens = _base_model_tokens(model_norm)
# # #         if base_tokens and all(bt in t_tokens for bt in base_tokens):
# # #             base_candidates.append((model_norm, r))
# # #
# # #     picked = _pick_best_variant(base_candidates, user_fuel_pref)
# # #     if picked:
# # #         return picked
# # #
# # #     phrase = _extract_after_of_phrase(text)
# # #     if phrase:
# # #         fuzzy_best, fuzzy_score = _best_fuzzy_model_match(phrase, full_rows)
# # #         if fuzzy_best and fuzzy_score >= 0.80:
# # #             return fuzzy_best
# # #
# # #     fuzzy_best, fuzzy_score = _best_fuzzy_model_match(text, full_rows)
# # #     if fuzzy_best and fuzzy_score >= 0.86:
# # #         return fuzzy_best
# # #
# # #     return best_exact
# # #
# # # def _base_key(model_norm: str) -> str:
# # #     base = _base_model_tokens(model_norm)
# # #     return " ".join(base)
# # #
# # # def _pick_variant_for_base(
# # #     full_rows: List[Dict[str, Any]],
# # #     base_phrase: str,
# # #     user_fuel_pref: Optional[str],
# # # ) -> Optional[str]:
# # #     candidates = _find_rows_by_base_name(full_rows, base_phrase)
# # #     return _pick_best_variant(candidates, user_fuel_pref)
# # #
# # # def detect_models_in_text(text: str, full_rows: List[Dict[str, Any]], max_models: int = 3) -> List[str]:
# # #     t_norm = normalize_model_name(_normalize_text(text))
# # #     t_comp = _compact(t_norm)
# # #     t_tokens = set(t_norm.split())
# # #     user_fuel_pref = extract_fuel(t_norm)
# # #
# # #     found: List[Tuple[int, str]] = []
# # #     seen_models = set()
# # #     seen_base = set()
# # #
# # #     def add_model(model_norm: str, pos: int):
# # #         if not model_norm:
# # #             return
# # #         if model_norm in seen_models:
# # #             return
# # #         found.append((pos, model_norm))
# # #         seen_models.add(model_norm)
# # #
# # #     alias_base = _apply_model_aliases(t_norm)
# # #     if alias_base:
# # #         picked = _pick_variant_for_base(full_rows, alias_base, user_fuel_pref)
# # #         if picked:
# # #             pos = t_norm.find(alias_base) if alias_base else 10**9
# # #             add_model(picked, pos)
# # #
# # #     for r in full_rows:
# # #         model_norm = normalize_model_name(str(r.get("model") or ""))
# # #         if not model_norm:
# # #             continue
# # #
# # #         if model_norm in t_norm:
# # #             add_model(model_norm, t_norm.find(model_norm))
# # #         else:
# # #             m_comp = _compact(model_norm)
# # #             if m_comp and m_comp in t_comp:
# # #                 add_model(model_norm, t_comp.find(m_comp))
# # #
# # #         if len(found) >= max_models:
# # #             break
# # #
# # #     if len(found) < max_models:
# # #         parts = re.split(r"\b(?:and|,|&|vs|versus)\b", t_norm)
# # #         for p in parts:
# # #             p = p.strip()
# # #             if not p:
# # #                 continue
# # #             m = detect_model_in_text(p, full_rows)
# # #             if m:
# # #                 pos = t_norm.find(p)
# # #                 add_model(m, pos if pos >= 0 else 10**8)
# # #             if len(found) >= max_models:
# # #                 break
# # #
# # #     if len(found) < max_models:
# # #         base_candidates: List[Tuple[int, str]] = []
# # #
# # #         for r in full_rows:
# # #             model_norm = normalize_model_name(str(r.get("model") or ""))
# # #             if not model_norm:
# # #                 continue
# # #
# # #             base_phrase = _base_key(model_norm)
# # #             if not base_phrase:
# # #                 continue
# # #
# # #             if base_phrase in seen_base:
# # #                 continue
# # #
# # #             base_tokens = set(base_phrase.split())
# # #             if base_tokens and base_tokens.issubset(t_tokens):
# # #                 pos = 10**8
# # #                 first_tok = base_phrase.split()[0]
# # #                 i = t_norm.find(first_tok)
# # #                 if i >= 0:
# # #                     pos = i
# # #
# # #                 picked = _pick_variant_for_base(full_rows, base_phrase, user_fuel_pref)
# # #                 if picked:
# # #                     base_candidates.append((pos, picked))
# # #                     seen_base.add(base_phrase)
# # #
# # #         base_candidates.sort(key=lambda x: x[0])
# # #         for pos, picked in base_candidates:
# # #             add_model(picked, pos)
# # #             if len(found) >= max_models:
# # #                 break
# # #
# # #     found.sort(key=lambda x: x[0])
# # #     return [m for _, m in found[:max_models]]
# # #
# # # def prefer_last_model_if_close(mentioned_model_norm: Optional[str], last_model_norm: Optional[str]) -> Optional[str]:
# # #     if not mentioned_model_norm:
# # #         return None
# # #     if not last_model_norm:
# # #         return mentioned_model_norm
# # #     if mentioned_model_norm in last_model_norm:
# # #         return last_model_norm
# # #     return mentioned_model_norm
# # #
# # # def resolve_target_model(user_text: str, last_model: Optional[str], full_rows: List[Dict[str, Any]]) -> Optional[str]:
# # #     mentioned = detect_model_in_text(user_text, full_rows)
# # #     if mentioned:
# # #         return prefer_last_model_if_close(mentioned, last_model)
# # #
# # #     t = _normalize_text(user_text)
# # #
# # #     if t.startswith(("how about", "what about")):
# # #         rest = re.sub(r"^(how about|what about)\s+", "", t).strip()
# # #         mentioned2 = detect_model_in_text(rest, full_rows)
# # #         if mentioned2:
# # #             return prefer_last_model_if_close(mentioned2, last_model)
# # #         return None
# # #
# # #     if any(p in t for p in ["it", "this model", "that model", "this one", "the car"]):
# # #         return last_model
# # #
# # #     return last_model
# # #
# # # def yn_from_value(val: Any) -> Optional[bool]:
# # #     if val is None:
# # #         return None
# # #     s = str(val).strip().lower()
# # #     if not s:
# # #         return None
# # #     s = s.replace("_", " ").replace("-", " ")
# # #     s = re.sub(r"\s+", " ", s)
# # #
# # #     yes_values = {"yes", "true", "1", "available", "standard", "included", "present"}
# # #     no_values = {"no", "false", "0", "not available", "na", "n/a", "none", "absent"}
# # #
# # #     if s in yes_values or s.startswith("standard") or s.startswith("included"):
# # #         return True
# # #     if s in no_values or s.startswith("not"):
# # #         return False
# # #     return None
# # #
# # # def yn_label(val: Any) -> str:
# # #     yn = yn_from_value(val)
# # #     if yn is True:
# # #         return "Yes"
# # #     if yn is False:
# # #         return "No"
# # #     s = str(val).strip() if val is not None else ""
# # #     return s if s else "N/A"
# # #
# # # def answer_feature_from_csv(
# # #     full_rows: List[Dict[str, Any]],
# # #     model_norm: str,
# # #     feature_key: str,
# # # ) -> Optional[Dict[str, Any]]:
# # #     row = find_row_by_model(full_rows, model_norm)
# # #     if not row:
# # #         return None
# # #
# # #     model_name = row.get("model") or "This model"
# # #     src = row.get("url") or ""
# # #
# # #     meta = FEATURE_MAP.get(feature_key)
# # #     if not meta:
# # #         return None
# # #
# # #     for col in meta.get("columns", []):
# # #         val = row.get(col)
# # #         if val in (None, ""):
# # #             continue
# # #
# # #         if feature_key == "price":
# # #             value_txt = format_price_usd(val)
# # #             text = f"{model_name} — {meta['label']}: {value_txt}"
# # #             return {"answer_type": "csv_feature", "text": text, "value": value_txt, "facts": [text], "sources": [src] if src else []}
# # #
# # #         if feature_key == "turning_radius":
# # #             value_txt = str(val).strip()
# # #             text = f"{model_name} — {meta['label']}: {value_txt}"
# # #             return {"answer_type": "csv_feature", "text": text, "value": value_txt, "facts": [text], "sources": [src] if src else []}
# # #
# # #         yn = yn_from_value(val)
# # #         if yn is True:
# # #             text = f"Yes — {model_name} has {meta['label']} (official specification)."
# # #         elif yn is False:
# # #             text = f"No — {model_name} does not list {meta['label']} (official specification)."
# # #         else:
# # #             text = f"{model_name} — {meta['label']}: {str(val).strip()}"
# # #
# # #         return {"answer_type": "csv_feature", "text": text, "facts": [text], "sources": [src] if src else []}
# # #
# # #     if feature_key == "camera_360":
# # #         text = f"No — {model_name} does not list {FEATURE_MAP['camera_360']['label']} in the official specifications we captured."
# # #         return {"answer_type": "csv_feature", "text": text, "facts": [text], "sources": [src] if src else []}
# # #
# # #     return None
# # #
# # # def is_recommendation_intent(text: str) -> bool:
# # #     t = _normalize_text(text)
# # #
# # #     if detect_feature_key(t) is not None:
# # #         return False
# # #
# # #     if re.search(r"\b(spec|specs|specification|details)\b", t):
# # #         return False
# # #
# # #     if extract_budget(t) is not None:
# # #         return True
# # #     if extract_seats(t) is not None:
# # #         return True
# # #     if extract_fuel(t) is not None:
# # #         return True
# # #     if extract_body_type(t) is not None:
# # #         return True
# # #
# # #     if any(k in t for k in ["recommend", "suggest", "buy", "looking for", "need a car", "budget"]):
# # #         return True
# # #
# # #     return False
# # #
# # # def _seats_value(row: Dict[str, Any]) -> Optional[int]:
# # #     v = to_int(row.get("seats"))
# # #     if v is not None:
# # #         return v
# # #     return to_int(row.get("spec_seating_capacity"))
# # #
# # # def filter_cars_split(
# # #     rows: List[Dict[str, Any]],
# # #     max_budget: int,
# # #     min_seats: int,
# # #     fuel: str,
# # #     body_type: str,
# # # ) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
# # #     fuel = (fuel or "any").lower().strip()
# # #     body_type = (body_type or "any").lower().strip()
# # #
# # #     verified: List[Dict[str, Any]] = []
# # #     possible: List[Dict[str, Any]] = []
# # #
# # #     for r in rows:
# # #         price = to_int(r.get("price_usd"))
# # #         if price is None or price > max_budget:
# # #             continue
# # #
# # #         row_fuel = (r.get("fuel") or "").lower().strip()
# # #         row_body = (r.get("body_type") or "").lower().strip()
# # #
# # #         if fuel != "any" and row_fuel != fuel:
# # #             continue
# # #         if body_type != "any" and row_body != body_type:
# # #             continue
# # #
# # #         seats_val = _seats_value(r)
# # #         if seats_val is None:
# # #             possible.append(r)
# # #             continue
# # #
# # #         if seats_val < min_seats:
# # #             continue
# # #
# # #         verified.append(r)
# # #
# # #     verified.sort(key=lambda x: to_int(x.get("price_usd")) or 10**12)
# # #     possible.sort(key=lambda x: to_int(x.get("price_usd")) or 10**12)
# # #     return verified, possible
# # #
# # # def build_reco_answer(
# # #     verified: List[Dict[str, Any]],
# # #     possible: List[Dict[str, Any]],
# # #     max_items: int = 5,
# # #     assumed_seats: Optional[int] = None,
# # # ) -> Dict[str, Any]:
# # #     if not verified and not possible:
# # #         return {"answer_type": "csv_reco", "text": "I couldn't find an official match with those constraints.", "facts": [], "sources": []}
# # #
# # #     lines: List[str] = []
# # #     sources: List[str] = []
# # #
# # #     if verified:
# # #         lines.append("Based on your requirements, here are official matches:\n")
# # #         for m in verified[:max_items]:
# # #             model = m.get("model", "")
# # #             price_txt = format_price_usd(m.get("price_usd"))
# # #             seats_val = _seats_value(m)
# # #             seats_txt = str(seats_val) if seats_val is not None else "N/A"
# # #             f = m.get("fuel", "")
# # #             body = m.get("body_type", "")
# # #             url = m.get("url", "")
# # #             lines.append(f"- {model} ({price_txt}), seats={seats_txt}, fuel={f}, body={body}")
# # #             if url:
# # #                 sources.append(url)
# # #
# # #     if possible:
# # #         if lines:
# # #             lines.append("")
# # #         lines.append("Possible matches (some required fields are N/A in CSV):\n")
# # #         for m in possible[:max_items]:
# # #             model = m.get("model", "")
# # #             price_txt = format_price_usd(m.get("price_usd"))
# # #             seats_val = _seats_value(m)
# # #             seats_txt = str(seats_val) if seats_val is not None else "N/A"
# # #             f = m.get("fuel", "")
# # #             body = m.get("body_type", "")
# # #             url = m.get("url", "")
# # #             lines.append(f"- {model} ({price_txt}), seats={seats_txt}, fuel={f}, body={body}")
# # #             if url:
# # #                 sources.append(url)
# # #
# # #     if assumed_seats is not None:
# # #         lines.append("")
# # #         lines.append(f"Note: I assumed {assumed_seats} seats. If you want 7 seats, type: 7 seats.")
# # #
# # #     return {"answer_type": "csv_reco", "text": "\n".join(lines).strip(), "facts": [], "sources": sources}
# # #
# # # def is_summary_intent(text: str) -> bool:
# # #     t = _normalize_text(text)
# # #     keys = [
# # #         "safety system", "safety systems", "safety feature", "safety features",
# # #         "safety", "adas", "driver assist", "driver assistance", "toyota safety sense", "tss",
# # #     ]
# # #     return any(k in t for k in keys)
# # #
# # # def answer_specs_from_csv(full_rows: List[Dict[str, Any]], model_norm: str, max_lines: int = 12) -> Optional[Dict[str, Any]]:
# # #     row = find_row_by_model(full_rows, model_norm)
# # #     if not row:
# # #         return None
# # #
# # #     model_name = row.get("model") or "This model"
# # #     src = row.get("url") or ""
# # #
# # #     lines: List[str] = []
# # #     price = row.get("price_usd")
# # #     if price not in (None, ""):
# # #         lines.append(f"- Price (USD): {format_price_usd(price)}")
# # #
# # #     seats = _seats_value(row)
# # #     if seats is not None:
# # #         lines.append(f"- Seats: {seats}")
# # #
# # #     fuel = (row.get("fuel") or "").strip()
# # #     if fuel:
# # #         lines.append(f"- Fuel: {fuel}")
# # #
# # #     body = (row.get("body_type") or "").strip()
# # #     if body:
# # #         lines.append(f"- Body type: {body}")
# # #
# # #     extra_fields = [
# # #         ("Engine type", "spec_engine_type"),
# # #         ("Transmission", "spec_transmission_type"),
# # #         ("Displacement", "spec_displacement"),
# # #         ("Maximum output", "spec_maximum_output"),
# # #         ("Maximum torque", "spec_maximum_torque"),
# # #         ("Fuel tank", "spec_fuel_tank_capacity"),
# # #         ("Ground clearance", "spec_ground_clearance"),
# # #         ("Turning radius", "spec_minimum_turning_radius_tire"),
# # #         ("Apple CarPlay/Android Auto", "spec_apple_carplay_and_android_auto"),
# # #         ("Reverse camera", "spec_reverse_camera"),
# # #         ("BSM", "spec_blind_spot_monitor_bsm"),
# # #         ("PVM", "spec_panoramic_view_monitor_pvm"),
# # #         ("Wireless charging", "spec_wireless_charging"),
# # #     ]
# # #
# # #     for label, col in extra_fields:
# # #         if len(lines) >= max_lines:
# # #             break
# # #         v = row.get(col)
# # #         if v in (None, ""):
# # #             continue
# # #         if col.startswith("spec_") and any(x in col for x in ["camera", "bsm", "pvm", "carplay", "wireless"]):
# # #             lines.append(f"- {label}: {yn_label(v)}")
# # #         else:
# # #             lines.append(f"- {label}: {str(v).strip()}")
# # #
# # #     text = f"{model_name} — key specifications (official data):\n" + "\n".join(lines)
# # #     return {"answer_type": "csv_feature", "text": text, "facts": [text], "sources": [src] if src else []}
# # #
# # # def is_spec_intent(text: str) -> bool:
# # #     t = _normalize_text(text)
# # #     return bool(re.search(r"\b(spec|specs|specification|specifications|detail|details)\b", t))
# # #
# # # def _build_safety_summary(row: Dict[str, Any]) -> List[str]:
# # #     lines: List[str] = []
# # #
# # #     def add(label: str, col: str):
# # #         v = row.get(col)
# # #         if v not in (None, ""):
# # #             lines.append(f"- {label}: {yn_label(v)}")
# # #
# # #     add("ABS", "spec_antilock_braking_system_abs")
# # #     add("Vehicle Stability Control (VSC)", "spec_vehicle_stability_control_vsc")
# # #     add("SRS Airbags", "spec_srs_airbags")
# # #     add("Blind Spot Monitor (BSM)", "spec_blind_spot_monitor_bsm")
# # #     add("Lane Departure Warning (LDW)", "spec_lane_departure_warning_ldw")
# # #     add("Lane Keeping Control (LKC)", "spec_lane_keeping_control_lkc")
# # #     add("Pre-Collision Warning (PCW)", "spec_precollision_warning_pcw")
# # #     add("Pre-Collision Braking (PCB)", "spec_precollision_braking_pcb")
# # #     add("Reverse Camera", "spec_reverse_camera")
# # #     add("Panoramic View Monitor (PVM)", "spec_panoramic_view_monitor_pvm")
# # #
# # #     sr = str(row.get("spec_safety_rating") or "").strip()
# # #     if sr:
# # #         lines.append(f"- Safety Rating: {sr}")
# # #
# # #     return lines
# # #
# # # def answer_summary_from_csv(full_rows: List[Dict[str, Any]], model_norm: str) -> Optional[Dict[str, Any]]:
# # #     row = find_row_by_model(full_rows, model_norm)
# # #     if not row:
# # #         return None
# # #
# # #     model_name = row.get("model") or "This model"
# # #     src = row.get("url") or ""
# # #
# # #     lines = _build_safety_summary(row)
# # #     if not lines:
# # #         text = f"I couldn't find structured safety fields for {model_name} in the CSV."
# # #     else:
# # #         text = f"{model_name} — Safety systems (official CSV):\n" + "\n".join(lines)
# # #
# # #     return {"answer_type": "csv_summary", "text": text, "facts": [text], "sources": [src] if src else []}
# # #
# # # def list_variants_for_model(full_rows: List[Dict[str, Any]], model_norm: str) -> List[Dict[str, Any]]:
# # #     model_norm = normalize_model_name(model_norm or "")
# # #     if not model_norm:
# # #         return []
# # #
# # #     row = find_row_by_model(full_rows, model_norm)
# # #     if row:
# # #         base_phrase = _base_key(model_norm)
# # #     else:
# # #         base_phrase = _base_key(model_norm)
# # #
# # #     if not base_phrase:
# # #         return []
# # #
# # #     candidates = _find_rows_by_base_name(full_rows, base_phrase)
# # #
# # #     out: List[Dict[str, Any]] = []
# # #     for m_norm, r in candidates:
# # #         out.append({
# # #             "model_norm": m_norm,
# # #             "model": r.get("model") or m_norm,
# # #             "fuel": (r.get("fuel") or "").strip(),
# # #             "price_usd": r.get("price_usd"),
# # #             "url": r.get("url") or "",
# # #         })
# # #
# # #     out.sort(key=lambda x: (to_int(x.get("price_usd")) if to_int(x.get("price_usd")) is not None else 10**12))
# # #     return out
# # # # scripts/csv_engine.py
# # # # Add this function at the bottom (or anywhere after find_row_by_model + normalize helpers)
# # #
# # # from typing import Dict, Any, List
# # #
# # # def list_variants_for_model(full_rows: List[Dict[str, Any]], model_norm: str) -> List[Dict[str, Any]]:
# # #     """
# # #     Return variants for the same base model family as model_norm.
# # #     Example: yaris cross gasoline + yaris cross hev.
# # #     """
# # #     # local imports from existing functions in this file
# # #     base = _base_key(model_norm)
# # #     if not base:
# # #         row = find_row_by_model(full_rows, model_norm)
# # #         return [row] if row else []
# # #
# # #     variants: List[Dict[str, Any]] = []
# # #     base_tokens = set(_tokenize(base))
# # #
# # #     for r in full_rows:
# # #         m = normalize_model_name(str(r.get("model") or ""))
# # #         if not m:
# # #             continue
# # #         m_base = _base_key(m)
# # #         if not m_base:
# # #             continue
# # #         if set(_tokenize(m_base)) == base_tokens:
# # #             variants.append(r)
# # #
# # #     # sort by price
# # #     variants.sort(key=lambda x: to_int(x.get("price_usd")) or 10**12)
# # #     return variants
# #
# # """
# # csv_engine.py  –  All CSV-based logic for the Toyota chatbot.
# #
# # PATH RESOLUTION ORDER for vehicle_master.csv:
# #   1. Explicit path passed to load_full_rows(csv_path=...)
# #   2. scripts/vehicle_master.csv        (same folder as this file)
# #   3. <project_root>/vehicle_master.csv (parent of scripts/)
# #   4. <project_root>/data/vehicle_master.csv
# #   5. <project_root>/data_new/vehicle_master.csv
# #   6. <project_root>/csv/vehicle_master.csv
# #   7. <project_root>/assets/vehicle_master.csv
# #   8. One level above project_root
# #   9. One level above project_root / data/
# #
# # A clear FileNotFoundError with all tried paths is raised if nothing is found.
# # """
# # from __future__ import annotations
# #
# # import csv
# # import re
# # from pathlib import Path
# # from typing import Any, Dict, List, Optional, Tuple
# #
# # # ---------------------------------------------------------------------------
# # # Path resolution
# # # ---------------------------------------------------------------------------
# #
# # _SCRIPTS_DIR  = Path(__file__).resolve().parent       # …/scripts/
# # _PROJECT_ROOT = _SCRIPTS_DIR.parent                   # …/Chat-04-Feb 2/
# #
# #
# # def _find_csv(filename: str, override: Optional[str] = None) -> Path:
# #     """Search everywhere and return first match, or raise clear FileNotFoundError."""
# #     # 1. Explicit override always wins
# #     if override:
# #         p = Path(override).expanduser().resolve()
# #         if p.exists():
# #             return p
# #
# #     # 2. Common fixed locations (fast)
# #     fixed = [
# #         _SCRIPTS_DIR / filename,
# #         _PROJECT_ROOT / filename,
# #         _PROJECT_ROOT / "data" / filename,
# #         _PROJECT_ROOT / "data_new" / filename,
# #         _PROJECT_ROOT / "data_vehicle" / filename,
# #         _PROJECT_ROOT / "data_preowned" / filename,
# #         _PROJECT_ROOT / "data_preowned" / "csv_preowned" / filename,
# #         _PROJECT_ROOT / "csv" / filename,
# #         _PROJECT_ROOT / "assets" / filename,
# #         _PROJECT_ROOT.parent / filename,
# #         _PROJECT_ROOT.parent / "data" / filename,
# #     ]
# #     for p in fixed:
# #         if p.exists():
# #             return p
# #
# #     # 3. Recursive glob — finds the file no matter which subfolder it is in
# #     for p in _PROJECT_ROOT.rglob(filename):
# #         return p
# #
# #     # 4. One level up (covers sibling project structures)
# #     for p in _PROJECT_ROOT.parent.rglob(filename):
# #         return p
# #
# #     raise FileNotFoundError(
# #         f"\n\n[csv_engine] Cannot find '{filename}'.\n"
# #         f"Searched recursively under:\n"
# #         f"  {_PROJECT_ROOT}\n"
# #         f"  {_PROJECT_ROOT.parent}\n\n"
# #         f"Quick fix — copy '{filename}' to:\n"
# #         f"  {_PROJECT_ROOT / filename}\n"
# #     )
# #
# #
# # # ---------------------------------------------------------------------------
# # # Helpers
# # # ---------------------------------------------------------------------------
# #
# # def _low(s: Any) -> str:
# #     return (str(s) or "").strip().lower()
# #
# #
# # def _norm_ws(s: str) -> str:
# #     return re.sub(r"\s+", " ", s.strip())
# #
# #
# # def format_price_usd(value: Any) -> str:
# #     if value in (None, "", "N/A"):
# #         return "N/A"
# #     try:
# #         v = float(str(value).replace(",", "").replace("$", "").strip())
# #         return f"${int(v):,}" if v == int(v) else f"${v:,.2f}"
# #     except Exception:
# #         return str(value).strip() or "N/A"
# #
# #
# # # ---------------------------------------------------------------------------
# # # Load rows
# # # ---------------------------------------------------------------------------
# #
# # def load_full_rows(csv_path: Optional[str] = None) -> List[Dict[str, Any]]:
# #     """
# #     Load and return all rows from vehicle_master.csv.
# #
# #     Args:
# #         csv_path: Optional explicit path to the CSV. Searches common project
# #                   locations automatically if not given.
# #
# #     Returns:
# #         List of row dicts (one per vehicle variant).
# #
# #     Raises:
# #         FileNotFoundError: with helpful message listing all searched locations.
# #     """
# #     path = _find_csv("vehicle_master.csv", override=csv_path)
# #     print(f"[csv_engine] vehicle CSV: {path}")
# #     with open(path, encoding="utf-8-sig", newline="") as f:
# #         rows = [dict(r) for r in csv.DictReader(f)]
# #     return rows
# #
# #
# # # ---------------------------------------------------------------------------
# # # Model detection
# # # ---------------------------------------------------------------------------
# #
# # _MODEL_ALIASES: Dict[str, str] = {
# #     # ── Corolla Cross ──────────────────────────────────────────────────────
# #     "corolla cross gasoline":       "COROLLA CROSS GASOLINE",
# #     "corolla cross hev":            "Corolla Cross HEV",
# #     "corolla cross hybrid":         "Corolla Cross HEV",
# #     "corolla cross":                "COROLLA CROSS GASOLINE",
# #     # ── Fortuner ──────────────────────────────────────────────────────────
# #     "fortuner legender":            "Fortuner Legender",
# #     "fortuner":                     "Fortuner Legender",
# #     # ── Hiace ─────────────────────────────────────────────────────────────
# #     "hiace 12-seater":              "Hiace 12-seater",
# #     "hiace 12 seater":              "Hiace 12-seater",
# #     "hiace 12":                     "Hiace 12-seater",
# #     "hiace 16-seater":              "Hiace 16-seater",
# #     "hiace 16 seater":              "Hiace 16-seater",
# #     "hiace 16":                     "Hiace 16-seater",
# #     # ── Hilux ─────────────────────────────────────────────────────────────
# #     "hilux revo rally":             "Hilux Revo Rally",
# #     "hilux rally":                  "Hilux Revo Rally",
# #     "hilux revo v-edition":         "Hilux Revo V-Edition",
# #     "hilux revo v edition":         "Hilux Revo V-Edition",
# #     "hilux v-edition":              "Hilux Revo V-Edition",
# #     "hilux revo v":                 "Hilux Revo V-Edition",
# #     "hilux":                        "Hilux Revo Rally",
# #     # ── Land Cruiser ──────────────────────────────────────────────────────
# #     "land cruiser 250 diesel":      "Land Cruiser 250 Diesel",
# #     "land cruiser 250 gasoline":    "Land Cruiser 250 Gasoline",
# #     "land cruiser 250":             "Land Cruiser 250 Diesel",
# #     "land cruiser gr-s":            "LAND CRUISER GR-S",
# #     "land cruiser gr s":            "LAND CRUISER GR-S",
# #     "land cruiser grs":             "LAND CRUISER GR-S",
# #     "land cruiser gr":              "LAND CRUISER GR-S",
# #     "land cruiser zx":              "Land Cruiser ZX",
# #     "land cruiser":                 "Land Cruiser ZX",
# #     # ── Others ────────────────────────────────────────────────────────────
# #     "raize":                        "Raize",
# #     "veloz":                        "Veloz",
# #     "vios":                         "Vios",
# #     "wigo":                         "Wigo",
# #     "yaris cross hev":              "Yaris Cross HEV",
# #     "yaris cross hybrid":           "Yaris Cross HEV",
# #     "yaris cross gasoline":         "YARIS CROSS GASOLINE",
# #     "yaris cross":                  "Yaris Cross HEV",
# # }
# #
# #
# # def _canonical_model_names(full_rows: List[Dict[str, Any]]) -> List[str]:
# #     seen: set = set()
# #     names: List[str] = []
# #     for r in full_rows:
# #         m = (r.get("model") or "").strip()
# #         if m and m not in seen:
# #             seen.add(m)
# #             names.append(m)
# #     return names
# #
# #
# # def detect_model_in_text(text: str, full_rows: List[Dict[str, Any]]) -> Optional[str]:
# #     """Return CSV model name found in *text* (longest alias wins), or None."""
# #     t = _norm_ws(_low(text))
# #
# #     # 1. Alias table — sorted longest-first so specific beats general
# #     for alias in sorted(_MODEL_ALIASES, key=len, reverse=True):
# #         if alias in t:
# #             canonical = _MODEL_ALIASES[alias]
# #             for r in full_rows:
# #                 if _low(r.get("model", "")) == _low(canonical):
# #                     return r["model"]
# #             return canonical
# #
# #     # 2. Direct match against CSV names
# #     names = _canonical_model_names(full_rows)
# #     for name in sorted(names, key=len, reverse=True):
# #         if _low(name) in t:
# #             return name
# #
# #     return None
# #
# #
# # def detect_models_in_text(
# #     text: str,
# #     full_rows: List[Dict[str, Any]],
# #     max_models: int = 2,
# # ) -> List[str]:
# #     """Return up to *max_models* distinct model names found in *text*."""
# #     t = _norm_ws(_low(text))
# #     found: List[str] = []
# #     used: List[Tuple[int, int]] = []
# #
# #     for name in sorted(_canonical_model_names(full_rows), key=len, reverse=True):
# #         pattern = _low(name)
# #         idx = t.find(pattern)
# #         if idx == -1:
# #             continue
# #         end = idx + len(pattern)
# #         if any(s <= idx < e or s < end <= e for s, e in used):
# #             continue  # overlapping with already-found
# #         found.append(name)
# #         used.append((idx, end))
# #         if len(found) >= max_models:
# #             break
# #
# #     return found
# #
# #
# # def resolve_target_model(
# #     user_text: str,
# #     last_model: Optional[str],
# #     full_rows: List[Dict[str, Any]],
# # ) -> Optional[str]:
# #     """Model from text first; then fall back to last_model for follow-ups."""
# #     m = detect_model_in_text(user_text, full_rows)
# #     return m if m else last_model
# #
# #
# # def find_row_by_model(
# #     full_rows: List[Dict[str, Any]],
# #     model_name: str,
# # ) -> Optional[Dict[str, Any]]:
# #     m = _low(model_name)
# #     for r in full_rows:
# #         if _low(r.get("model", "")) == m:
# #             return r
# #     return None
# #
# #
# # # ---------------------------------------------------------------------------
# # # Intent detection
# # # ---------------------------------------------------------------------------
# #
# # def is_spec_intent(text: str) -> bool:
# #     return any(k in _low(text) for k in ["spec", "specification"])
# #
# #
# # def is_summary_intent(text: str) -> bool:
# #     t = _low(text)
# #     return "summary" in t or "overview" in t or "tell me about" in t
# #
# #
# # def is_recommendation_intent(text: str) -> bool:
# #     t = _low(text)
# #     return any(k in t for k in [
# #         "recommend", "suggest", "i want to buy", "buy a car", "buy car",
# #         "looking for a car", "looking to buy", "help me choose",
# #         "which car", "best car for",
# #     ])
# #
# #
# # # ---------------------------------------------------------------------------
# # # Slot extraction
# # # ---------------------------------------------------------------------------
# #
# # def extract_budget(text: str) -> Optional[float]:
# #     t = _low(text).replace(",", "")
# #     m = re.search(
# #         r"(?:under|below|less\s+than|budget|max|<)\s*\$?\s*(\d{4,6}(?:\.\d+)?)", t
# #     )
# #     if m:
# #         try:
# #             return float(m.group(1))
# #         except Exception:
# #             pass
# #     m2 = re.search(r"\b(\d{4,6})\b", t)
# #     if m2:
# #         try:
# #             return float(m2.group(1))
# #         except Exception:
# #             pass
# #     return None
# #
# #
# # def extract_seats(text: str) -> Optional[int]:
# #     t = _low(text)
# #     m = re.search(r"(?:min|minimum|at\s+least|>)\s*(\d+)\s*seat", t)
# #     if m:
# #         return int(m.group(1))
# #     m2 = re.search(r"(\d+)\s*seat", t)
# #     if m2:
# #         return int(m2.group(1))
# #     return None
# #
# #
# # def extract_fuel(text: str) -> Optional[str]:
# #     t = _low(text)
# #     if "both" in t.split():
# #         return "both"
# #     if "gasoline" in t or re.search(r"\bgas\b", t):
# #         return "gasoline"
# #     if "diesel" in t:
# #         return "diesel"
# #     if "hybrid" in t or "hev" in t:
# #         return "hybrid"
# #     if re.search(r"\bev\b", t) or "electric" in t:
# #         return "ev"
# #     return None
# #
# #
# # def extract_body_type(text: str) -> Optional[str]:
# #     t = _low(text)
# #     if "suv" in t:
# #         return "SUV"
# #     if "sedan" in t:
# #         return "Sedan"
# #     if "pickup" in t or "pick-up" in t or "pick up" in t:
# #         return "Pickup"
# #     if "mpv" in t or "mvp" in t:
# #         return "MPV"
# #     if re.search(r"\bbus\b", t):
# #         return "BUS"
# #     return None
# #
# #
# # # ---------------------------------------------------------------------------
# # # Feature key detection
# # # ---------------------------------------------------------------------------
# #
# # _FEATURE_MAP: List[Tuple[str, List[str]]] = [
# #     ("spec_transmission",                    ["transmission", "gear box", "gearbox"]),
# #     ("spec_transmission_type",               ["transmission type"]),
# #     ("spec_fuel_tank_capacity",              ["fuel tank", "tank capacity"]),
# #     ("spec_srs_airbags",                     ["airbag", "airbags"]),
# #     ("seats",                                ["seat number", "how many seats", "seating capacity", "seats", "seat"]),
# #     ("spec_ground_clearance",                ["ground clearance", "clearance"]),
# #     ("spec_apple_carplay_and_android_auto",  ["apple carplay", "android auto", "carplay"]),
# #     ("spec_apple_carplay_or_android_auto",   ["apple carplay", "android auto", "carplay"]),
# #     ("spec_panoramic_view_monitor_pvm",      ["360 camera", "360camera", "panoramic view monitor", "pvm", "around view", "360"]),
# #     ("spec_blind_spot_monitor_bsm",          ["blind spot monitor", "blind spot", "bsm"]),
# #     ("spec_headup_display_hud",              ["head-up display", "heads-up display", "hud", "head up display"]),
# #     ("spec_wireless_charger",                ["wireless charg"]),
# #     ("spec_wireless_charging",               ["wireless charg"]),
# #     ("spec_reverse_camera",                  ["reverse camera", "backup camera", "rear camera"]),
# #     ("spec_parking_sensors",                 ["parking sensor"]),
# #     ("spec_safety_rating",                   ["safety rating", "ncap"]),
# #     ("spec_lane_departure_warning_ldw",      ["lane departure warning", "lane warning", "ldw"]),
# #     ("spec_vehicle_stability_control_vsc",   ["vehicle stability control", "stability control", "vsc"]),
# #     ("spec_smart_entry",                     ["smart entry", "smart key", "keyless"]),
# #     ("spec_ignition",                        ["ignition", "push start"]),
# #     ("spec_drive_type",                      ["drive type", "drivetrain", "4wd", "fwd", "awd", "2wd"]),
# #     ("spec_displacement",                    ["displacement", "engine size", "engine cc"]),
# #     ("spec_engine_type",                     ["engine type", "engine"]),
# #     ("spec_wheelbase",                       ["wheelbase", "wheel base"]),
# #     ("spec_length___width___height",         ["dimensions", "dimension", "length width height"]),
# #     ("spec_max_output",                      ["horsepower", "power output", "max output"]),
# #     ("spec_max_torque",                      ["torque"]),
# #     ("fuel",                                 ["fuel type", "fuel"]),
# # ]
# #
# #
# # def detect_feature_key(text: str) -> Optional[str]:
# #     t = _low(text)
# #     best_col: Optional[str] = None
# #     best_len = 0
# #     for col, keywords in _FEATURE_MAP:
# #         for kw in keywords:
# #             if kw in t and len(kw) > best_len:
# #                 best_col = col
# #                 best_len = len(kw)
# #     return best_col
# #
# #
# # # ---------------------------------------------------------------------------
# # # Answer builders
# # # ---------------------------------------------------------------------------
# #
# # def answer_specs_from_csv(full_rows: List[Dict[str, Any]], model_name: str) -> Dict[str, Any]:
# #     row = find_row_by_model(full_rows, model_name)
# #     if not row:
# #         txt = f"I couldn't find '{model_name}' in the dataset."
# #         return {"answer_type": "csv_specs", "text": txt, "facts": [txt], "sources": []}
# #
# #     name   = row.get("model") or model_name
# #     price  = format_price_usd(row.get("price_usd"))
# #     seats  = row.get("seats") or "N/A"
# #     fuel   = row.get("fuel") or "N/A"
# #     body   = row.get("body_type") or "N/A"
# #     trans  = row.get("spec_transmission") or row.get("spec_transmission_type") or "N/A"
# #     engine = row.get("spec_engine_type") or "N/A"
# #     src    = row.get("url") or ""
# #
# #     txt = "\n".join([
# #         f"{name} — key specifications (official data):",
# #         f"- Price (USD): {price}",
# #         f"- Seats: {seats}",
# #         f"- Fuel: {fuel}",
# #         f"- Body type: {body}",
# #         f"- Transmission: {trans}",
# #         f"- Engine: {engine}",
# #     ])
# #     return {"answer_type": "csv_specs", "text": txt, "facts": [txt], "sources": [src] if src else []}
# #
# #
# # def answer_summary_from_csv(full_rows: List[Dict[str, Any]], model_name: str) -> Dict[str, Any]:
# #     row = find_row_by_model(full_rows, model_name)
# #     if not row:
# #         txt = f"I couldn't find '{model_name}' in the dataset."
# #         return {"answer_type": "csv_summary", "text": txt, "facts": [txt], "sources": []}
# #
# #     name  = row.get("model") or model_name
# #     price = format_price_usd(row.get("price_usd"))
# #     seats = row.get("seats") or "N/A"
# #     fuel  = row.get("fuel") or "N/A"
# #     body  = row.get("body_type") or "N/A"
# #     trans = row.get("spec_transmission") or row.get("spec_transmission_type") or "N/A"
# #     src   = row.get("url") or ""
# #
# #     txt = (
# #         f"{name} — Summary\n"
# #         f"Price: {price} | Body: {body} | Fuel: {fuel} | Seats: {seats} | Transmission: {trans}"
# #     )
# #     return {"answer_type": "csv_summary", "text": txt, "facts": [txt], "sources": [src] if src else []}
# #
# #
# # def answer_price_from_csv(full_rows: List[Dict[str, Any]], model_name: str) -> Dict[str, Any]:
# #     row = find_row_by_model(full_rows, model_name)
# #     if not row:
# #         txt = f"I couldn't find '{model_name}' in the dataset."
# #         return {"answer_type": "csv_price", "text": txt, "facts": [txt], "sources": []}
# #
# #     name  = row.get("model") or model_name
# #     price = format_price_usd(row.get("price_usd"))
# #     src   = row.get("url") or ""
# #
# #     txt = f"Sure — here are the official prices from our dataset:\n\n{name} — Price (USD): {price}"
# #     return {"answer_type": "csv_price", "text": txt, "facts": [txt], "sources": [src] if src else []}
# #
# #
# # def answer_feature_from_csv(
# #     full_rows: List[Dict[str, Any]],
# #     model_name: str,
# #     feature_key: str,
# # ) -> Optional[Dict[str, Any]]:
# #     """Return feature answer or None if value is missing."""
# #     row = find_row_by_model(full_rows, model_name)
# #     if not row:
# #         return None
# #
# #     name = row.get("model") or model_name
# #     src  = row.get("url") or ""
# #
# #     if feature_key == "seats":
# #         val = row.get("seats") or row.get("spec_seating_capacity") or ""
# #     elif feature_key == "fuel":
# #         val = row.get("fuel") or ""
# #     else:
# #         val = row.get(feature_key) or ""
# #
# #     val_str = str(val).strip()
# #     if not val_str:
# #         return None
# #
# #     _LABELS: Dict[str, str] = {
# #         "spec_transmission":                    "Transmission",
# #         "spec_transmission_type":               "Transmission type",
# #         "spec_fuel_tank_capacity":              "Fuel tank capacity",
# #         "spec_srs_airbags":                     "SRS airbags",
# #         "seats":                                "Seats",
# #         "spec_ground_clearance":                "Ground clearance",
# #         "spec_apple_carplay_and_android_auto":  "Apple CarPlay / Android Auto",
# #         "spec_apple_carplay_or_android_auto":   "Apple CarPlay / Android Auto",
# #         "spec_panoramic_view_monitor_pvm":      "360° Panoramic View Monitor",
# #         "spec_blind_spot_monitor_bsm":          "Blind Spot Monitor",
# #         "spec_headup_display_hud":              "Head-Up Display",
# #         "spec_wireless_charger":                "Wireless charger",
# #         "spec_wireless_charging":               "Wireless charging",
# #         "spec_reverse_camera":                  "Reverse camera",
# #         "spec_parking_sensors":                 "Parking sensors",
# #         "spec_safety_rating":                   "Safety rating",
# #         "spec_lane_departure_warning_ldw":      "Lane Departure Warning",
# #         "spec_vehicle_stability_control_vsc":   "Vehicle Stability Control",
# #         "spec_smart_entry":                     "Smart entry",
# #         "spec_ignition":                        "Ignition",
# #         "spec_drive_type":                      "Drive type",
# #         "spec_displacement":                    "Displacement",
# #         "spec_engine_type":                     "Engine type",
# #         "spec_wheelbase":                       "Wheelbase",
# #         "spec_length___width___height":         "Dimensions (L×W×H)",
# #         "spec_max_output":                      "Max output",
# #         "spec_max_torque":                      "Max torque",
# #         "fuel":                                 "Fuel type",
# #     }
# #     label = _LABELS.get(feature_key, feature_key.replace("spec_", "").replace("_", " ").title())
# #
# #     _YES = {"included", "yes", "available", "standard"}
# #     _NO  = {"not available", "n/a", "no", "not included"}
# #
# #     vl = val_str.lower()
# #     if vl in _YES:
# #         verdict = "Yes"
# #     elif vl in _NO:
# #         verdict = "No"
# #     else:
# #         verdict = val_str
# #
# #     txt = f"{name} — {label}: {verdict}"
# #     return {"answer_type": "csv_feature", "text": txt, "facts": [txt], "sources": [src] if src else []}
# #
# #
# # # ---------------------------------------------------------------------------
# # # Recommendation filtering
# # # ---------------------------------------------------------------------------
# #
# # def filter_cars_split(
# #     full_rows: List[Dict[str, Any]],
# #     max_budget: float,
# #     min_seats: int,
# #     fuel: Optional[str],
# #     body_type: Optional[str],
# # ) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
# #     """Return (verified_matches, possible_matches_seats_short)."""
# #     verified, possible = [], []
# #     for r in full_rows:
# #         try:
# #             price = float(str(r.get("price_usd", "0")).replace(",", "").replace("$", ""))
# #         except Exception:
# #             continue
# #         if price > max_budget:
# #             continue
# #
# #         rfuel = _low(r.get("fuel") or "")
# #         rbody = _low(r.get("body_type") or "")
# #         fuel_ok = fuel is None or fuel == "both" or fuel in rfuel
# #         body_ok = body_type is None or _low(body_type) == rbody
# #
# #         try:
# #             rseats = int(str(r.get("seats") or "0").strip())
# #         except Exception:
# #             rseats = 0
# #
# #         seats_ok = min_seats == 0 or rseats >= min_seats
# #
# #         if fuel_ok and body_ok:
# #             (verified if seats_ok else possible).append(r)
# #
# #     return verified, possible
# #
# #
# # def build_reco_answer(
# #     verified: List[Dict[str, Any]],
# #     possible: List[Dict[str, Any]],
# #     max_items: int = 5,
# #     assumed_seats: Optional[int] = None,
# # ) -> Dict[str, Any]:
# #     if not verified and not possible:
# #         txt = (
# #             "I couldn't find a match in our dataset with those filters. "
# #             "Try increasing your budget or changing body type / fuel."
# #         )
# #         return {"answer_type": "csv_reco", "text": txt, "facts": [txt], "sources": []}
# #
# #     show   = verified or possible
# #     suffix = "" if verified else " (seats may vary)"
# #     lines  = ["Here are matches from our dataset:"]
# #     sources: List[str] = []
# #
# #     for r in show[:max_items]:
# #         name  = r.get("model") or "N/A"
# #         price = format_price_usd(r.get("price_usd"))
# #         seats = r.get("seats") or "N/A"
# #         rfuel = r.get("fuel") or "N/A"
# #         rbody = r.get("body_type") or "N/A"
# #         lines.append(f"- {name} — {price} | Seats: {seats} | Fuel: {rfuel} | Body: {rbody}{suffix}")
# #         u = r.get("url") or ""
# #         if u and u not in sources:
# #             sources.append(u)
# #
# #     txt = "\n".join(lines)
# #     return {"answer_type": "csv_reco", "text": txt, "facts": [txt], "sources": sources}
# #
# #
#
# """
# csv_engine.py  –  All CSV-based logic for the Toyota chatbot.
#
# PATH RESOLUTION ORDER for vehicle_master.csv:
#   1. Explicit path passed to load_full_rows(csv_path=...)
#   2. scripts/vehicle_master.csv        (same folder as this file)
#   3. <project_root>/vehicle_master.csv (parent of scripts/)
#   4. <project_root>/data/vehicle_master.csv
#   5. <project_root>/data_new/vehicle_master.csv
#   6. <project_root>/csv/vehicle_master.csv
#   7. <project_root>/assets/vehicle_master.csv
#   8. One level above project_root
#   9. One level above project_root / data/
#
# A clear FileNotFoundError with all tried paths is raised if nothing is found.
# """
# from __future__ import annotations
#
# import csv
# import re
# from pathlib import Path
# from typing import Any, Dict, List, Optional, Tuple
#
# # ---------------------------------------------------------------------------
# # Path resolution
# # ---------------------------------------------------------------------------
#
# _SCRIPTS_DIR  = Path(__file__).resolve().parent       # …/scripts/
# _PROJECT_ROOT = _SCRIPTS_DIR.parent                   # …/Chat-04-Feb 2/
#
#
# def _find_csv(filename: str, override: Optional[str] = None) -> Path:
#     """Search everywhere and return first match, or raise clear FileNotFoundError."""
#     # 1. Explicit override always wins
#     if override:
#         p = Path(override).expanduser().resolve()
#         if p.exists():
#             return p
#
#     # 2. Common fixed locations (fast)
#     fixed = [
#         _SCRIPTS_DIR / filename,
#         _PROJECT_ROOT / filename,
#         _PROJECT_ROOT / "data" / filename,
#         _PROJECT_ROOT / "data_new" / filename,
#         _PROJECT_ROOT / "data_vehicle" / filename,
#         _PROJECT_ROOT / "data_preowned" / filename,
#         _PROJECT_ROOT / "data_preowned" / "csv_preowned" / filename,
#         _PROJECT_ROOT / "csv" / filename,
#         _PROJECT_ROOT / "assets" / filename,
#         _PROJECT_ROOT.parent / filename,
#         _PROJECT_ROOT.parent / "data" / filename,
#     ]
#     for p in fixed:
#         if p.exists():
#             return p
#
#     # 3. Recursive glob — finds the file no matter which subfolder it is in
#     for p in _PROJECT_ROOT.rglob(filename):
#         return p
#
#     # 4. One level up (covers sibling project structures)
#     for p in _PROJECT_ROOT.parent.rglob(filename):
#         return p
#
#     raise FileNotFoundError(
#         f"\n\n[csv_engine] Cannot find '{filename}'.\n"
#         f"Searched recursively under:\n"
#         f"  {_PROJECT_ROOT}\n"
#         f"  {_PROJECT_ROOT.parent}\n\n"
#         f"Quick fix — copy '{filename}' to:\n"
#         f"  {_PROJECT_ROOT / filename}\n"
#     )
#
#
# # ---------------------------------------------------------------------------
# # Helpers
# # ---------------------------------------------------------------------------
#
# def _low(s: Any) -> str:
#     return (str(s) or "").strip().lower()
#
#
# def _norm_ws(s: str) -> str:
#     return re.sub(r"\s+", " ", s.strip())
#
#
# def format_price_usd(value: Any) -> str:
#     if value in (None, "", "N/A"):
#         return "N/A"
#     try:
#         v = float(str(value).replace(",", "").replace("$", "").strip())
#         return f"${int(v):,}" if v == int(v) else f"${v:,.2f}"
#     except Exception:
#         return str(value).strip() or "N/A"
#
#
# # ---------------------------------------------------------------------------
# # Load rows
# # ---------------------------------------------------------------------------
#
# def load_full_rows(csv_path: Optional[str] = None) -> List[Dict[str, Any]]:
#     """
#     Load and return all rows from vehicle_master.csv.
#
#     Args:
#         csv_path: Optional explicit path to the CSV. Searches common project
#                   locations automatically if not given.
#
#     Returns:
#         List of row dicts (one per vehicle variant).
#
#     Raises:
#         FileNotFoundError: with helpful message listing all searched locations.
#     """
#     path = _find_csv("vehicle_master.csv", override=csv_path)
#     print(f"[csv_engine] vehicle CSV: {path}")
#     with open(path, encoding="utf-8-sig", newline="") as f:
#         rows = [dict(r) for r in csv.DictReader(f)]
#     return rows
#
#
# # ---------------------------------------------------------------------------
# # Model detection
# # ---------------------------------------------------------------------------
#
# _MODEL_ALIASES: Dict[str, str] = {
#     # ── Corolla Cross ──────────────────────────────────────────────────────
#     "corolla cross gasoline":       "COROLLA CROSS GASOLINE",
#     "corolla cross hev":            "Corolla Cross HEV",
#     "corolla cross hybrid":         "Corolla Cross HEV",
#     "corolla cross":                "COROLLA CROSS GASOLINE",
#     # ── Fortuner ──────────────────────────────────────────────────────────
#     "fortuner legender":            "Fortuner Legender",
#     "fortuner":                     "Fortuner Legender",
#     # ── Hiace ─────────────────────────────────────────────────────────────
#     "hiace 12-seater":              "Hiace 12-seater",
#     "hiace 12 seater":              "Hiace 12-seater",
#     "hiace 12":                     "Hiace 12-seater",
#     "hiace 16-seater":              "Hiace 16-seater",
#     "hiace 16 seater":              "Hiace 16-seater",
#     "hiace 16":                     "Hiace 16-seater",
#     # ── Hilux ─────────────────────────────────────────────────────────────
#     "hilux revo rally":             "Hilux Revo Rally",
#     "hilux rally":                  "Hilux Revo Rally",
#     "hilux revo v-edition":         "Hilux Revo V-Edition",
#     "hilux revo v edition":         "Hilux Revo V-Edition",
#     "hilux v-edition":              "Hilux Revo V-Edition",
#     "hilux revo v":                 "Hilux Revo V-Edition",
#     "hilux":                        "Hilux Revo Rally",
#     # ── Land Cruiser ──────────────────────────────────────────────────────
#     "land cruiser 250 diesel":      "Land Cruiser 250 Diesel",
#     "land cruiser 250 gasoline":    "Land Cruiser 250 Gasoline",
#     "land cruiser 250":             "Land Cruiser 250 Diesel",
#     "land cruiser gr-s":            "LAND CRUISER GR-S",
#     "land cruiser gr s":            "LAND CRUISER GR-S",
#     "land cruiser grs":             "LAND CRUISER GR-S",
#     "land cruiser gr":              "LAND CRUISER GR-S",
#     "land cruiser zx":              "Land Cruiser ZX",
#     "land cruiser":                 "Land Cruiser ZX",
#     # ── Others ────────────────────────────────────────────────────────────
#     "raize":                        "Raize",
#     "veloz":                        "Veloz",
#     "vios":                         "Vios",
#     "wigo":                         "Wigo",
#     "yaris cross hev":              "Yaris Cross HEV",
#     "yaris cross hybrid":           "Yaris Cross HEV",
#     "yaris cross gasoline":         "YARIS CROSS GASOLINE",
#     "yaris cross":                  "Yaris Cross HEV",
# }
#
#
# def _canonical_model_names(full_rows: List[Dict[str, Any]]) -> List[str]:
#     seen: set = set()
#     names: List[str] = []
#     for r in full_rows:
#         m = (r.get("model") or "").strip()
#         if m and m not in seen:
#             seen.add(m)
#             names.append(m)
#     return names
#
#
# def detect_model_in_text(text: str, full_rows: List[Dict[str, Any]]) -> Optional[str]:
#     """Return CSV model name found in *text* (longest alias wins), or None."""
#     t = _norm_ws(_low(text))
#
#     # 1. Alias table — sorted longest-first so specific beats general
#     for alias in sorted(_MODEL_ALIASES, key=len, reverse=True):
#         if alias in t:
#             canonical = _MODEL_ALIASES[alias]
#             for r in full_rows:
#                 if _low(r.get("model", "")) == _low(canonical):
#                     return r["model"]
#             return canonical
#
#     # 2. Direct match against CSV names
#     names = _canonical_model_names(full_rows)
#     for name in sorted(names, key=len, reverse=True):
#         if _low(name) in t:
#             return name
#
#     return None
#
#
# def detect_models_in_text(
#     text: str,
#     full_rows: List[Dict[str, Any]],
#     max_models: int = 2,
# ) -> List[str]:
#     """Return up to *max_models* distinct model names found in *text*."""
#     t = _norm_ws(_low(text))
#     found: List[str] = []
#     used: List[Tuple[int, int]] = []
#
#     for name in sorted(_canonical_model_names(full_rows), key=len, reverse=True):
#         pattern = _low(name)
#         idx = t.find(pattern)
#         if idx == -1:
#             continue
#         end = idx + len(pattern)
#         if any(s <= idx < e or s < end <= e for s, e in used):
#             continue  # overlapping with already-found
#         found.append(name)
#         used.append((idx, end))
#         if len(found) >= max_models:
#             break
#
#     return found
#
#
# def resolve_target_model(
#     user_text: str,
#     last_model: Optional[str],
#     full_rows: List[Dict[str, Any]],
# ) -> Optional[str]:
#     """Model from text first; then fall back to last_model for follow-ups."""
#     m = detect_model_in_text(user_text, full_rows)
#     return m if m else last_model
#
#
# def find_row_by_model(
#     full_rows: List[Dict[str, Any]],
#     model_name: str,
# ) -> Optional[Dict[str, Any]]:
#     m = _low(model_name)
#     for r in full_rows:
#         if _low(r.get("model", "")) == m:
#             return r
#     return None
#
#
# # ---------------------------------------------------------------------------
# # Intent detection
# # ---------------------------------------------------------------------------
#
# def is_spec_intent(text: str) -> bool:
#     return any(k in _low(text) for k in ["spec", "specification"])
#
#
# def is_summary_intent(text: str) -> bool:
#     t = _low(text)
#     return "summary" in t or "overview" in t or "tell me about" in t
#
#
# def is_recommendation_intent(text: str) -> bool:
#     t = _low(text)
#     return any(k in t for k in [
#         "recommend", "suggest", "i want to buy", "buy a car", "buy car",
#         "looking for a car", "looking to buy", "help me choose",
#         "which car", "best car for",
#     ])
#
#
# # ---------------------------------------------------------------------------
# # Slot extraction
# # ---------------------------------------------------------------------------
#
# def extract_budget(text: str) -> Optional[float]:
#     t = _low(text).replace(",", "")
#     m = re.search(
#         r"(?:under|below|less\s+than|budget|max|<)\s*\$?\s*(\d{4,6}(?:\.\d+)?)", t
#     )
#     if m:
#         try:
#             return float(m.group(1))
#         except Exception:
#             pass
#     m2 = re.search(r"\b(\d{4,6})\b", t)
#     if m2:
#         try:
#             return float(m2.group(1))
#         except Exception:
#             pass
#     return None
#
#
# def extract_seats(text: str) -> Optional[int]:
#     t = _low(text)
#     m = re.search(r"(?:min|minimum|at\s+least|>)\s*(\d+)\s*seat", t)
#     if m:
#         return int(m.group(1))
#     m2 = re.search(r"(\d+)\s*seat", t)
#     if m2:
#         return int(m2.group(1))
#     return None
#
#
# def extract_fuel(text: str) -> Optional[str]:
#     t = _low(text)
#     if "both" in t.split():
#         return "both"
#     if "gasoline" in t or re.search(r"\bgas\b", t):
#         return "gasoline"
#     if "diesel" in t:
#         return "diesel"
#     if "hybrid" in t or "hev" in t:
#         return "hybrid"
#     if re.search(r"\bev\b", t) or "electric" in t:
#         return "ev"
#     return None
#
#
# def extract_body_type(text: str) -> Optional[str]:
#     t = _low(text)
#     if "suv" in t:
#         return "SUV"
#     if "sedan" in t:
#         return "Sedan"
#     if "pickup" in t or "pick-up" in t or "pick up" in t:
#         return "Pickup"
#     if "mpv" in t or "mvp" in t:
#         return "MPV"
#     if re.search(r"\bbus\b", t):
#         return "BUS"
#     return None
#
#
# # ---------------------------------------------------------------------------
# # Feature key detection
# # ---------------------------------------------------------------------------
#
# _FEATURE_MAP: List[Tuple[str, List[str]]] = [
#     ("spec_transmission",                    ["transmission", "gear box", "gearbox"]),
#     ("spec_transmission_type",               ["transmission type"]),
#     ("spec_fuel_tank_capacity",              ["fuel tank", "tank capacity"]),
#     ("spec_srs_airbags",                     ["airbag", "airbags"]),
#     ("seats",                                ["seat number", "how many seats", "seating capacity", "seats", "seat"]),
#     ("spec_ground_clearance",                ["ground clearance", "clearance"]),
#     ("spec_apple_carplay_and_android_auto",  ["apple carplay", "android auto", "carplay"]),
#     ("spec_apple_carplay_or_android_auto",   ["apple carplay", "android auto", "carplay"]),
#     ("spec_panoramic_view_monitor_pvm",      ["360 camera", "360camera", "panoramic view monitor", "pvm", "around view", "360"]),
#     ("spec_blind_spot_monitor_bsm",          ["blind spot monitor", "blind spot", "bsm"]),
#     ("spec_headup_display_hud",              ["head-up display", "heads-up display", "hud", "head up display"]),
#     ("spec_wireless_charger",                ["wireless charg"]),
#     ("spec_wireless_charging",               ["wireless charg"]),
#     ("spec_reverse_camera",                  ["reverse camera", "backup camera", "rear camera"]),
#     ("spec_parking_sensors",                 ["parking sensor"]),
#     ("spec_safety_rating",                   ["safety rating", "ncap"]),
#     ("spec_lane_departure_warning_ldw",      ["lane departure warning", "lane warning", "ldw"]),
#     ("spec_vehicle_stability_control_vsc",   ["vehicle stability control", "stability control", "vsc"]),
#     ("spec_smart_entry",                     ["smart entry", "smart key", "keyless"]),
#     ("spec_ignition",                        ["ignition", "push start"]),
#     ("spec_drive_type",                      ["drive type", "drivetrain", "4wd", "fwd", "awd", "2wd"]),
#     ("spec_displacement",                    ["displacement", "engine size", "engine cc"]),
#     ("spec_engine_type",                     ["engine type", "engine"]),
#     ("spec_wheelbase",                       ["wheelbase", "wheel base"]),
#     ("spec_length___width___height",         ["dimensions", "dimension", "length width height"]),
#     ("spec_max_output",                      ["horsepower", "power output", "max output"]),
#     ("spec_max_torque",                      ["torque"]),
#     ("fuel",                                 ["fuel type", "fuel"]),
# ]
#
#
# def detect_feature_key(text: str) -> Optional[str]:
#     t = _low(text)
#     best_col: Optional[str] = None
#     best_len = 0
#     for col, keywords in _FEATURE_MAP:
#         for kw in keywords:
#             if kw in t and len(kw) > best_len:
#                 best_col = col
#                 best_len = len(kw)
#     return best_col
#
#
# # ---------------------------------------------------------------------------
# # Answer builders
# # ---------------------------------------------------------------------------
#
# def answer_specs_from_csv(full_rows: List[Dict[str, Any]], model_name: str) -> Dict[str, Any]:
#     row = find_row_by_model(full_rows, model_name)
#     if not row:
#         txt = f"I couldn't find '{model_name}' in the dataset."
#         return {"answer_type": "csv_specs", "text": txt, "facts": [txt], "sources": []}
#
#     name   = row.get("model") or model_name
#     price  = format_price_usd(row.get("price_usd"))
#     seats  = row.get("seats") or "N/A"
#     fuel   = row.get("fuel") or "N/A"
#     body   = row.get("body_type") or "N/A"
#     trans  = row.get("spec_transmission") or row.get("spec_transmission_type") or "N/A"
#     engine = row.get("spec_engine_type") or "N/A"
#     src    = row.get("url") or ""
#
#     txt = (
#         f"Great question! Here's a quick spec overview for the **{name}**:\n\n"
#         f"💰 **Price:** {price}\n"
#         f"🪑 **Seats:** {seats}\n"
#         f"⛽ **Fuel:** {fuel.title() if fuel != 'N/A' else fuel}\n"
#         f"🚗 **Body type:** {body}\n"
#         f"⚙️ **Transmission:** {trans}\n"
#         f"🔧 **Engine:** {engine}"
#     )
#     return {"answer_type": "csv_specs", "text": txt, "facts": [txt], "sources": [src] if src else []}
#
#
# def answer_summary_from_csv(full_rows: List[Dict[str, Any]], model_name: str) -> Dict[str, Any]:
#     row = find_row_by_model(full_rows, model_name)
#     if not row:
#         txt = f"I couldn't find '{model_name}' in the dataset."
#         return {"answer_type": "csv_summary", "text": txt, "facts": [txt], "sources": []}
#
#     name  = row.get("model") or model_name
#     price = format_price_usd(row.get("price_usd"))
#     seats = row.get("seats") or "N/A"
#     fuel  = row.get("fuel") or "N/A"
#     body  = row.get("body_type") or "N/A"
#     trans = row.get("spec_transmission") or row.get("spec_transmission_type") or "N/A"
#     src   = row.get("url") or ""
#
#     txt = (
#         f"Sure! Here's a quick overview of the **{name}**:\n\n"
#         f"The {name} is a {fuel.title() if fuel != 'N/A' else fuel}-powered {body} "
#         f"priced at **{price}**. It seats up to **{seats} passengers** and comes with "
#         f"a **{trans}** transmission. A solid choice if you're looking for a reliable {body}! 😊"
#     )
#     return {"answer_type": "csv_summary", "text": txt, "facts": [txt], "sources": [src] if src else []}
#
#
# def answer_price_from_csv(full_rows: List[Dict[str, Any]], model_name: str) -> Dict[str, Any]:
#     row = find_row_by_model(full_rows, model_name)
#     if not row:
#         txt = f"I couldn't find '{model_name}' in the dataset."
#         return {"answer_type": "csv_price", "text": txt, "facts": [txt], "sources": []}
#
#     name  = row.get("model") or model_name
#     price = format_price_usd(row.get("price_usd"))
#     src   = row.get("url") or ""
#
#     txt = f"The **{name}** is priced at **{price}** (USD). Would you like to know more about its specs or features? 😊"
#     return {"answer_type": "csv_price", "text": txt, "facts": [txt], "sources": [src] if src else []}
#
#
# def answer_feature_from_csv(
#     full_rows: List[Dict[str, Any]],
#     model_name: str,
#     feature_key: str,
# ) -> Optional[Dict[str, Any]]:
#     """Return feature answer or None if value is missing."""
#     row = find_row_by_model(full_rows, model_name)
#     if not row:
#         return None
#
#     name = row.get("model") or model_name
#     src  = row.get("url") or ""
#
#     if feature_key == "seats":
#         val = row.get("seats") or row.get("spec_seating_capacity") or ""
#     elif feature_key == "fuel":
#         val = row.get("fuel") or ""
#     else:
#         val = row.get(feature_key) or ""
#
#     val_str = str(val).strip()
#     if not val_str:
#         return None
#
#     _LABELS: Dict[str, str] = {
#         "spec_transmission":                    "Transmission",
#         "spec_transmission_type":               "Transmission type",
#         "spec_fuel_tank_capacity":              "Fuel tank capacity",
#         "spec_srs_airbags":                     "SRS airbags",
#         "seats":                                "Seats",
#         "spec_ground_clearance":                "Ground clearance",
#         "spec_apple_carplay_and_android_auto":  "Apple CarPlay / Android Auto",
#         "spec_apple_carplay_or_android_auto":   "Apple CarPlay / Android Auto",
#         "spec_panoramic_view_monitor_pvm":      "360° Panoramic View Monitor",
#         "spec_blind_spot_monitor_bsm":          "Blind Spot Monitor",
#         "spec_headup_display_hud":              "Head-Up Display",
#         "spec_wireless_charger":                "Wireless charger",
#         "spec_wireless_charging":               "Wireless charging",
#         "spec_reverse_camera":                  "Reverse camera",
#         "spec_parking_sensors":                 "Parking sensors",
#         "spec_safety_rating":                   "Safety rating",
#         "spec_lane_departure_warning_ldw":      "Lane Departure Warning",
#         "spec_vehicle_stability_control_vsc":   "Vehicle Stability Control",
#         "spec_smart_entry":                     "Smart entry",
#         "spec_ignition":                        "Ignition",
#         "spec_drive_type":                      "Drive type",
#         "spec_displacement":                    "Displacement",
#         "spec_engine_type":                     "Engine type",
#         "spec_wheelbase":                       "Wheelbase",
#         "spec_length___width___height":         "Dimensions (L×W×H)",
#         "spec_max_output":                      "Max output",
#         "spec_max_torque":                      "Max torque",
#         "fuel":                                 "Fuel type",
#     }
#     label = _LABELS.get(feature_key, feature_key.replace("spec_", "").replace("_", " ").title())
#
#     _YES = {"included", "yes", "available", "standard"}
#     _NO  = {"not available", "n/a", "no", "not included"}
#
#     vl = val_str.lower()
#     if vl in _YES:
#         verdict = "Yes"
#     elif vl in _NO:
#         verdict = "No"
#     else:
#         verdict = val_str
#
#     # Build a conversational sentence based on feature type
#     vl = verdict.lower()
#     if vl == "yes":
#         txt = f"Yes! The **{name}** does come with **{label}** as standard. 👍"
#     elif vl == "no":
#         txt = f"Unfortunately, the **{name}** does not include **{label}**."
#     else:
#         txt = f"The **{name}** has a **{label}** of: **{verdict}**."
#     return {"answer_type": "csv_feature", "text": txt, "facts": [txt], "sources": [src] if src else []}
#
#
# # ---------------------------------------------------------------------------
# # Recommendation filtering
# # ---------------------------------------------------------------------------
#
# def filter_cars_split(
#     full_rows: List[Dict[str, Any]],
#     max_budget: float,
#     min_seats: int,
#     fuel: Optional[str],
#     body_type: Optional[str],
# ) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
#     """Return (verified_matches, possible_matches_seats_short)."""
#     verified, possible = [], []
#     for r in full_rows:
#         try:
#             price = float(str(r.get("price_usd", "0")).replace(",", "").replace("$", ""))
#         except Exception:
#             continue
#         if price > max_budget:
#             continue
#
#         rfuel = _low(r.get("fuel") or "")
#         rbody = _low(r.get("body_type") or "")
#         fuel_ok = fuel is None or fuel == "both" or fuel in rfuel
#         body_ok = body_type is None or _low(body_type) == rbody
#
#         try:
#             rseats = int(str(r.get("seats") or "0").strip())
#         except Exception:
#             rseats = 0
#
#         seats_ok = min_seats == 0 or rseats >= min_seats
#
#         if fuel_ok and body_ok:
#             (verified if seats_ok else possible).append(r)
#
#     return verified, possible
#
#
# def build_reco_answer(
#     verified: List[Dict[str, Any]],
#     possible: List[Dict[str, Any]],
#     max_items: int = 5,
#     assumed_seats: Optional[int] = None,
# ) -> Dict[str, Any]:
#     if not verified and not possible:
#         txt = (
#             "Hmm, I couldn't find a perfect match with those filters. "
#             "You might want to try a slightly higher budget or a different body type / fuel. "
#             "I'm happy to help you adjust! 😊"
#         )
#         return {"answer_type": "csv_reco", "text": txt, "facts": [txt], "sources": []}
#
#     show    = verified or possible
#     note    = "" if verified else "\n_(These may not fully meet your seat requirement — feel free to ask me for alternatives!)_"
#     lines   = ["Great news! Here are some Toyota models that match your preferences:\n"]
#     sources: List[str] = []
#
#     for i, r in enumerate(show[:max_items], 1):
#         name  = r.get("model") or "N/A"
#         price = format_price_usd(r.get("price_usd"))
#         seats = r.get("seats") or "N/A"
#         rfuel = (r.get("fuel") or "N/A").title()
#         rbody = r.get("body_type") or "N/A"
#         lines.append(f"{i}. **{name}**")
#         lines.append(f"   💰 {price}  |  🪑 {seats} seats  |  ⛽ {rfuel}  |  🚗 {rbody}")
#         u = r.get("url") or ""
#         if u and u not in sources:
#             sources.append(u)
#
#     lines.append("\nWould you like more details on any of these? I can show specs, features, or pre-owned options too! 😊")
#     if note:
#         lines.append(note)
#     txt = "\n".join(lines)
#     return {"answer_type": "csv_reco", "text": txt, "facts": [txt], "sources": sources}

from __future__ import annotations

import csv
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

# ---------------------------------------------------------------------------
# Path resolution
# ---------------------------------------------------------------------------

_SCRIPTS_DIR = Path(__file__).resolve().parent        # …/scripts/
_PROJECT_ROOT = _SCRIPTS_DIR.parent                   # …/Chat-04-Feb 2/


def _find_csv(filename: str, override: Optional[str] = None) -> Path:
    """
    Search everywhere and return first match, or raise clear FileNotFoundError.
    """
    # 1. Explicit override always wins
    if override:
        p = Path(override).expanduser().resolve()
        if p.exists():
            return p

    # 2. Common fixed locations (fast)
    fixed = [
        _SCRIPTS_DIR / filename,
        _PROJECT_ROOT / filename,
        _PROJECT_ROOT / "data" / filename,
        _PROJECT_ROOT / "data_new" / filename,
        _PROJECT_ROOT / "data_vehicle" / filename,
        _PROJECT_ROOT / "data_preowned" / filename,
        _PROJECT_ROOT / "data_preowned" / "csv_preowned" / filename,
        _PROJECT_ROOT / "csv" / filename,
        _PROJECT_ROOT / "assets" / filename,
        _PROJECT_ROOT.parent / filename,
        _PROJECT_ROOT.parent / "data" / filename,
    ]
    for p in fixed:
        if p.exists():
            return p

    # 3. Recursive glob — finds the file no matter which subfolder it is in
    for p in _PROJECT_ROOT.rglob(filename):
        return p

    # 4. One level up (covers sibling project structures)
    for p in _PROJECT_ROOT.parent.rglob(filename):
        return p

    raise FileNotFoundError(
        f"\n\n[csv_engine] Cannot find '{filename}'.\n"
        f"Searched recursively under:\n"
        f"  {_PROJECT_ROOT}\n"
        f"  {_PROJECT_ROOT.parent}\n\n"
        f"Quick fix — copy '{filename}' to:\n"
        f"  {_PROJECT_ROOT / filename}\n"
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _low(s: Any) -> str:
    return (str(s) or "").strip().lower()


def _norm_ws(s: str) -> str:
    return re.sub(r"\s+", " ", s.strip())


def format_price_usd(value: Any) -> str:
    if value in (None, "", "N/A"):
        return "N/A"
    try:
        v = float(str(value).replace(",", "").replace("$", "").strip())
        return f"${int(v):,}" if v == int(v) else f"${v:,.2f}"
    except Exception:
        return str(value).strip() or "N/A"


# ---------------------------------------------------------------------------
# Load rows
# ---------------------------------------------------------------------------

def load_full_rows(csv_path: Optional[str] = None) -> List[Dict[str, Any]]:
    """
    Load and return all rows from vehicle_master.csv.

    Args:
        csv_path: Optional explicit path to the CSV. Searches common project
                  locations automatically if not given.

    Returns:
        List of row dicts (one per vehicle variant).

    Raises:
        FileNotFoundError: with helpful message listing all searched locations.
    """
    path = _find_csv("vehicle_master.csv", override=csv_path)
    print(f"[csv_engine] vehicle CSV: {path}")
    with open(path, encoding="utf-8-sig", newline="") as f:
        rows = [dict(r) for r in csv.DictReader(f)]
    return rows


# ---------------------------------------------------------------------------
# Model detection
# ---------------------------------------------------------------------------

_MODEL_ALIASES: Dict[str, str] = {
    # ── Corolla Cross ──────────────────────────────────────────────────────
    "corolla cross gasoline": "COROLLA CROSS GASOLINE",
    "corolla cross hev": "Corolla Cross HEV",
    "corolla cross hybrid": "Corolla Cross HEV",
    "corolla cross": "COROLLA CROSS GASOLINE",

    # ── Fortuner ──────────────────────────────────────────────────────────
    "fortuner legender": "Fortuner Legender",
    "fortuner": "Fortuner Legender",

    # ── Hiace ─────────────────────────────────────────────────────────────
    "hiace 12-seater": "Hiace 12-seater",
    "hiace 12 seater": "Hiace 12-seater",
    "hiace 12": "Hiace 12-seater",
    "hiace 16-seater": "Hiace 16-seater",
    "hiace 16 seater": "Hiace 16-seater",
    "hiace 16": "Hiace 16-seater",

    # ── Hilux ─────────────────────────────────────────────────────────────
    "hilux revo rally": "Hilux Revo Rally",
    "hilux rally": "Hilux Revo Rally",
    "hilux revo v-edition": "Hilux Revo V-Edition",
    "hilux revo v edition": "Hilux Revo V-Edition",
    "hilux v-edition": "Hilux Revo V-Edition",
    "hilux revo v": "Hilux Revo V-Edition",
    "hilux": "Hilux Revo Rally",

    # 1. FIX: Add Rocco + Hilux Revo aliases (for compare like "hilux revo vs revo rocco")
    # Note: Ensure your CSV model column contains exactly "Hilux Revo Rocco"; if not, change canonical here.
    "revo rocco": "Hilux Revo Rocco",
    "hilux revo rocco": "Hilux Revo Rocco",
    "hilux rocco": "Hilux Revo Rocco",
    "hilux revo": "Hilux Revo Rally",

    # ── Land Cruiser ──────────────────────────────────────────────────────
    "land cruiser 250 diesel": "Land Cruiser 250 Diesel",
    "land cruiser 250 gasoline": "Land Cruiser 250 Gasoline",
    "land cruiser 250": "Land Cruiser 250 Diesel",
    "land cruiser gr-s": "LAND CRUISER GR-S",
    "land cruiser gr s": "LAND CRUISER GR-S",
    "land cruiser grs": "LAND CRUISER GR-S",
    "land cruiser gr": "LAND CRUISER GR-S",
    "land cruiser zx": "Land Cruiser ZX",
    "land cruiser": "Land Cruiser ZX",

    # ── Others ────────────────────────────────────────────────────────────
    "raize": "Raize",
    "veloz": "Veloz",
    "vios": "Vios",
    "wigo": "Wigo",
    "yaris cross hev": "Yaris Cross HEV",
    "yaris cross hybrid": "Yaris Cross HEV",
    "yaris cross gasoline": "YARIS CROSS GASOLINE",
    "yaris cross": "Yaris Cross HEV",
}


def _canonical_model_names(full_rows: List[Dict[str, Any]]) -> List[str]:
    seen: set = set()
    names: List[str] = []
    for r in full_rows:
        m = (r.get("model") or "").strip()
        if m and m not in seen:
            seen.add(m)
            names.append(m)
    return names


def detect_model_in_text(text: str, full_rows: List[Dict[str, Any]]) -> Optional[str]:
    """
    Return CSV model name found in text (longest alias wins), or None.
    """
    t = _norm_ws(_low(text))

    # 1. Alias table — sorted longest-first so specific beats general
    for alias in sorted(_MODEL_ALIASES, key=len, reverse=True):
        if alias in t:
            canonical = _MODEL_ALIASES[alias]
            for r in full_rows:
                if _low(r.get("model", "")) == _low(canonical):
                    return r["model"]
            return canonical

    # 2. Direct match against CSV names
    names = _canonical_model_names(full_rows)
    for name in sorted(names, key=len, reverse=True):
        if _low(name) in t:
            return name

    return None


def detect_models_in_text(
    text: str,
    full_rows: List[Dict[str, Any]],
    max_models: int = 2,
) -> List[str]:
    """
    Return up to max_models distinct model names found in text.

    2. FIX: Includes alias detection (so "revo rocco" gets detected as a model).
    """
    t = _norm_ws(_low(text))
    found: List[str] = []
    used: List[Tuple[int, int]] = []

    def _add_model(model_name: str, start: int, end: int) -> None:
        if model_name and model_name not in found:
            found.append(model_name)
            used.append((start, end))

    # 2.1 Alias detection first (longest-first)
    for alias in sorted(_MODEL_ALIASES, key=len, reverse=True):
        idx = t.find(alias)
        if idx == -1:
            continue
        end = idx + len(alias)

        if any(s <= idx < e or s < end <= e for s, e in used):
            continue

        canonical = _MODEL_ALIASES[alias]
        resolved = None
        for r in full_rows:
            if _low(r.get("model", "")) == _low(canonical):
                resolved = r.get("model")
                break

        _add_model(resolved or canonical, idx, end)

        if len(found) >= max_models:
            return found[:max_models]

    # 2.2 Canonical model names next
    for name in sorted(_canonical_model_names(full_rows), key=len, reverse=True):
        pattern = _low(name)
        idx = t.find(pattern)
        if idx == -1:
            continue
        end = idx + len(pattern)

        if any(s <= idx < e or s < end <= e for s, e in used):
            continue

        _add_model(name, idx, end)

        if len(found) >= max_models:
            break

    return found[:max_models]


def resolve_target_model(
    user_text: str,
    last_model: Optional[str],
    full_rows: List[Dict[str, Any]],
) -> Optional[str]:
    """
    Model from text first; then fall back to last_model for follow-ups.
    """
    m = detect_model_in_text(user_text, full_rows)
    return m if m else last_model


def find_row_by_model(
    full_rows: List[Dict[str, Any]],
    model_name: str,
) -> Optional[Dict[str, Any]]:
    m = _low(model_name)
    for r in full_rows:
        if _low(r.get("model", "")) == m:
            return r
    return None


# ---------------------------------------------------------------------------
# Intent detection
# ---------------------------------------------------------------------------

def is_spec_intent(text: str) -> bool:
    return any(k in _low(text) for k in ["spec", "specification"])


def is_summary_intent(text: str) -> bool:
    t = _low(text)
    return "summary" in t or "overview" in t or "tell me about" in t


def is_recommendation_intent(text: str) -> bool:
    t = _low(text)
    return any(k in t for k in [
        "recommend",
        "suggest",
        "i want to buy",
        "buy a car",
        "buy car",
        "looking for a car",
        "looking to buy",
        "help me choose",
        "which car",
        "best car for",
    ])


# ---------------------------------------------------------------------------
# Slot extraction
# ---------------------------------------------------------------------------

def extract_budget(text: str) -> Optional[float]:
    t = _low(text).replace(",", "")
    m = re.search(
        r"(?:under|below|less\s+than|budget|max|<)\s*\$?\s*(\d{4,6}(?:\.\d+)?)",
        t
    )
    if m:
        try:
            return float(m.group(1))
        except Exception:
            pass

    m2 = re.search(r"\b(\d{4,6})\b", t)
    if m2:
        try:
            return float(m2.group(1))
        except Exception:
            pass
    return None


def extract_seats(text: str) -> Optional[int]:
    t = _low(text)
    m = re.search(r"(?:min|minimum|at\s+least|>)\s*(\d+)\s*seat", t)
    if m:
        return int(m.group(1))
    m2 = re.search(r"(\d+)\s*seat", t)
    if m2:
        return int(m2.group(1))
    return None


def extract_fuel(text: str) -> Optional[str]:
    t = _low(text)
    if "both" in t.split():
        return "both"
    if "gasoline" in t or re.search(r"\bgas\b", t):
        return "gasoline"
    if "diesel" in t:
        return "diesel"
    if "hybrid" in t or "hev" in t:
        return "hybrid"
    if re.search(r"\bev\b", t) or "electric" in t:
        return "ev"
    return None


def extract_body_type(text: str) -> Optional[str]:
    t = _low(text)
    if "suv" in t:
        return "SUV"
    if "sedan" in t:
        return "Sedan"
    if "pickup" in t or "pick-up" in t or "pick up" in t:
        return "Pickup"
    if "mpv" in t or "mvp" in t:
        return "MPV"
    if re.search(r"\bbus\b", t):
        return "BUS"
    return None


# ---------------------------------------------------------------------------
# Feature key detection
# ---------------------------------------------------------------------------

_FEATURE_MAP: List[Tuple[str, List[str]]] = [
    ("spec_transmission", ["transmission", "gear box", "gearbox"]),
    ("spec_transmission_type", ["transmission type"]),
    ("spec_fuel_tank_capacity", ["fuel tank", "tank capacity"]),
    ("spec_srs_airbags", ["airbag", "airbags"]),
    ("seats", ["seat number", "how many seats", "seating capacity", "seats", "seat"]),
    ("spec_ground_clearance", ["ground clearance", "clearance"]),
    ("spec_apple_carplay_and_android_auto", ["apple carplay", "android auto", "carplay"]),
    ("spec_apple_carplay_or_android_auto", ["apple carplay", "android auto", "carplay"]),
    ("spec_panoramic_view_monitor_pvm", ["360 camera", "360camera", "panoramic view monitor", "pvm", "around view", "360"]),
    ("spec_blind_spot_monitor_bsm", ["blind spot monitor", "blind spot", "bsm"]),
    ("spec_headup_display_hud", ["head-up display", "heads-up display", "hud", "head up display"]),
    ("spec_wireless_charger", ["wireless charg"]),
    ("spec_wireless_charging", ["wireless charg"]),
    ("spec_reverse_camera", ["reverse camera", "backup camera", "rear camera"]),
    ("spec_parking_sensors", ["parking sensor"]),
    ("spec_safety_rating", ["safety rating", "ncap"]),
    ("spec_lane_departure_warning_ldw", ["lane departure warning", "lane warning", "ldw"]),
    ("spec_vehicle_stability_control_vsc", ["vehicle stability control", "stability control", "vsc"]),
    ("spec_smart_entry", ["smart entry", "smart key", "keyless"]),
    ("spec_ignition", ["ignition", "push start"]),
    ("spec_drive_type", ["drive type", "drivetrain", "4wd", "fwd", "awd", "2wd"]),
    ("spec_displacement", ["displacement", "engine size", "engine cc"]),
    ("spec_engine_type", ["engine type", "engine"]),
    ("spec_wheelbase", ["wheelbase", "wheel base"]),
    ("spec_length___width___height", ["dimensions", "dimension", "length width height"]),
    ("spec_max_output", ["horsepower", "power output", "max output"]),
    ("spec_max_torque", ["torque"]),
    ("fuel", ["fuel type", "fuel"]),

    # 3. FIX: Cruise control support (Fortuner cruise control test)
    ("spec_cruise_control", ["cruise control", "cruise"]),
]


def detect_feature_key(text: str) -> Optional[str]:
    t = _low(text)
    best_col: Optional[str] = None
    best_len = 0
    for col, keywords in _FEATURE_MAP:
        for kw in keywords:
            if kw in t and len(kw) > best_len:
                best_col = col
                best_len = len(kw)
    return best_col


# ---------------------------------------------------------------------------
# Answer builders
# ---------------------------------------------------------------------------

def answer_specs_from_csv(full_rows: List[Dict[str, Any]], model_name: str) -> Dict[str, Any]:
    row = find_row_by_model(full_rows, model_name)
    if not row:
        txt = f"I couldn't find '{model_name}' in the dataset."
        return {"answer_type": "csv_specs", "text": txt, "facts": [txt], "sources": []}

    name = row.get("model") or model_name
    price = format_price_usd(row.get("price_usd"))
    seats = row.get("seats") or "N/A"
    fuel = row.get("fuel") or "N/A"
    body = row.get("body_type") or "N/A"
    trans = row.get("spec_transmission") or row.get("spec_transmission_type") or "N/A"
    engine = row.get("spec_engine_type") or "N/A"
    src = row.get("url") or ""

    txt = (
        f"Great question! Here's a quick spec overview for the **{name}**:\n\n"
        f"**Price:** {price}\n"
        f"**Seats:** {seats}\n"
        f"**Fuel:** {fuel.title() if fuel != 'N/A' else fuel}\n"
        f"**Body type:** {body}\n"
        f"**Transmission:** {trans}\n"
        f"**Engine:** {engine}"
    )
    return {"answer_type": "csv_specs", "text": txt, "facts": [txt], "sources": [src] if src else []}


def answer_summary_from_csv(full_rows: List[Dict[str, Any]], model_name: str) -> Dict[str, Any]:
    row = find_row_by_model(full_rows, model_name)
    if not row:
        txt = f"I couldn't find '{model_name}' in the dataset."
        return {"answer_type": "csv_summary", "text": txt, "facts": [txt], "sources": []}

    name = row.get("model") or model_name
    price = format_price_usd(row.get("price_usd"))
    seats = row.get("seats") or "N/A"
    fuel = row.get("fuel") or "N/A"
    body = row.get("body_type") or "N/A"
    trans = row.get("spec_transmission") or row.get("spec_transmission_type") or "N/A"
    src = row.get("url") or ""

    txt = (
        f"Sure! Here's a quick overview of the **{name}**:\n\n"
        f"The {name} is a {fuel.title() if fuel != 'N/A' else fuel}-powered {body} "
        f"priced at **{price}**. It seats up to **{seats} passengers** and comes with "
        f"a **{trans}** transmission."
    )
    return {"answer_type": "csv_summary", "text": txt, "facts": [txt], "sources": [src] if src else []}


def answer_price_from_csv(full_rows: List[Dict[str, Any]], model_name: str) -> Dict[str, Any]:
    row = find_row_by_model(full_rows, model_name)
    if not row:
        txt = f"I couldn't find '{model_name}' in the dataset."
        return {"answer_type": "csv_price", "text": txt, "facts": [txt], "sources": []}

    name = row.get("model") or model_name
    price = format_price_usd(row.get("price_usd"))
    src = row.get("url") or ""

    txt = f"The **{name}** is priced at **{price}** (USD). Would you like to know more about its specs or features?"
    return {"answer_type": "csv_price", "text": txt, "facts": [txt], "sources": [src] if src else []}


def answer_feature_from_csv(
    full_rows: List[Dict[str, Any]],
    model_name: str,
    feature_key: str,
) -> Optional[Dict[str, Any]]:
    """
    Return feature answer or None if value is missing.
    """
    row = find_row_by_model(full_rows, model_name)
    if not row:
        return None

    name = row.get("model") or model_name
    src = row.get("url") or ""

    if feature_key == "seats":
        val = row.get("seats") or row.get("spec_seating_capacity") or ""
    elif feature_key == "fuel":
        val = row.get("fuel") or ""
    else:
        # 4. FIX: Cruise control column variations support
        if feature_key == "spec_cruise_control":
            candidates = [
                "spec_cruise_control",
                "spec_adaptive_cruise_control",
                "spec_dynamic_radar_cruise_control_drrc",
                "spec_radar_cruise_control",
            ]
            val = ""
            for k in candidates:
                if row.get(k):
                    val = row.get(k)
                    feature_key = k
                    break

            # Last resort: any column containing 'cruise'
            if not val:
                for k in row.keys():
                    if "cruise" in _low(k) and row.get(k):
                        val = row.get(k)
                        feature_key = k
                        break
        else:
            val = row.get(feature_key) or ""

    val_str = str(val).strip()
    if not val_str:
        return None

    _LABELS: Dict[str, str] = {
        "spec_transmission": "Transmission",
        "spec_transmission_type": "Transmission type",
        "spec_fuel_tank_capacity": "Fuel tank capacity",
        "spec_srs_airbags": "SRS airbags",
        "seats": "Seats",
        "spec_ground_clearance": "Ground clearance",
        "spec_apple_carplay_and_android_auto": "Apple CarPlay / Android Auto",
        "spec_apple_carplay_or_android_auto": "Apple CarPlay / Android Auto",
        "spec_panoramic_view_monitor_pvm": "360° Panoramic View Monitor",
        "spec_blind_spot_monitor_bsm": "Blind Spot Monitor",
        "spec_headup_display_hud": "Head-Up Display",
        "spec_wireless_charger": "Wireless charger",
        "spec_wireless_charging": "Wireless charging",
        "spec_reverse_camera": "Reverse camera",
        "spec_parking_sensors": "Parking sensors",
        "spec_safety_rating": "Safety rating",
        "spec_lane_departure_warning_ldw": "Lane Departure Warning",
        "spec_vehicle_stability_control_vsc": "Vehicle Stability Control",
        "spec_smart_entry": "Smart entry",
        "spec_ignition": "Ignition",
        "spec_drive_type": "Drive type",
        "spec_displacement": "Displacement",
        "spec_engine_type": "Engine type",
        "spec_wheelbase": "Wheelbase",
        "spec_length___width___height": "Dimensions (L×W×H)",
        "spec_max_output": "Max output",
        "spec_max_torque": "Max torque",
        "fuel": "Fuel type",

        # 5. FIX: Cruise control labels
        "spec_cruise_control": "Cruise control",
        "spec_adaptive_cruise_control": "Adaptive cruise control",
        "spec_dynamic_radar_cruise_control_drrc": "Dynamic Radar Cruise Control",
        "spec_radar_cruise_control": "Radar cruise control",
    }
    label = _LABELS.get(feature_key, feature_key.replace("spec_", "").replace("_", " ").title())

    _YES = {"included", "yes", "available", "standard"}
    _NO = {"not available", "n/a", "no", "not included"}

    vl = val_str.lower()
    if vl in _YES:
        verdict = "Yes"
    elif vl in _NO:
        verdict = "No"
    else:
        verdict = val_str

    if verdict.lower() == "yes":
        txt = f"Yes. The **{name}** includes **{label}**."
    elif verdict.lower() == "no":
        txt = f"No. The **{name}** does not include **{label}**."
    else:
        txt = f"The **{name}** has **{label}**: **{verdict}**."

    return {"answer_type": "csv_feature", "text": txt, "facts": [txt], "sources": [src] if src else []}


# ---------------------------------------------------------------------------
# Recommendation filtering
# ---------------------------------------------------------------------------

def filter_cars_split(
    full_rows: List[Dict[str, Any]],
    max_budget: float,
    min_seats: int,
    fuel: Optional[str],
    body_type: Optional[str],
) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    """
    Return (verified_matches, possible_matches_seats_short).
    """
    verified: List[Dict[str, Any]] = []
    possible: List[Dict[str, Any]] = []

    for r in full_rows:
        try:
            price = float(str(r.get("price_usd", "0")).replace(",", "").replace("$", ""))
        except Exception:
            continue
        if price > max_budget:
            continue

        rfuel = _low(r.get("fuel") or "")
        rbody = _low(r.get("body_type") or "")
        fuel_ok = fuel is None or fuel == "both" or fuel in rfuel
        body_ok = body_type is None or _low(body_type) == rbody

        try:
            rseats = int(str(r.get("seats") or "0").strip())
        except Exception:
            rseats = 0

        seats_ok = min_seats == 0 or rseats >= min_seats

        if fuel_ok and body_ok:
            (verified if seats_ok else possible).append(r)

    return verified, possible


def build_reco_answer(
    verified: List[Dict[str, Any]],
    possible: List[Dict[str, Any]],
    max_items: int = 5,
    assumed_seats: Optional[int] = None,
) -> Dict[str, Any]:
    if not verified and not possible:
        txt = (
            "I couldn't find a perfect match with those filters. "
            "Try a slightly higher budget or a different body type / fuel."
        )
        return {"answer_type": "csv_reco", "text": txt, "facts": [txt], "sources": []}

    show = verified or possible
    note = "" if verified else "\n(These may not fully meet your seat requirement.)"
    lines = ["Here are some Toyota models that match your preferences:\n"]
    sources: List[str] = []

    for i, r in enumerate(show[:max_items], 1):
        name = r.get("model") or "N/A"
        price = format_price_usd(r.get("price_usd"))
        seats = r.get("seats") or "N/A"
        rfuel = (r.get("fuel") or "N/A").title()
        rbody = r.get("body_type") or "N/A"
        lines.append(f"{i}. {name}")
        lines.append(f"   {price} | {seats} seats | {rfuel} | {rbody}")
        u = r.get("url") or ""
        if u and u not in sources:
            sources.append(u)

    lines.append("\nReply with a listing number (1–10) or model name to see more details.")
    if note:
        lines.append(note)

    txt = "\n".join(lines)
    return {"answer_type": "csv_reco", "text": txt, "facts": [txt], "sources": sources}














