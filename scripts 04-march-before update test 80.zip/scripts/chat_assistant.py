# scripts/chat_assistant.py
"""
Toyota Chatbot - Chat Assistant Router

This file routes user messages into:
- SYSTEM (small talk / reset / prompts)
- CSV_METHOD (official dataset answers)
- PREOWNED_RAG (used/pre-owned listings)
- RAG (fallback, if enabled)
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Dict, List, Optional

_SCRIPTS_DIR = Path(__file__).resolve().parent
_PROJECT_ROOT = _SCRIPTS_DIR.parent
from scripts.response_style import style_answer, DEFAULT_STYLE
# 1: CSV / Recommendation engine functions
from scripts.csv_engine import (
    detect_feature_key,
    detect_model_in_text,
    detect_models_in_text,
    resolve_target_model,
    answer_feature_from_csv,
    answer_price_from_csv,
    answer_specs_from_csv,
    answer_summary_from_csv,
    is_recommendation_intent,
    is_spec_intent,
    is_summary_intent,
    extract_budget,
    extract_seats,
    extract_fuel,
    extract_body_type,
    filter_cars_split,
    build_reco_answer,
    find_row_by_model,
    format_price_usd,
    load_full_rows,
)

# 2: Pre-owned engine
from scripts.preowned_engine import PreownedEngine, is_preowned_intent


# 3: RAG fallback
class SimpleRAG:
    available = False

    def __init__(self, rows: List[Dict[str, Any]]):
        self.rows = rows

    def rag_answer(self, user_text: str, last_model_norm: Optional[str] = None) -> Dict[str, Any]:
        msg = (
            "That's a great question, but unfortunately I don't have that information in our dataset. "
            "Feel free to ask about price, specs, features, comparisons, recommendations, or pre-owned listings."
        )
        return {"answer_type": "system", "text": msg, "facts": [msg], "sources": []}


def build_rag_engine(rows: List[Dict[str, Any]]):
    try:
        from scripts.rag_engine import CompositeRAGEngine  # type: ignore
        eng = CompositeRAGEngine(rows)
        setattr(eng, "available", True)
        return eng
    except Exception:
        return SimpleRAG(rows)


def build_preowned_engine(preowned_csv_path: Optional[str] = None) -> PreownedEngine:
    return PreownedEngine(csv_path=preowned_csv_path)


# 4: Helpers
def _low(s: Any) -> str:
    return (str(s) or "").strip().lower()


def _clean(text: str) -> str:
    t = (text or "").strip()
    t = re.sub(r"^\s*\d+[\.\)]\s*", "", t)  # remove "1) " prefix
    t = t.strip('"\'`\u201c\u201d\u2018\u2019')
    t = re.sub(r"\s+", " ", t).strip()
    return t


def _pipe(res: Dict[str, Any], pipeline: str) -> Dict[str, Any]:
    out = dict(res)
    out["pipeline"] = pipeline
    if "text" not in out:
        out["text"] = out.get("answer") or ""
    if "answer" not in out:
        out["answer"] = out.get("text") or ""
    return out


def _sys(text: str) -> Dict[str, Any]:
    return _pipe({"answer_type": "system", "text": text, "facts": [text], "sources": []}, "SYSTEM")


def _csv_prompt(text: str) -> Dict[str, Any]:
    # For recommendation slot-filling prompts, your QA expects CSV_METHOD pipeline (not SYSTEM)
    return _pipe({"answer_type": "system", "text": text, "facts": [text], "sources": []}, "CSV_METHOD")


def _reset_state(state: Dict[str, Any]) -> None:
    state.clear()
    state.update(
        {
            "last_model": None,
            "slots": {"max_budget": None, "min_seats": None, "fuel": None, "body_type": None},
            "slot_fill_active": False,
        }
    )


def _cancel_reco_flow(state: Dict[str, Any]) -> None:
    state["slot_fill_active"] = False
    state["slots"] = {"max_budget": None, "min_seats": None, "fuel": None, "body_type": None}


def _missing_slots(slots: Dict[str, Any]) -> List[str]:
    missing: List[str] = []
    if slots.get("max_budget") is None:
        missing.append("budget")
    if not slots.get("body_type"):
        missing.append("body")
    if not slots.get("fuel"):
        missing.append("fuel")
    return missing


# 5: System message classification
def _is_small_talk(text: str) -> bool:
    t = (text or "").strip().lower()
    exact = {
        "hi",
        "hello",
        "hey",
        "hii",
        "thanks",
        "thank you",
        "ty",
        "ok",
        "okay",
        "bye",
        "goodbye",
    }
    if t in exact:
        return True
    for p in ("hi ", "hello ", "hey ", "thanks ", "thank you "):
        if t.startswith(p):
            return True
    return False


def _welcome_text() -> str:
    return (
        "Hello! Welcome to Toyota Cambodia. I'm here to help you.\n\n"
        "You can ask me about:\n"
        "• Price & specs of any Toyota model\n"
        "• Features (CarPlay, 360 camera, airbags, seats)\n"
        "• Compare two models\n"
        "• Recommendations based on your budget\n"
        "• Pre-owned / used listings\n\n"
        "What would you like to know?"
    )


def _is_not_answerable(text: str) -> bool:
    t = _low(text)

    if re.search(r"\b0[-–]100\b|\b0\s+to\s+100\b|\bacceleration\b", t):
        return True

    # "best" / "popular" in Cambodia are not in dataset -> must be SYSTEM (prevents random RAG)
    if re.search(r"\b(best|most popular|popular)\b", t) and (
        "cambodia" in t or "overall" in t or "toyota" in t
    ):
        return True

    if "best car" in t and ("cambodia" in t or "overall" in t):
        return True

    return False


def _is_general_knowledge_question(user_text: str, full_rows: List[Dict[str, Any]]) -> bool:
    """
    Route general definitions/explanations to RAG, not CSV feature answers (prevents "Yes Veloz has BSM" bug).
    Only triggers when the user did NOT mention a specific model.
    """
    t = _low(user_text)

    if detect_model_in_text(user_text, full_rows):
        return False

    # question forms
    ask_form = (
        t.startswith("what is")
        or t.startswith("what's")
        or t.startswith("how does")
        or t.startswith("how do")
        or t.startswith("why")
        or "benefit" in t
        or "maintenance cost" in t
        or "fuel efficient" in t
        or "battery lifespan" in t
    )
    if not ask_form:
        return False

    # key automotive/EV/hybrid safety terms
    terms = [
        "hybrid technology",
        "hybrid",
        "hev",
        "ev",
        "electric vehicle",
        "toyota safety sense",
        "safety sense",
        "blind spot monitor",
        "blind spot monitoring",
        "bsm",
        "adaptive cruise control",
        "regenerative braking",
        "regen braking",
        "fuel efficient",
        "maintenance cost",
        "battery lifespan",
    ]
    return any(term in t for term in terms)


def _is_warranty_or_services_info_question(user_text: str) -> bool:
    """
    Guard: prevents routing warranty/services questions to PREOWNED just because they contain 'km'.
    Example: 'warranty period km' must NOT trigger PREOWNED.
    """
    t = _low(user_text)

    if re.search(r"\b(warranty|guarantee|coverage|covered|oem)\b", t):
        return True

    if re.search(r"\b(service\s+package|servicing\s+package|servicing|maintenance|repair|service\s+center|workshop)\b", t):
        return True

    return False


def _looks_like_preowned_listing_query(user_text: str) -> bool:
    """
    Tighten PREOWNED routing.
    'km' alone is not enough. Require a stronger listing signal.
    """
    t = _low(user_text)

    strong_terms = [
        "preowned",
        "pre-owned",
        "pre owned",
        "used",
        "second hand",
        "certified",
        "cpo",
        "toyota certified",
        "listing",
        "listings",
        "plate",
        "vin",
        "odometer",
        "mileage",
    ]
    if any(k in t for k in strong_terms):
        return True

    # plate-like patterns (very common in your outputs)
    if re.search(r"\bpp-\d", t) or re.search(r"\b[a-z]{1,3}-[a-z]?-?\d", t):
        return True

    # If 'km' present, require another listing signal like year/price/mileage word
    if "km" in t:
        if re.search(r"\b(20\d{2}|price|\$|usd|year|mileage|odometer)\b", t):
            return True

    return False


# 6: Compare parsing (fix: versus/with/vs/and + difference/better/between/or)
def _is_compare_intent(text: str) -> bool:
    t = _low(text)

    if re.search(r"\bcompare\b", t):
        return True
    if re.search(r"\bvs\b", t):
        return True
    if re.search(r"\bversus\b", t):
        return True
    if re.search(r"\bdifference\b", t) and re.search(r"\bbetween\b", t):
        return True
    if re.search(r"\bwhich\b.*\bbetter\b", t):
        return True
    if re.search(r"\bbetter\b", t) and re.search(r"\bor\b", t):
        return True

    return False


def _extract_compare_models(user_text: str, full_rows: List[Dict[str, Any]]) -> List[str]:
    # Try direct detection first
    models = detect_models_in_text(user_text, full_rows, max_models=2)
    if len(models) >= 2:
        return models[:2]

    low = _low(user_text)

    # Patterns: "difference between A and B", "between A and B"
    m = re.search(r"\bbetween\s+(.*?)\s+\band\s+(.*)$", low)
    if m:
        left = (m.group(1) or "").strip()
        right = (m.group(2) or "").strip()
        a = detect_model_in_text(left, full_rows)
        b = detect_model_in_text(right, full_rows)
        if a and b and a != b:
            return [a, b]

    # Patterns: "A or B"
    m2 = re.search(r"^(.*?)\s+\bor\s+(.*)$", low)
    if m2:
        left = (m2.group(1) or "").strip()
        right = (m2.group(2) or "").strip()
        a = detect_model_in_text(left, full_rows)
        b = detect_model_in_text(right, full_rows)
        if a and b and a != b:
            return [a, b]

    # Generic split-based fallback
    for sep in (r"\bvs\b", r"\bversus\b", r"\bwith\b", r"\band\b"):
        parts = re.split(sep, low, maxsplit=1)
        if len(parts) != 2:
            continue
        left = parts[0].strip()
        right = parts[1].strip()
        a = detect_model_in_text(left, full_rows)
        b = detect_model_in_text(right, full_rows)
        if a and b and a != b:
            return [a, b]

    one = detect_model_in_text(user_text, full_rows)
    return [one] if one else []


def _do_compare(full_rows: List[Dict[str, Any]], a: str, b: str) -> Dict[str, Any]:
    row_a = find_row_by_model(full_rows, a)
    row_b = find_row_by_model(full_rows, b)

    if not row_a or not row_b:
        missing = a if not row_a else b
        msg = f"I couldn't find '{missing}' in the dataset."
        return {"answer_type": "csv_compare", "text": msg, "facts": [msg], "sources": []}

    def v(row: Dict[str, Any], key: str) -> str:
        val = row.get(key)
        if val is None or str(val).strip() == "":
            return "N/A"
        return str(val).strip()

    name_a = row_a.get("model") or a
    name_b = row_b.get("model") or b

    lines = [
        f"Here’s a quick comparison (official dataset): {name_a} vs {name_b}",
        f"- Price: {format_price_usd(row_a.get('price_usd'))} vs {format_price_usd(row_b.get('price_usd'))}",
        f"- Seats: {v(row_a, 'seats')} vs {v(row_b, 'seats')}",
        f"- Fuel: {v(row_a, 'fuel')} vs {v(row_b, 'fuel')}",
        f"- Body type: {v(row_a, 'body_type')} vs {v(row_b, 'body_type')}",
        f"- Transmission: {v(row_a, 'spec_transmission')} vs {v(row_b, 'spec_transmission')}",
    ]
    txt = "\n".join(lines)
    sources = []
    if row_a.get("url"):
        sources.append(row_a["url"])
    if row_b.get("url"):
        sources.append(row_b["url"])
    return {"answer_type": "csv_compare", "text": txt, "facts": [txt], "sources": sources}


# 7: Recommendation quick-filter detection (under $45000 gasoline)
def _looks_like_filter(user_text: str, full_rows: List[Dict[str, Any]]) -> bool:
    t = _low(user_text)

    has_budget = extract_budget(user_text) is not None or any(k in t for k in ["under", "below", "less than", "budget", "max"])
    has_body = extract_body_type(user_text) is not None or any(k in t for k in ["suv", "sedan", "pickup", "mpv", "bus"])
    has_fuel = extract_fuel(user_text) is not None or any(k in t for k in ["gasoline", "petrol", "diesel", "hybrid", "hev", "ev", "electric"])
    has_model = detect_model_in_text(user_text, full_rows) is not None

    return (not has_model) and has_budget and (has_body or has_fuel)


# def chat_turn(
#     user_text: str,
#     state: Dict[str, Any],
#     full_rows: List[Dict[str, Any]],
#     rag_engine: Any,
#     preowned_engine: PreownedEngine,
#     debug: bool = False,
# ) -> Dict[str, Any]:
#     # 8: Init
#     if not state:
#         _reset_state(state)
#
#     user_text = _clean(user_text)
#     if not user_text:
#         return _sys("Please type a question.")
#
#     t0 = _low(user_text)
#
#     # 9: Reset must be first
#     if t0 in {"/reset", "reset"}:
#         _reset_state(state)
#         return _sys("Reset done.")
#
#     # 10: Small talk must be before any other routing
#     if _is_small_talk(user_text):
#         t = _low(user_text)
#         if t in {"thanks", "thank you", "ty"}:
#             return _sys("You're welcome. What would you like to know about Toyota Cambodia?")
#         if t in {"bye", "goodbye"}:
#             return _sys("Bye. If you need anything about Toyota models, price, specs, or services, just ask.")
#         return _sys(_welcome_text())
#
#     # 11: Not answerable (SYSTEM)
#     if _is_not_answerable(user_text):
#         return _sys(
#             "That's a great question, but unfortunately I don't have that information in our dataset. "
#             "Feel free to ask about price, specs, features, comparisons, recommendations, or pre-owned listings."
#         )
#
#     # 11.5: General knowledge question -> RAG (prevents wrong CSV feature answers)
#     if _is_general_knowledge_question(user_text, full_rows) and getattr(rag_engine, "available", False):
#         out = rag_engine.rag_answer(user_text, last_model_norm=state.get("last_model"))
#         out["text"] = style_answer(user_text, out, DEFAULT_STYLE)
#         return _pipe(out, "RAG")
#     # 11.6: Force service/company topics to RAG (prevents CSV/SYSTEM misroutes)
#     if _is_service_company_rag_intent(user_text) and getattr(rag_engine, "available", False):
#         out = rag_engine.rag_answer(user_text, last_model_norm=state.get("last_model"))
#         return _pipe(out, "RAG")
#
#     # # 12: Preowned (tightened)
#     # if is_preowned_intent(user_text) and _looks_like_preowned_listing_query(
#     #         user_text) and not _is_warranty_or_services_info_question(user_text):
#     #     _cancel_reco_flow(state)
#     #     result = preowned_engine.query(user_text, top_k=10)
#     #     ans = preowned_engine.format_answer(result)
#     #
#     #     res = {
#     #         "answer_type": "preowned",
#     #         "text": ans.get("text", ""),
#     #         "facts": [ans.get("text", "")],
#     #         "sources": ans.get("sources", []),
#     #     }
#     #     res["text"] = style_answer(user_text, res, DEFAULT_STYLE)
#     #     return _pipe(res, "PREOWNED_RAG")
#     # 12: Preowned (tightened)
#     if is_preowned_intent(user_text) and _looks_like_preowned_listing_query(
#         user_text
#     ) and not _is_warranty_or_services_info_question(user_text):
#         _cancel_reco_flow(state)
#
#         result = preowned_engine.query(user_text, top_k=10)
#         ans = preowned_engine.format_answer(result)
#
#         text = str(ans.get("text") or "").strip()
#         sources = ans.get("sources") or []
#         sources = [str(s) for s in sources if s]
#
#         if not text:
#             if sources:
#                 lines = ["Here are Toyota Certified Pre-Owned listings I found:"]
#                 for i, u in enumerate(sources[:10], start=1):
#                     lines.append(f"{i}. {u}")
#                 text = "\n".join(lines)
#             else:
#                 text = "Sorry, I couldn't find any pre-owned listings for that request."
#
#         res = {
#             "answer_type": "preowned",
#             "text": text,
#             "facts": [text],
#             "sources": sources,
#         }
#         # res["text"] = style_answer(user_text, res, DEFAULT_STYLE)
#         # return _pipe(res, "PREOWNED_RAG")
#         styled = style_answer(user_text, res, DEFAULT_STYLE)
#
#         if isinstance(styled, str) and styled.strip():
#             res["text"] = styled
#         else:
#             # fallback protection — ensure never empty
#             if not res.get("text"):
#                 if res.get("sources"):
#                     lines = ["Here are Toyota Certified Pre-Owned listings I found:"]
#                     for i, u in enumerate(res["sources"][:10], start=1):
#                         lines.append(f"{i}. {u}")
#                     res["text"] = "\n".join(lines)
#                 else:
#                     res["text"] = "Sorry, I couldn't find any pre-owned listings for that request."
#
#         return _pipe(res, "PREOWNED_RAG")
#
#     # 13: Track last model mention
#     mentioned = detect_model_in_text(user_text, full_rows)
#     if mentioned:
#         state["last_model"] = mentioned
#
#     # 14: Compare
#     if _is_compare_intent(user_text):
#         models = _extract_compare_models(user_text, full_rows)
#         if len(models) >= 2:
#             _cancel_reco_flow(state)
#             return _pipe(_do_compare(full_rows, models[0], models[1]), "CSV_METHOD")
#         return _sys("Which two Toyota models do you want to compare? Example: compare Veloz vs Vios")
#
#     # 15: Specs
#     if is_spec_intent(user_text) or re.fullmatch(r"specs?\??", t0):
#         model = detect_model_in_text(user_text, full_rows) or state.get("last_model")
#         if not model:
#             return _sys("Which model are you asking about?")
#         state["last_model"] = model
#         _cancel_reco_flow(state)
#         return _pipe(answer_specs_from_csv(full_rows, model), "CSV_METHOD")
#
#     # 16: Summary
#     if is_summary_intent(user_text) or re.fullmatch(r"summary\??", t0):
#         model = detect_model_in_text(user_text, full_rows) or state.get("last_model")
#         if not model:
#             return _sys("Which model are you asking about?")
#         state["last_model"] = model
#         _cancel_reco_flow(state)
#         return _pipe(answer_summary_from_csv(full_rows, model), "CSV_METHOD")
#
#     # 17: Price
#     if any(k in t0 for k in ["price", "how much", "cost", "starting price"]):
#         model = resolve_target_model(user_text, state.get("last_model"), full_rows)
#         if not model:
#             return _sys("Which Toyota model price do you want?")
#         state["last_model"] = model
#         _cancel_reco_flow(state)
#         return _pipe(answer_price_from_csv(full_rows, model), "CSV_METHOD")
#
#     # 18: Recommendation (slot fill + filter)
#     is_reco = is_recommendation_intent(user_text) or state.get("slot_fill_active") is True or _looks_like_filter(user_text, full_rows)
#     if is_reco:
#         b = extract_budget(user_text)
#         s = extract_seats(user_text)
#         f = extract_fuel(user_text)
#         bt = extract_body_type(user_text)
#
#         # Force fuel detection for common words (prevents asking fuel again)
#         if not f:
#             if "gasoline" in t0 or "petrol" in t0:
#                 f = "gasoline"
#             elif "diesel" in t0:
#                 f = "diesel"
#             elif "hybrid" in t0 or "hev" in t0:
#                 f = "hybrid"
#             elif "ev" in t0 or "electric" in t0:
#                 f = "ev"
#
#         if b is not None:
#             state["slots"]["max_budget"] = b
#         if s is not None:
#             state["slots"]["min_seats"] = s
#         if f:
#             state["slots"]["fuel"] = f
#         if bt:
#             state["slots"]["body_type"] = bt
#
#         missing = _missing_slots(state["slots"])
#         if missing:
#             state["slot_fill_active"] = True
#             if "budget" in missing:
#                 return _csv_prompt("Sure. Tell me your budget (USD). Example: budget 40000")
#             if "body" in missing:
#                 return _csv_prompt("What body type do you want? (SUV / Sedan / Pickup / MPV / Bus)")
#             if "fuel" in missing:
#                 return _csv_prompt("What fuel do you prefer? (Gasoline / Diesel / Hybrid / EV)")
#             return _csv_prompt("Please provide: " + ", ".join(missing))
#
#         max_budget = float(state["slots"]["max_budget"])
#         min_seats = int(state["slots"]["min_seats"] or 0)
#         fuel = state["slots"]["fuel"]
#         body_type = state["slots"]["body_type"]
#
#         verified, possible = filter_cars_split(full_rows, max_budget, min_seats, fuel, body_type)
#         res = build_reco_answer(verified, possible, max_items=5, assumed_seats=min_seats or None)
#         _cancel_reco_flow(state)
#         return _pipe(res, "CSV_METHOD")
#
#     # 19: Feature Q&A
#     feature_key = detect_feature_key(user_text)
#     if feature_key:
#         # If user is asking a definition-like question with no model, send to RAG
#         if _is_general_knowledge_question(user_text, full_rows) and getattr(rag_engine, "available", False):
#             out = rag_engine.rag_answer(user_text, last_model_norm=state.get("last_model"))
#             return _pipe(out, "RAG")
#
#         model = resolve_target_model(user_text, state.get("last_model"), full_rows)
#         if not model:
#             return _sys("Which Toyota model are you asking about?")
#         state["last_model"] = model
#         _cancel_reco_flow(state)
#
#         res = answer_feature_from_csv(full_rows, model, feature_key)
#         if res:
#             return _pipe(res, "CSV_METHOD")
#
#         row = find_row_by_model(full_rows, model)
#         src = (row.get("url") if row else "") or ""
#         msg = "Thanks. I don’t have that feature captured in the current dataset yet."
#         return _pipe({"answer_type": "csv_feature", "text": msg, "facts": [msg], "sources": [src] if src else []}, "CSV_METHOD")
#
#     # 20: Fallback RAG
#     if getattr(rag_engine, "available", False):
#         out = rag_engine.rag_answer(user_text, last_model_norm=state.get("last_model"))
#         out["text"] = style_answer(user_text, out, DEFAULT_STYLE)
#         return _pipe(out, "RAG")
#
#     return _sys("Tell me a model name and what you want (price, specs, feature, compare, recommend, or preowned).")
def _is_gibberish(text: str) -> bool:
    t = (text or "").strip().lower()
    if not t:
        return True

    # very short meaningless
    if len(t) <= 2 and not any(c.isdigit() for c in t):
        return True

    # only symbols
    if re.fullmatch(r"[\W_]+", t):
        return True

    # repeated characters like "aaaaaa" or "هههههه"
    if len(set(t)) <= 2 and len(t) >= 6:
        return True

    # too many vowels in a long random string like "eeooehhyy"
    letters = re.sub(r"[^a-z]", "", t)
    if len(letters) >= 6:
        vowels = sum(1 for c in letters if c in "aeiouy")
        if vowels / max(len(letters), 1) > 0.75:
            return True

    return False


def _is_off_topic(text: str, full_rows: List[Dict[str, Any]]) -> bool:
    t = (text or "").lower()

    # if user mentions a valid model, it is not off-topic
    if detect_model_in_text(text, full_rows):
        return False

    # if user uses car-related keywords, it is not off-topic
    car_keywords = [
        "price", "cost", "spec", "specs", "feature", "engine",
        "fuel", "seat", "suv", "sedan", "pickup", "mpv",
        "hybrid", "diesel", "gasoline", "ev",
        "preowned", "pre-owned", "used", "mileage",
        "compare", "recommend", "budget", "warranty", "service"
    ]
    if any(k in t for k in car_keywords):
        return False

    # obvious off-topic categories (extend later if needed)
    off_topic = [
        "joke", "song", "movie", "weather", "love",
        "dating", "translate", "math", "game"
    ]
    return any(k in t for k in off_topic)
def chat_turn(
    user_text: str,
    state: Dict[str, Any],
    full_rows: List[Dict[str, Any]],
    rag_engine: Any,
    preowned_engine: PreownedEngine,
    debug: bool = False,
) -> Dict[str, Any]:

    if not state:
        _reset_state(state)

    user_text = _clean(user_text)

    if not user_text:
        return _sys("Please type a question.")

    t0 = _low(user_text)

    # -----------------------------
    # Reset
    # -----------------------------
    if t0 in {"/reset", "reset"}:
        _reset_state(state)
        return _sys("Reset done.")

    # -----------------------------
    # Small talk
    # -----------------------------
    if _is_small_talk(user_text):
        if t0 in {"thanks","thank you","ty"}:
            return _sys("You're welcome. What would you like to know about Toyota Cambodia?")
        if t0 in {"bye","goodbye"}:
            return _sys("Bye. If you need anything about Toyota models, price, specs, or services, just ask.")
        return _sys(_welcome_text())

    # -----------------------------
    # Garbage / gibberish guard
    # -----------------------------
    if _is_gibberish(user_text):
        return _sys(
            "Please ask a Toyota vehicle question such as price, specs, features, comparison, recommendation, "
            "pre-owned listings, warranty, or service information."
        )

    # -----------------------------
    # Off-topic guard
    # -----------------------------
    if _is_off_topic(user_text, full_rows):
        return _sys(
            "I can only help with Toyota Cambodia vehicle information such as price, specs, features, "
            "comparison, recommendation, pre-owned listings, warranty, or service information."
        )

    # -----------------------------
    # Questions intentionally not supported
    # -----------------------------
    if _is_not_answerable(user_text):
        return _sys(
            "That's a great question, but I don't have that information in our dataset. "
            "Please ask about Toyota models, price, specs, features, comparison, recommendations, or services."
        )

    # -----------------------------
    # General knowledge → RAG
    # -----------------------------
    if _is_general_knowledge_question(user_text, full_rows) and getattr(rag_engine, "available", False):
        out = rag_engine.rag_answer(user_text, last_model_norm=state.get("last_model"))
        out["text"] = style_answer(user_text, out, DEFAULT_STYLE)
        return _pipe(out, "RAG")

    # -----------------------------
    # Service / company topics → RAG
    # -----------------------------
    if _is_service_company_rag_intent(user_text) and getattr(rag_engine, "available", False):
        out = rag_engine.rag_answer(user_text, last_model_norm=state.get("last_model"))
        return _pipe(out, "RAG")

    # -----------------------------
    # PREOWNED
    # -----------------------------
    if is_preowned_intent(user_text) and _looks_like_preowned_listing_query(user_text):

        _cancel_reco_flow(state)

        result = preowned_engine.query(user_text, top_k=10)
        ans = preowned_engine.format_answer(result)

        text = str(ans.get("text") or "").strip()
        sources = ans.get("sources") or []

        if not text:
            if sources:
                lines = ["Here are Toyota Certified Pre-Owned listings:"]
                for i, s in enumerate(sources[:10], start=1):
                    lines.append(f"{i}. {s}")
                text = "\n".join(lines)
            else:
                text = "Sorry, I couldn't find any pre-owned listings."

        res = {
            "answer_type": "preowned",
            "text": text,
            "facts": [text],
            "sources": sources,
        }

        styled = style_answer(user_text, res, DEFAULT_STYLE)
        if styled and styled.strip():
            res["text"] = styled

        return _pipe(res, "PREOWNED_RAG")

    # -----------------------------
    # Track last model
    # -----------------------------
    mentioned = detect_model_in_text(user_text, full_rows)
    if mentioned:
        state["last_model"] = mentioned

    # -----------------------------
    # Compare
    # -----------------------------
    if _is_compare_intent(user_text):

        models = _extract_compare_models(user_text, full_rows)

        if len(models) >= 2:
            _cancel_reco_flow(state)
            return _pipe(_do_compare(full_rows, models[0], models[1]), "CSV_METHOD")

        return _sys("Which two Toyota models do you want to compare? Example: compare Veloz vs Vios")

    # -----------------------------
    # Specs
    # -----------------------------
    if is_spec_intent(user_text):

        model = detect_model_in_text(user_text, full_rows) or state.get("last_model")

        if not model:
            return _sys("Which model are you asking about?")

        state["last_model"] = model
        _cancel_reco_flow(state)

        return _pipe(answer_specs_from_csv(full_rows, model), "CSV_METHOD")

    # -----------------------------
    # Summary
    # -----------------------------
    if is_summary_intent(user_text):

        model = detect_model_in_text(user_text, full_rows) or state.get("last_model")

        if not model:
            return _sys("Which model are you asking about?")

        state["last_model"] = model
        _cancel_reco_flow(state)

        return _pipe(answer_summary_from_csv(full_rows, model), "CSV_METHOD")

    # -----------------------------
    # Price
    # -----------------------------
    if any(k in t0 for k in ["price","how much","cost","starting price"]):

        if any(k in t0 for k in ["under","below","budget","less than"]):
            pass
        else:
            model = resolve_target_model(user_text, state.get("last_model"), full_rows)

            if not model:
                return _sys("Which Toyota model price do you want?")

            state["last_model"] = model
            _cancel_reco_flow(state)

            return _pipe(answer_price_from_csv(full_rows, model), "CSV_METHOD")

    # -----------------------------
    # Recommendation engine
    # -----------------------------
    is_reco = (
        is_recommendation_intent(user_text)
        or state.get("slot_fill_active") is True
        or _looks_like_filter(user_text, full_rows)
    )

    if is_reco:

        b = extract_budget(user_text)
        s = extract_seats(user_text)
        f = extract_fuel(user_text)
        bt = extract_body_type(user_text)

        if b is not None:
            state["slots"]["max_budget"] = b
        if s is not None:
            state["slots"]["min_seats"] = s
        if f:
            state["slots"]["fuel"] = f
        if bt:
            state["slots"]["body_type"] = bt

        missing = _missing_slots(state["slots"])

        if missing:

            state["slot_fill_active"] = True

            if "budget" in missing:
                return _csv_prompt("Tell me your budget (USD). Example: budget 40000")

            if "body" in missing:
                return _csv_prompt("What body type do you want? (SUV / Sedan / Pickup / MPV / Bus)")

            if "fuel" in missing:
                return _csv_prompt("What fuel do you prefer? (Gasoline / Diesel / Hybrid / EV)")

            return _csv_prompt("Please provide: " + ", ".join(missing))

        max_budget = float(state["slots"]["max_budget"])
        min_seats = int(state["slots"]["min_seats"] or 0)
        fuel = state["slots"]["fuel"]
        body_type = state["slots"]["body_type"]

        verified, possible = filter_cars_split(
            full_rows, max_budget, min_seats, fuel, body_type
        )

        res = build_reco_answer(verified, possible, max_items=5)

        txt = str(res.get("text") or "").lower()

        if ("couldn't find" in txt) or ("no match" in txt):

            state["slot_fill_active"] = True
            return _pipe(res, "CSV_METHOD")

        _cancel_reco_flow(state)

        return _pipe(res, "CSV_METHOD")

    # -----------------------------
    # Feature Q&A
    # -----------------------------
    feature_key = detect_feature_key(user_text)

    if feature_key:

        model = resolve_target_model(user_text, state.get("last_model"), full_rows)

        if not model:
            return _sys("Which Toyota model are you asking about?")

        state["last_model"] = model
        _cancel_reco_flow(state)

        res = answer_feature_from_csv(full_rows, model, feature_key)

        if res:
            return _pipe(res, "CSV_METHOD")

        return _sys("That feature is not available in the dataset yet.")

    # -----------------------------
    # Final RAG fallback
    # -----------------------------
    if getattr(rag_engine, "available", False):

        out = rag_engine.rag_answer(user_text, last_model_norm=state.get("last_model"))

        styled = style_answer(user_text, out, DEFAULT_STYLE)

        if styled and styled.strip():
            out["text"] = styled

        return _pipe(out, "RAG")

    # -----------------------------
    # Final fallback
    # -----------------------------
    return _sys(
        "Tell me a Toyota model and what you want (price, specs, feature, compare, recommend, or pre-owned)."
    )
def _is_service_company_rag_intent(user_text: str) -> bool:
    t = _low(user_text)

    # Service / appointment / maintenance info (not car recommendation)
    if re.search(r"\b(service|servicing|maintenance|repair|appointment|book|booking|schedule)\b", t):
        return True

    # Branches / contacts / location
    if re.search(r"\b(branch|branches|showroom|dealer|dealership|service center|workshop|contact|hotline|phone|address|location)\b", t):
        return True

    # Company / distributor / profile
    if re.search(r"\b(company profile|profile|history|mission|vision|official distributor|distributor)\b", t):
        return True

    # Toyota Plus / parts policy / warranty policy wording (informational)
    if re.search(r"\b(toyota plus|genuine parts|parts policy)\b", t):
        return True

    # Specific pattern: “service A/B/C/D price”
    if re.search(r"\bservice\s*[a-d]\b.*\b(price|cost)\b", t):
        return True

    return False

def render_answer(
    user_text: str,
    res: Dict[str, Any],
    use_llm: bool = False,
    rewrite_csv: bool = False,
    debug: bool = False,
) -> str:
    text = str(res.get("answer") or res.get("text") or "").strip()
    if not text:
        facts = res.get("facts") or []
        if isinstance(facts, list) and facts:
            text = str(facts[0]).strip()
    if not text:
        text = "Sorry — I couldn't produce an answer."

    sources = [s for s in (res.get("sources") or []) if s]
    if sources:
        text += "\nSources: " + ", ".join(sources[:3])

    if debug and res.get("pipeline"):
        text += f"\n[PIPELINE={res['pipeline']}]"

    return text
